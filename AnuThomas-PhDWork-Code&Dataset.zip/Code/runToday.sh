sh runDir2/scripts/runCRSP.sh run  ./runDir2
sh runDir21/scripts/runCRSP.sh run  ./runDir21
sh runDir/scripts/runCRSP.sh run  ./runDir
