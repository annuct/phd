
clear all;
data1 = csvread('CG_sf.csv');

for i=2:5
    data1(:,i) = min(data1(:,i)',data1(:,5+i)');
end
data(:,1:5) = data1(:,1:5);
data(:, 6) = max(data(:,1:4)');
data(:,7:11) =  data1(:,6:10);
data(:, end+1) = min(data1(:,7:9)');
gp = find(data1(:,6)~=0);
data(gp, end) = min(data1(gp,6:9)');

% 11:14 CM, LR CGs CGf best

for i=1:6
    if(i==5) continue; end
    data(:,end+1) = (data(:,5) - data(:,i) )./data(:,i)*100;    
end



for i=7:12
    if(i==11) continue; end
    gp = find( data(:,i) ~=0);    
    data(:,end+1) =100; 
    data(gp,end) = (data(gp,i)- data(gp,11))./data(gp,i)*100;    
end


for j=1:10
    val = [0, 0.00001, 0.01, .1, 1, 100];
    for k=1:6
    M(k,j) = length(find(data(:,j+12)>-val(k)))/length(data)*100;    
    end
end
disp(M)
figure(1)
boxplot(data(:,13:end) ,'orientation', 'horizontal');
axis([-5 35 0 11]);

figure(2)
data(:,13)=0;
data(:,18)=0;
boxplot(data(:,13:end) ,'orientation', 'horizontal');
axis([-3 3 0 11]);


