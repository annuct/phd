
function create_CG_plots

filename = 'ColGen_data_plot.csv';

content = fileread(filename);

[str pos]  =regexp(content,'\n','match');
content = content(pos(2)+1:end);

mineIdx = [7, 10, 5, 6, 8,9, 12,15];
mineLetters = ['A'; 'B'; 'C'; 'D'; 'E'; 'F'; 'G'; 'H' ];

for i=1:length(mineIdx)
    content = regexprep(content, mineLetters(i),[num2str(mineIdx(i)*1000)]);
end

content = regexp(content,'\n','split');

ResMat =[];
for i=1:length(content)
    if(regexp(content{i},'^,')) continue; end
    ResMat(end+1, :) =  str2double(regexp(content{i},',','split')) ;
end


% 	1  | 2  3  4    5 |  6  7   8   9 |   10  11 12  13  |
% ,Lowerbound,,,,Upperbound,,,,Time,,,
% Set,CM,LR,CG-s,CG-f,CM,LR,CG-s,CG-f,CM,LR,CG-s,CG-f

%computing LB and UB diff ratio

for k=1:4 % gap
    gp1 = find(isnan(ResMat(:,k+5)));
    gp2 = setdiff(1:length(ResMat), gp1); %find(Not(isnan(ResMat(:,k+5))));
    
    ResMat(gp1,end+1) = 100;  % 14 15 16 17
    ResMat(gp2,end) = (ResMat(gp2,k+5) - ResMat(gp2,k+1))./ResMat(gp2,k+5)*100;  % 18 19 20 21
end




for k=2:5 % LB normalisation
    ResMat(:,end+1) = ResMat(:,k)./max(ResMat(:,2:5)')';  % 18 19 20 21
end
for k=6:9 % UB normlisation
    ResMat(:,end+1) = ResMat(:,k)./min(ResMat(:,6:9)')'; % 22 23 24 25
end



VhardGp = setdiff(find(isnan(ResMat(:,6)) >0), find(isnan(ResMat(:,10)) >0));



%plot_CI(ResMat, 1);
%plot_CI(ResMat, 2);

ResMat(:,end+1) = floor(ResMat(:,1)/10000);
zGp = intersect(find(ResMat(:,end)>10), find(rem(ResMat(:,end),10)==0));
ResMat(zGp,end) = ResMat(zGp,end)/10;



ResMat(:,end+1) = rem(ResMat(:,1),1000);

plot_boxplot(ResMat, 1);
plot_boxplot(ResMat, 2);


str ='';
X =[2,3,4,5];
for i=1:length(X)
    switch(i)
        case 1
            str =[str, 'CM'];
        case 2
            str =[str, 'LR'];
        case 3
            str =[str, 'CG-s'];
        case 4
            str =[str, 'CG-f'];
    end
    for j=1:length(X)
        if(i==j) , str =[str,'& '];continue; end
        VV(i,j) = length(find(ResMat(:,X(i))>=ResMat(:,X(j))));
        %VV(i,j) = VV(i,j)+length(find(ResMat(:,X(i))==ResMat(:,X(j))))/2;
        str =[str,'& ', num2str(VV(i,j))];
    end
    str =[str,'\\ \hline ', char(10)];
end
%  disp('Lowerbound comparison')
% disp(str)

X =[6,7,8,9];
for i=1:length(X)
    switch(i)
        case 1
            str =[str, 'CM'];
        case 2
            str =[str, 'LR'];
        case 3
            str =[str, 'CG-s'];
        case 4
            str =[str, 'CG-f'];
    end
    for j=1:length(X)
        if(i==j), str =[str,'& ']; continue; end
        
        VV(i,j) = length(find(ResMat(:,X(i))<=ResMat(:,X(j))));
     %   VV(i,j) = VV(i,j)+length(find(ResMat(:,X(i))==ResMat(:,X(j))))/2;
        VV(i,j) =  VV(i,j)+length(find(isnan(ResMat(:,X(j)))));
        str =[str,'& ', num2str(VV(i,j))];
    end
    str =[str,'\\ \hline ', char(10)];
end

disp(str)

disp('finished....');
end


function plot_boxplot(ResMat, flag)
if(flag==1)
    data = unique(ResMat(:,end-1));
else
    data = [1,2,3,4];
    Group ={};
    Group{1} = find(ResMat(:,14) < 10);
    Group{2} = setdiff(find(ResMat(:,14) < 20),  Group{1});
    Group{3} = setdiff(setdiff(find(ResMat(:,14) > 20),  Group{1}),  Group{2});
    Group{4}= setdiff(find(isnan(ResMat(:,6)) ), find(isnan(ResMat(:,10)) >0));
    Group{3} =  setdiff(Group{3}, Group{4});
end
statMat=[];
%h2 = figure(2);

for ch=1:4 % ch LB, UB, Gap, Time
    
    h = figure(1);
    Mat=[];
    cnt=0;
    for s =1:length(data)
        xval = data(s);
        if(isnan(xval)) continue; end
        
        if(flag==1)
            gp = find(ResMat(:,end-1) == xval);
        else
            gp = Group{s};
            xval = 4*s;
        end
        if isempty(gp) continue; end
        cnt = cnt+1;
        if(ch==4)
            start= 10;
        elseif(ch==3)
            start = 14;
        else
            start = (ch-1)*4 +18;
        end
        Mat(1:length(gp), 5*cnt-3:5*cnt ) = ResMat(gp,start:start+3 );
        
        Mat(1:length(gp), 5*cnt-4) = -100;
    end
    
    
    %     Origin ={};
    %
    %     for s =1:length(data)
    %         uu = Mat(:, 5*s-3: 5*s);
    %         str = ['a', num2str(s),' <- matrix(c('];
    %         for j=1:size(uu,2)
    %             for i=1:size(uu,1)
    %                 str = [str, ', ', num2str(uu(i,j))];
    %             end
    %         end
    %         str =[str,'), ncol=4)'];
    %         % disp(str)
    %     end
    
    %    /* for i=1:size(Mat,2)
    %         if( mod(i,3)==1)
    %             Origin{end+1} = [' ', num2str((i+2)/3*900), ' '];
    %         elseif mod(i,3)==0
    %             Origin{end+1} = [' ', num2str(i), ' -------- LR'] ;
    %         else
    %             Origin{end+1} = [' ', num2str(i), ' ---------- IM'];
    %         end
    %
    %     end
    % 	*/
    
    
    xaxis =data;
    %   set(0,'CurrentFigure',h2);
    
    %     for k= 1:length(data)
    %         prcmat = [];
    %         for u=1:4
    %             prcmat(end+1,:) = prctile(Mat(:, 1+u+5*(k-1)),[40 50 60]);
    %         end
    %         newx = [xaxis fliplr(xaxis)];
    %         newy =  [prcmat(:,1) ; flipud(prcmat(:,3))];
    %         if(k==2)
    %             %    fill(newx, newy, [90 190 190]/255); hold on;
    %             plot(xaxis, prcmat(:,2), 'b', 'linewidth',2); hold on;
    %         else
    %             %     fill(newx, newy, [190 90 190]/255); hold on;
    %             plot(xaxis, prcmat(:,2), 'r', 'linewidth',2); hold on;
    %         end
    %     end
    
    %      y = prctile(Mat(:,i),[25 50 75]);
    
    
    
    set(0,'CurrentFigure',h); ymin=100;ymax=0;
    cl ={[.3,.3,.3], [.3,.6,.6],[.6,.1,.2],[.9,.3,.4]};
    for i=2:4 % method        
        tmpMat = Mat*0;
        tmpMat(:,[i+1:5:size(Mat,2)]) =  Mat(:,[i+1:5:size(Mat,2)]);
        ymin = min(ymin, min(min(Mat(:,[i+1:5:size(Mat,2)]))));
        ymax = max(ymax, max(max(Mat(:,[i+1:5:size(Mat,2)]))));
        if(flag==2)
            for k=1:4
                tmp2Set = 1:length(Group{k});
                tmpMat2 = tmpMat(tmp2Set,:)*0;
                tmpMat2(tmp2Set,(i+1)+5*(k-1)) = tmpMat(tmp2Set,(i+1)+5*(k-1));
            boxplot(tmpMat2, 'color',cl{i}); hold on;
            end
        else
        boxplot(tmpMat, 'color',cl{i}); hold on;
        end
    end
    
    %boxplot(Mat(:,[3:5:size(Mat,1)]),Origin, 'color', [30 144 255]/255 , 'orientation', 'horizontal'); hold on;
    %boxplot(Mat(:,[4:5:size(Mat,1)]),Origin, 'color','r', 'orientation', 'horizontal'); hold on;
    %boxplot(Mat(:,[5:5:size(Mat,1)]),Origin, 'color','g', 'orientation', 'horizontal'); hold on;
    
    
    
    
    if (ch==1)
        ylabel('Lowerbound');
    elseif (ch==2)
        ylabel('Upperound');
    elseif (ch==3)
        ylabel('Relative Gap');
    elseif (ch==4)
        ylabel('Time');
    end
    if( flag==1)
        xlabel('Data Series');
    else
        xlabel('Data Group');
    end
    
    axis([0, length(data)*5+5, ymin, ymax]);
    
    % set(gca,'XDir','reverse');
    % set(gca,'XTick',[0, 12]);
    %  text(maxx*0.9, 12, ['\fontsize{16} \bf {\color{magenta} --- IM}  {\color[rgb]{0.1176    0.5647    1} --- LR}'])
    
    %     for i= 1: size(Mat,2)
    %         mv = mean(Mat(:,i));
    %         if (mv >0)
    %             hold on; plot([mv mv], [i i], '-ko', 'MarkerSize',2, 'LineWidth',4);
    %         end
    %     end
    
    %     disp(['time_gap_series',num2str(xval),'    ', num2str(median(Mat))]);
    %
    %     % 24 free 25= Avg  # orders	26= Tot Dem	27 = # orders	28 = Avg demand per 0rder	29=avg # trips
    %     % 30= no of mines, 31 = class, 32 = no trains
    %
    %     vect = [s  mean(ResMat(gp,25:29)) ....
    %         mean(ResMat(gp,29)./ResMat(gp,32)) mean(ResMat(gp,27)./ResMat(gp,32))];
    
    
    
    if(flag==1)
        title(['DataSeries-',num2str(ch)]);
        saveas(h,['cg_1series',num2str(ch),'.png']);
        %         saveas(h,['time_gap_series',num2str(xval),'.eps']);
        %   statMat(:, s) = transpose(vect);
    else
        title(['DataGroup-',num2str(ch)]);
        saveas(h,['cg_1group',num2str(ch),'.png']);
        %           saveas(h,['time_gap_gp',num2str(xval),'.eps']);
        %  statMat( s, : ) = vect';
    end
    
    
    
    clf(h);
    
end
% disp([num2str(flag) ' method']);
% disp(num2str(statMat));


end


