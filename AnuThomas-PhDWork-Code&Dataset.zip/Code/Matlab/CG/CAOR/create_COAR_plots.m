
function create_COAR_plots

 filename = 'CAOR_data_plot.csv';
% filename ='CAOR_CPX_nonstabilised_SS.csv';

content = fileread(filename);

[str pos]  =regexp(content,'\n','match');
content = content(pos(2)+1:end);

mineIdx = [7, 10, 5, 6, 8,9, 12,15];
mineLetters = ['A'; 'B'; 'C'; 'D'; 'E'; 'F'; 'G'; 'H' ];

for i=1:length(mineIdx)
    content = regexprep(content, mineLetters(i),num2str(mineIdx(i)));
end

content = regexp(content,'\n','split');

ResMat =[];
for i=1:length(content)
    if(regexp(content{i},'^,')) continue; end
    ResMat(end+1, :) =  str2double(regexp(content{i},',','split'));
end


% DATA is ready in matrix form

% column 1:  number of mines,
% column 2: set no,
% col 3: CM LB
% col 4 CM UB, 5=CM Gap 6 =  CM Time,  7= free, 8= LR no itrs, 9= LB,
% 10=UB, 11= gap, 12= time, 13=step 14= viol, 15= free,
% 16 - 19 CM time, 20-23 LR time
% 24 free 25= Avg  # orders	26= Tot Dem	27 = # orders	28 = Avg demand per prder	29=avg # trips
% 30= free, 31 LB diff ratio, 32 UB diff ratio


%computing LB and UB diff ratio


ResMat(:,end+2) = (ResMat(:,9) - ResMat(:,3))./max(ResMat(:,9), ResMat(:,3));
ResMat(:,end+1) = (ResMat(:,10) - ResMat(:,4))./min(ResMat(:,10), ResMat(:,4));

VhardGp = setdiff(find(isnan(ResMat(:,5)) >0), find(isnan(ResMat(:,6)) >0));

% ResMat(VhardGp,26) = (ResMat(VhardGp,10) - 100)./ResMat(VhardGp,10);


%taking the minimum from interpolation and log to get the gap at t = 3600 secs
 % ResMat(:,19) = min(ResMat(:,19), ResMat(:,5));


 plot_CI(ResMat, 1);
 plot_CI(ResMat, 2);



%plot_gap(ResMat, 1);
%plot_gap(ResMat, 2);




disp('finished....');
end


function plot_gap(ResMat, flag)
if(flag==1)
    data = unique(ResMat(:,1));
else
    data = [1,2,3,4];
    Group ={};
    Group{1} = find(ResMat(:,5) < 10);
    Group{2} = setdiff(find(ResMat(:,5) < 20),  Group{1});
    Group{3} = setdiff(setdiff(find(ResMat(:,5) > 20),  Group{1}),  Group{2});
    Group{4}= setdiff(find(isnan(ResMat(:,5)) >0), find(isnan(ResMat(:,6)) >0));
end
statMat=[];
h2 = figure(2);
for s =1:length(data)
    
    h = figure(1);
    
    xval = data(s);
    if(isnan(xval)) continue; end
    
    if(flag==1)
        gp = find(ResMat(:,1) == xval);
    else
        gp = Group{s};
        xval = 2*s;
    end
    
    Mat=[];
    for k=1:4
        Mat(:, 3*k-1) = ResMat(gp, 15+k);
        Mat(:, 3*k) = ResMat(gp, 19+k);
    end
    
    
    Origin ={};
    for i=1:size(Mat,2)
        if( mod(i,3)==1)
            Origin{end+1} = [' ', num2str((i+2)/3*900), ' '];
        elseif mod(i,3)==0
            Origin{end+1} = [' ', num2str(i), ' -------- LR'] ;
        else
            Origin{end+1} = [' ', num2str(i), ' ---------- IM'];
        end
        
   
    end
   
     xaxis =[900 1800 2700 3600];
    set(0,'CurrentFigure',h2);
    for k= 2:3
        prcmat = [];
        for u=1:4
            prcmat(end+1,:) = prctile(Mat(:,(u-1)*3+k),[40 50 60]);
        end
        newx = [xaxis fliplr(xaxis)];
        newy =  [prcmat(:,1) ; flipud(prcmat(:,3))];
        if(k==2)
    %    fill(newx, newy, [90 190 190]/255); hold on;
        plot(xaxis, prcmat(:,2), 'b', 'linewidth',2); hold on;
        else
   %     fill(newx, newy, [190 90 190]/255); hold on;
        plot(xaxis, prcmat(:,2), 'r', 'linewidth',2); hold on;            
        end
    end
    
    %      y = prctile(Mat(:,i),[25 50 75]);
    
    
    
    maxx = max(max(Mat))+2;
    
    a= Mat*0 + -10;
    b = a;
    
    for k=1:4
        a(:, 3*k) = Mat(:, 3*k);
        b(:, 3*k-1) = Mat(:, 3*k-1);
    end
    set(0,'CurrentFigure',h);
    boxplot(b,Origin, 'color','m', 'orientation', 'horizontal'); hold on;
    boxplot(a, Origin, 'boxstyle','filled', 'color',[30 144 255]/255, 'orientation', 'horizontal');
    
    
    ylabel('Time in secs');
    xlabel('Gap in percentage');
    axis([-2  maxx 0 13])
    set(gca,'XDir','reverse');
    % set(gca,'XTick',[0, 12]);
    text(maxx*0.9, 12, ['\fontsize{16} \bf {\color{magenta} --- CPX}  {\color[rgb]{0.1176    0.5647    1} --- LR}'])
    
    for i= 1: size(Mat,2)
        mv = mean(Mat(:,i));
        if (mv >0)            
            hold on; plot([mv mv], [i i], '-ko', 'MarkerSize',2, 'LineWidth',4);            
        end
    end
    
    disp(['time_gap_series',num2str(xval),'    ', num2str(median(Mat))]);
        
    % 24 free 25= Avg  # orders	26= Tot Dem	27 = # orders	28 = Avg demand per 0rder	29=avg # trips
    % 30= no of mines, 31 = class, 32 = no trains
    
    vect = [s  mean(ResMat(gp,25:29)) ....
        mean(ResMat(gp,29)./ResMat(gp,32)) mean(ResMat(gp,27)./ResMat(gp,32))];
    
    
    
    if(flag==1)
        title(['DataSeries-',num2str(xval)]);
        saveas(h,['time_gap_series',num2str(xval),'.png']);
%         saveas(h,['time_gap_series',num2str(xval),'.eps']);
         statMat(:, s) = transpose(vect);
    else
        title(['DataGroup-',num2str(xval)]);
        saveas(h,['time_gap_gp',num2str(xval),'.png']);
%           saveas(h,['time_gap_gp',num2str(xval),'.eps']);
         statMat( s, : ) = vect';
    end
    
    
    
    clf(h);
  
end
% disp([num2str(flag) ' method']);
% disp(num2str(statMat));


end

function plot_CI(ResMat, flag)

% flag =1 series flag==2 group
eps=0.1;

if(flag==1)
    data = unique(ResMat(:,1));
else
    data = [1,2,3,4];
    Group ={};
    Group{1} = find(ResMat(:,5) < 10);
    Group{2} = setdiff(find(ResMat(:,5) < 20),  Group{1});
    Group{3} = setdiff(setdiff(find(ResMat(:,5) > 20),  Group{1}),  Group{2});
    Group{4}= setdiff(find(isnan(ResMat(:,5)) >0), find(isnan(ResMat(:,6)) >0));
end


h1 = figure(1);
h2 = figure(2);
statMat=[];
for s =1:length(data)
    xval = data(s);
    if(isnan(xval)) continue; end
    
    if(flag==1)
        gp = find(ResMat(:,1) == xval);
        if(xval==12) xval=11; end
        if(xval==15) xval=12; end
    else
        gp = Group{s};
        xval = 2*s;
    end
    
    
    LBdiff = ResMat(gp, end-1);
    UBdiff = ResMat(gp,end);
    plotASeries(h1, LBdiff, xval);
    plotASeries(h2, UBdiff, xval);
end


% 27 free 28= Avg  # orders	29= Tot Dem	30 = # orders	31 = Avg demand per prder	32=avg # trips



set(0,'CurrentFigure',h1);
ylabel('Relative difference (BM- CPX)/ Max');
% title('95 % CI for the difference in lowerbound')

if(flag==1)
    xlabel('Number of Mines');
    line([4.5, 12.5],[0,0], 'color','k');
    xlim([4.5, 12.5])
    saveas(h1,'lb_conf_series.png');
else
    xlabel('Easy     Medium     Hard    Very Hard');
    line([1 9],[0,0], 'color','k');
    xlim([1 9])
    saveas(h1,'lb_conf_group.png');
end
clf(h1);

set(0,'CurrentFigure',h2);
ylabel('Relative difference (BM- CPX)/ Min');
% title('95 % CI for the difference in upperbound')

if(flag==1)
    xlabel('Number of Mines');
    line([4.5, 12.5],[0,0],'color','k');
    xlim([4.5, 12.5])
    saveas(h2,'ub_conf_series.png');
%     saveas(h2,'ub_conf_series.eps');
else
    xlabel('Easy         Medium            Hard          Very Hard');
    line([1 9],[0,0], 'color','k');
    xlim([1 9])
    text(7.9, -0.18, '\bf {NA}'); 
    saveas(h2,'ub_conf_group.png')
%       saveas(h2,'ub_conf_group.eps')
end
clf(h2);
end

function plotASeries(h, diff, xval)
set(0,'CurrentFigure',h);
eps =0.1;
diff = diff(find(~isnan(diff)));
% UBdiff = ResMat(gp,26);

[h,p,ci, stat] = ttest(diff, 0.05);
line([xval, xval],ci,  'LineWidth',3,'color','b'); hold on
line([xval-eps, xval+eps],[ci(1) ci(1)],  'LineWidth',3,'color','r'); hold on
line([xval-eps, xval+eps],[ci(2) ci(2)],        'LineWidth',3,'color','r'); hold on
line([xval-eps, xval+eps], [mean(diff) mean(diff)],  'LineWidth',3,'color','r'); hold on

% line(ci,[xval, xval],  'LineWidth',3,'color','b'); hold on
% line([ci(1) ci(1)],[xval-eps, xval+eps],  'LineWidth',3,'color','r'); hold on
% line([ci(2) ci(2)],   [xval-eps, xval+eps],      'LineWidth',3,'color','r'); hold on
% line([mean(diff) mean(diff)],[xval-eps, xval+eps],  'LineWidth',3,'color','r'); hold on


disp(['PlotASeries ' num2str([h xval mean(diff) median(diff)  ci'])]);
end


