function cm_lr_plot

data = csvread('CM_LR_results.csv');

% CM - LB	LR 1- LB	LR -2 LB	CM - UB	LR 1- UB	LR -2 UB

noSets = 10;
noSeries = 3;

dcnt=1;


eps = 0.01;
NoMines = [7, 10, 5, 6, 9, 12];
figure(1)
line([0, 1], [0, 0],  'LineWidth',2,'color','b'); hold on
line([0, 1], [0, 0],  'LineWidth',2,'color','k'); hold on
line([0, 1], [0, 0],  'LineWidth',2,'color','g'); hold on

ymin =0; ymax =0;
legend('LR1-CM','LR2-CM','LR2-LR1')

for dcnt = 1:6
    xval = NoMines(dcnt)-0.1;
    CIarray =[];
    CIarray(end+1)=     NoMines(dcnt);
    for i=1:noSeries-1
        for j=i+1:noSeries
            row1 = data((dcnt-1)*(noSets+1)+1: dcnt*(noSets+1)-1, i);
            row2 = data((dcnt-1)*(noSets+1)+1: dcnt*(noSets+1)-1, j);
            
            diff1 = (row2 - row1)./max(row1, row2)*100;
            [h,p,ci, stat] = ttest(diff1, 0.05);
            
            if(i+j ==3 )
                line([xval, xval],ci,  'LineWidth',2,'color','b'); hold on
                
            elseif(i+j ==4)
                line([xval, xval],ci,  'LineWidth',2,'color','k'); hold on
                
            else
                line([xval, xval],ci,  'LineWidth',2,'color','g'); hold on
            end
            
            ymin=  min(ymin,ci(1));
            ymax=  max(ymax,ci(2));
            CIarray(end+1)=     ci(1);
            CIarray(end+1)=     ci(2);
            
            line([xval-eps, xval+eps],[ci(1) ci(1)],  'LineWidth',3,'color','r'); hold on
            line([xval-eps, xval+eps],[ci(2) ci(2)],  'LineWidth',3,'color','r'); hold on
            line([xval-eps, xval+eps], [mean(diff1) mean(diff1)],  'LineWidth',3,'color','r'); hold on
            
            xval = xval+0.2;
        end
    end
    disp(['LB   ',num2str(CIarray)])
end
xlabel('Number of Mines');
ylabel('CI for the differnce in percentage');
line([4.5, 12.5],[0,0]);
axis([4.5, 12.5 ymin-1 ymax+1])
title('Lowerbound')


ymin =0; ymax =0;
%%
figure(2)



line([0, 1], [0, 0],  'LineWidth',2,'color','b'); hold on
line([0, 1], [0, 0],  'LineWidth',2,'color','k'); hold on
line([0, 1], [0, 0],  'LineWidth',2,'color','g'); hold on


legend('LR1-CM','LR2-CM','LR2-LR1')

for dcnt = 1:6
    xval = NoMines(dcnt)-0.1;
    CIarray =[];
    CIarray(end+1)=     NoMines(dcnt);
    
    for i=noSeries+1:2*noSeries-1
        for j=i+1:2*noSeries
            row1 = data((dcnt-1)*(noSets+1)+1: dcnt*(noSets+1)-1, i);
            row2 = data((dcnt-1)*(noSets+1)+1: dcnt*(noSets+1)-1, j);
            
            u = find(row1 >0);
            diff1 = (row2(u) - row1(u))./min(row1(u), row2(u))*100;
            [h,p,ci, stat] = ttest(diff1, 0.05);
            
            if(i+j == 9 )
                line([xval, xval],ci,  'LineWidth',2,'color','b'); hold on
                
            elseif(i+j == 10)
                line([xval, xval],ci,  'LineWidth',2,'color','k'); hold on
                
            else
                line([xval, xval],ci,  'LineWidth',2,'color','g'); hold on
            end
            
            ymin=  min(ymin,ci(1));
            ymax=  max(ymax,ci(2));
            
            CIarray(end+1)=     ci(1);
            CIarray(end+1)=     ci(2);
            
            line([xval-eps, xval+eps],[ci(1) ci(1)],  'LineWidth',3,'color','r'); hold on
            line([xval-eps, xval+eps],[ci(2) ci(2)],  'LineWidth',3,'color','r'); hold on
            line([xval-eps, xval+eps], [mean(diff1) mean(diff1)],  'LineWidth',3,'color','r'); hold on
            
            xval = xval+0.2;
        end
    end
    disp(['UB   ',num2str(CIarray)])    ;
end

xlabel('Number of Mines');
ylabel('CI for the differnce in percentage');
line([4.5, 12.5],[0,0]);
axis([4.5, 12.5 ymin-1 ymax+1])
title('Upperbound')
