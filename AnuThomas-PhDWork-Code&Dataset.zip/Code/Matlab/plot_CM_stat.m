
function plot_CM_stat

filename  = 'Set_A/CM_A-stats.csv';
filename2 = 'Set_A/LR_z28_A_summary.txt';
data = csvread(filename);

sets = unique(data(:,1));



for i = 1: length(sets)
    idx = find(data(:,1)==i);
    
    
    time = data(idx,2);
    gap = data(idx,3);
    
    
    A(i,:) = findGaps(time, gap);
    % disp([i, g]);
end



LRsumm = regexp(fileread(filename2),'\n','split');
step =1; M=[];
for i=1:length(LRsumm)
    if ~isempty(regexp(LRsumm{i},'^Itr')) || i== length(LRsumm)
        
        if (i==1)             continue;         end
        gap = M(:,4);
        time = M(:,5);
        B(step,:) = findGaps(time, gap);
        step = step+1;
        M =[];
    else
        tmp =  str2double(regexp(LRsumm{i},',\s+','split'));
        if(length(tmp) > 5)
            M(end+1,:) = tmp;
        end
    end
end

for step =1 :4
    A1(:,3*step-1) = A(:,step);
    A1(:,3*step) = B(:,step);
end
Origin ={};
for i=1:size(A1,2)
    if( mod(i,3)==1)
        Origin{end+1} = [num2str((i+2)/3*900), ' -'];
    elseif mod(i,3)==0
        Origin{end+1} = [num2str(i/3*900), ' - LR'] ;
    else
        Origin{end+1} = [num2str((i+1)/3*900), ' - CM'];
    end

end
boxplot(A1,Origin, 'color','wmb', 'orientation', 'horizontal');
title(['DataSet-A']);
ylabel('Time in secs');
xlabel('Gap in percentage');
axis([-10 100 0 13])
set(gca,'XDir','reverse');
% set(gca,'XTick',[0, 12]);


text(90, 12, ['\fontsize{16} \bf {\color{magenta} --- CM}  {\color{blue} --- LR}'])
% for step =1 :4
% text(0, 3*step-0.5, ['t=', num2str(900*step), 's'])
% end
% linear interpolation

% t1 = 1800, 2700, 3600

M =[0, 900, 1800, 2700, 3600, 900, 1800, 2700, 3600];
for i = 1:length(A)    
M(end+1,:) =[i A(i,:), B(i,:)];
end
csvwrite([filename(1:5), '_summary.csv'],M);
end


function g = findGaps(time, gap)
time =[0; time];
gap =[100; gap];

for k=1:3
    if(time(end) < 900*k)
        g(k) = gap(end);
    else
        g(k)= interp1(time, gap, 900*k);
    end
end
g(4) = gap(end);
end