function plot_CG_LR


data = getData();
h1= figure(1);
h2= figure(2);
for i=1:size(data,1)
    if(mod(i,2)==0)
        h =h2;
    else
        h=h1;
    end
    plot_a_sequence(h,  data(i,:));
    
end

end

function plot_a_sequence(h,  arr)

set(0,'CurrentFigure',h);
eps =0.1;

% UBdiff = ResMat(gp,26);

for i=1:2
    xval = arr(1) + 0.15*(-1)^i;
    ci = arr(3*i:3*i+1);
    
    if(mod(i,2)==0)
        line([xval, xval],ci,  'LineWidth',3,'color', 'g'); hold on
    else
        line([xval, xval],ci,  'LineWidth',3,'color', 'b'); hold on
    end
    line([xval-eps, xval+eps],[ci(1) ci(1)],  'LineWidth',3,'color','r'); hold on
    line([xval-eps, xval+eps],[ci(2) ci(2)],        'LineWidth',3,'color','r'); hold on
    line([xval-eps, xval+eps], [arr(3*i-1) arr(3*i-1)],  'LineWidth',3,'color','r'); hold on
    
end

end


function data = getData()
% First 2: LR mean 3-4 LR diff
data =[5	0.080021	0.050982	0.10906	0.093612	0.060181	0.12704
5	0.015017	0.0007211	0.029313	0.015053	-0.0053307	0.035437
6	0.14533	0.11705	0.17361	0.16364	0.13084	0.19645
6	-0.01124	-0.03656	0.014081	-0.023326	-0.034766	-0.011886
7	0.14448	0.11654	0.17243	0.15273	0.12361	0.18184
7	-0.048277	-0.081623	-0.014931	-0.062028	-0.096108	-0.027948
8	0.22862	0.20932	0.24792	0.24237	0.21929	0.26546
8	-0.11903	-0.22269	-0.015376	-0.13051	-0.23754	-0.02348
9	0.20223	0.183	0.22146	0.21289	0.1918	0.23398
9	-0.10914	-0.21413	-0.0041524	-0.12948	-0.23152	-0.027443
10	0.215528	0.199783	0.231273	0.228728	0.20939	0.248067
10	-0.298634	-0.642604	0.0453349	-0.318706	-0.692874	0.055463
11	0.216707	0.200707	0.232707	0.237339	0.221263	0.253416
11	-0.541681	-1.53232	0.448959	-0.622443	-1.70203	0.457147
12	0.217232	0.196222	0.238242	0.228458	0.205798	0.251118
12	-0.337246	NaN	NaN	-0.338592	NaN	NaN
];

end