data <- read.csv('DataSet_CM_LR.csv', sep=',', strip.white = TRUE, header = TRUE)

NoSets <- 15

append.t1.results <- function(nprocessors, colNo){
t.test(data[(1+(i-1)*NoSets):(i*NoSets),colNo])
#	return(t.test(data[1+(i-1)*NoSets:i*NoSets,1]))

}

t1.results <- NULL
for (i in 1:4){append.t1.results(i, 5) }