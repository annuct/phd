
function create_NmCG_plots

filename = 'NormCG.csv';

content = fileread(filename);

[str pos]  =regexp(content,'\n','match');
content = content(pos(2)+1:end);

mineIdx = [7, 10, 5, 6, 8,9, 12,15];
mineLetters = ['A'; 'B'; 'C'; 'D'; 'E'; 'F'; 'G'; 'H' ];

for i=1:length(mineIdx)
    content = regexprep(content, mineLetters(i),num2str(mineIdx(i)));
end

content = regexp(content,'\n','split');

ResMat =[];
for i=1:length(content)
    if(regexp(content{i},'^,')) continue; end
    ResMat(end+1, :) =  str2double(regexp(content{i},',','split'));
end


% No, #itrs, LB, UB, Gap, Time, MasterLB, First	Soln
% Opt1 =    Centralised Complete information sharing between agents
% Opt2 = Decentralised Production information is private
% Opt3 =Decentralised Resource constraint is private but train availability
% is known
% Opt4 = Decentralised Production information and resource constraint are private
% but train availability is known
% Opt5 = Decentralised Resource constraint is private and train availability is unknown
% Opt6 = Decentralised Production information and resource constraint are
% private and train availability is unknown


for i=1:6
    baseIdx = 1+(i-1)*8;
    ResMat(:,end+1) = ResMat(:,baseIdx+4)./ResMat(:,4) ; % POS
    ResMat(:,end+1) = ResMat(:,baseIdx+8)./ResMat(:,4) ; % POA
    ResMat(:,end+1) = ResMat(:,baseIdx+2) ; % Normalised Iterations
    ResMat(:,end+1) = ResMat(:,baseIdx+6); % exe time
    ResMat(:,end+1) = ResMat(:,baseIdx+5); % relative gap
    ResMat(:,end+1) = (ResMat(:,baseIdx+7)-ResMat(:,baseIdx+3))./ResMat(:,baseIdx+3)*100; % LB Gap
    ResMat(:,end) = max(ResMat(:,end), 0);
end


GpingGap=[5,100];
NoGroups = length(GpingGap);

gapIdx=6;

Group ={};

for i=1:NoGroups
    
    if(i>1)
        Group{i} = setdiff(find(ResMat(:,gapIdx) < GpingGap(i)),  find(ResMat(:,gapIdx) < GpingGap(i-1)));
    else
        Group{i} = find(ResMat(:,gapIdx) < GpingGap(i));
    end
end

Group{end+1} = union(Group{1},Group{2});

plot_for_a_group(ResMat, Group{1});
% plot_for_a_group(ResMat, Group{end});

a=4;
end

function plot_for_a_group(ResMat, GP)

Colour = [0 0 0; 176 	23 	31;  0 0 255; 30 144 255;  69 139 116; 200 200 0; 140 50 0; 0  0 0; 128 0 128; ];

NoParm=6;

for c=1:NoParm
    Array = 49 + c + (0:5)*NoParm;    
    switch(c)
        case 1, xstr = 'Price of Stability';
        case 2, xstr = 'Price of Anarchy'; 
        case 3, xstr = 'No of Iterations'; 
        case 4, xstr = 'Execution Time'; 
        case 5, xstr = 'Relative Gap'; 
        case 6, xstr = 'LB Gap'; 
    end   
    
    figure(c); clf;
    legStr={};
    for i=1:length(Array)
        X = sort(ResMat(GP,Array(i)));
        Y = (1:length(X))/length(X);
        plot(X, Y ,'LineWidth',4,'color', Colour(i,:)/255); hold on;
        legStr{i} = ['Opt-',num2str(i)];
    end
    legend(legStr,'Location','SE');
    ylabel('Cumulative Frequency F(x)');
    xlabel(xstr);
    saveas(gcf,[regexprep(lower(xstr),' ', '_'),'_',num2str(length(GP)),'.png']);
    clf;
    [P,ANOVATAB,STATS] =anova1(ResMat(GP, Array),[]);    
    ylabel(xstr);
    saveas(gcf,[regexprep(lower(xstr),' ', '_'),'_anova_',num2str(length(GP)),'.png']);
    delete(gcf);delete(gcf);delete(gcf);
end


end