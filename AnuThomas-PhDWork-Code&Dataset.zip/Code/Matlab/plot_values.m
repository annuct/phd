 data = csvread('110909.csv');
 
 clr =['r','g','b','k','m'];
 leg_str={};
 
 LR_best =[3129300  2985864  6557445 4520373 3556405];

 for k=1:5
     clf;  
      leg_str={};
     st =(k-1)*250;
     for u=1:3                  
         plot(data(st+(u-1)*50+1:st+u*50,3),data(st+(u-1)*50+1:st+u*50,6),'LineWidth',2, 'color', clr(u)); hold on
         leg_str{end+1} = ['gap ', num2str((u-1)*5), '%'];
     end
   
     
     xlabel('Iterations')
     ylabel('TWT');
     title(['DataSet\_0',num2str(k-1)]);
     legend(leg_str);
     
     I = getframe(gcf);
     imwrite(I.cdata, ['DataSet_A',num2str(k-1),'_twt.png']);
     
     
    clf
     leg_str={};
     for u=1:3         
         plot(data(st+(u-1)*50+1:st+u*50,3),data(st+(u-1)*50+1:st+u*50,5),'LineWidth',2, 'color', clr(u)); hold on
         leg_str{end+1} = ['gap ', num2str((u-1)*5), '%'];
     end
     
       plot([0,50], [ LR_best(k),  LR_best(k)],'LineWidth',2, 'color', 'k');
       leg_str{end+1} = 'LR\_best';
     xlabel('Iterations')
     ylabel('Cost');
     title(['DataSet\_0',num2str(k-1)]);
     legend(leg_str);
     
     I = getframe(gcf);
     imwrite(I.cdata, ['DataSet_A',num2str(k-1),'_cost.png']);
 end
 
 
