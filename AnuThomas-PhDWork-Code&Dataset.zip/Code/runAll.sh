
if [ $# -lt 1 ]; then
    echo "Run the script with choice: copy OR jcomp  OR run"  
    exit
fi

if [ $1 == 1 ]; then

sh runDir/scripts/runCRSP.sh run  ./runDir

elif [ $1 == 2 ]; then

sh runDir2/scripts/runCRSP.sh run  ./runDir2

elif [ $1 == 3 ]; then

sh runDir3/scripts/runCRSP.sh run  ./runDir3

elif [ $1 == 4 ]; then

sh runDir11/scripts/runCRSP.sh run  ./runDir11

elif [ $1 == 5 ]; then

sh runDir21/scripts/runCRSP.sh run  ./runDir21

elif [ $1 == 6 ]; then

sh runDir31/scripts/runCRSP.sh run  ./runDir31

elif [ $1 == 11 ]; then

echo running on ONE

sh runDir/scripts/runCRSP.sh run  ./runDir

echo =========== Finished first choice  ==================


sh runDir11/scripts/runCRSP.sh run  ./runDir11

echo =========== Finished second choice  ==================


elif [ $1 == 21 ]; then
echo running on TWO

sh runDir2/scripts/runCRSP.sh run  ./runDir2

echo =========== Finished first choice  ==================


sh runDir21/scripts/runCRSP.sh run  ./runDir21

echo =========== Finished second choice  ==================


elif [ $1 == 31 ]; then
echo running on THREE

sh runDir3/scripts/runCRSP.sh run  ./runDir3

echo =========== Finished first choice  ==================


sh runDir31/scripts/runCRSP.sh run  ./runDir31

echo =========== Finished second choice  ==================

fi

