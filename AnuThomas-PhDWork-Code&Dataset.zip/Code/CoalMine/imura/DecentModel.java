package imura;

import java.text.DecimalFormat;

import ilog.concert.IloException;
import ilog.cplex.IloCplex;
import imura.Mine.MineSol;

public class DecentModel {

	protected Data intData;
	int nMines;
	int nPeriods;
	int nTypes;
	Solution sol;
	//	private HashSet <String> visitedPat= new HashSet <String>();

	public DecentModel(Data d){
		intData = d;
		nMines = d.nMines;
		nPeriods = d.nPeriods;
		nTypes = d.nTypes;
	}

	private void setData(Data din){
		this.intData = din;
	}
	public void solve(IloCplex cplex) throws IloException{
		solve(cplex, 0.0);
	}

	public void solve(IloCplex cplex,  double gap) throws IloException{

		Data data = intData;
		// decentralised model
		RailOpr RO = new RailOpr(true);
		MyUtils Utils = new MyUtils(data.conf.filePrefix);

		int infs_count=0;
		for(int itr=0; itr< data.conf.itrLimit; itr++){

			for(int i=0; i < nMines; i++){
				cplex.clearModel();
				data.mine[i].solveMineProb(cplex, data, gap, 0);
			}
			RO.makeJobs(data);
			if( RO.solveRailProb(cplex, data, itr) < 1e19){
				computeTrAvailAndDelay(data, RO, itr);
				infs_count =0;
			}else{
				infs_count ++;
				if(infs_count>5) return;
				else
					System.out.println("Changing delay with random noise due to infeasibility");
				Mine[]  M = data.mine;			
				for (int i=0; i< nMines; i++) 
					for(int k=0; k < nTypes;k++){
				//		M[i].Delay[k] =  M[i].Delay[k] + (int)Math.round(Math.random());
					}

			}
		}		
	}



	//===========================================================================
	private void computeTrAvailAndDelay(Data data, RailOpr RO, int itr) {

		Mine[]  M = data.mine;
		for(int i=0; i < M.length; i++)
			M[i].TrAvail = new int[nTypes][nPeriods];

		for(int i=0; i < nMines; i++){
			for(int k=0; k < nTypes; k++){
				for (int t =0; t < nPeriods; t++){					
					int train_cnt=0; 
					for(int j=0; j < RO.nJobs; j++){					
						int jTime = RO.Jobs[j].jTime; // journey time
						// && (data.Jobs[j][0] != mIdx)
						if ((t+jTime < RO.Tmax)  && (k == RO.Jobs[j].tIdx)){
							// Particular class of train checked for all other mines+ sufficient time
							train_cnt += (RO.JobSched[j][t+jTime] - RO.JobSched[j][t]); 				}
					}
					if (train_cnt < data.TrClass[k].number)
						M[i].TrAvail[k][t] = 1; //  available
					else 
						M[i].TrAvail[k][t] = 0; // not available
				}
			}
		}

		//--------DELAY---------------------

		for (int i=0; i< nMines; i++) 
			for(int k=0; k < nTypes;k++){
				M[i].Delay[k] =  M[i].Delay[k];
				double sumt=0.0;
				int newcnt=0;
				for(int j=0; j < RO.nJobs; j++){
					if (i== RO.Jobs[j].mIdx && k == RO.Jobs[j].tIdx)	{					
						sumt+= Math.max(0,(RO.Jobs[j].cDate -RO.Jobs[j].dDate)); // find the difference from due date
						newcnt++;
					}
				}
				if (newcnt >= 1)	
					M[i].Delay[k] =  (int)Math.ceil(sumt/newcnt);//	findMedian(delayArr); //
			}		
	}

	//===========================================================================

	public void solveWithLag(IloCplex cplex) throws IloException{

		Data data = intData;
		// decentralised model		
		MyUtils Utils = new MyUtils(data.conf.filePrefix);
		cplex.clearModel();
		Pattern PatObj= new Pattern(data);

		int itrLimit = data.conf.itrLimit;

		double[][][] lambda 	=  new double[nMines][nTypes][nPeriods];
		double[][] S 		=  new double[nTypes][nPeriods];	
		double gamMax		=  data.conf.GAMMA_MAX;
		int  UBimpCntr =0,  LBimpCntr =0;;
		double step= 0.1, cumTime = 0, lam_reset_gap =0;

		initialiseVariables(data, lambda, S);		
		//Initialise solution arrays
		sol = new Solution(itrLimit, data);

		//	PatObj.getInitialPattern(cplex);
		//	PatObj.setNewPattern(PatObj.getBestpattern());	

		Utils.printf("Itr, \tLB,  \tUB, \tGap, \t cTime, \t step, \t Viol","summary.txt");	
		long start = System.currentTimeMillis();
		sol.bestUB = computeUB(cplex, 0, -100 , PatObj); // evaluate with initial pattern	
		printIterationSummary(Utils, step, start, 0);		

		int jump=0;
		for(int itr=1; itr< itrLimit; itr++){
			double newLB=0, actCost=0;
			//LB computation
			int[] newPattern = new int[nMines];

			for(int i=0; i < nMines; i++){
				cplex.clearModel();	
				data.mine[i].msgflag = false;
				data.mine[i].solveMineProb(cplex, data);	
				newPattern[i]= identifyPattern(data, PatObj, i );
				//	sol.setMineSol(data.mine[i]);
				//System.out.println("mine["+i+"].ObjValue = "+data.mine[i].ObjValue);
				newLB += data.mine[i].objcost;
				actCost += data.mine[i].getActualCost();
			}		
			setData(data); // updating internal data

			double[][] delta = computeViolation();	
			// double[] beta = Utils.product(S, delta);
			double penalty = 0; int cumViol=0;

			for(int m=0; m < nTypes; m++)
				for(int t=0; t < nPeriods; t++){
					penalty += lambda[0][m][t]*data.TrClass[m].number;
					cumViol += ( (delta[m][t] < 0)? -1*delta[m][t]: 0);
				}			

			sol.viol[itr] = cumViol;			
			sol.currLB[itr] = newLB-penalty; 					
			PatObj.setNewPattern(newPattern);			
			sol.PatStrArray[itr] = PatObj.makeString(newPattern);	
			sol.currUB[itr] = computeUB(cplex, itr, UBimpCntr, PatObj);
			if(cumViol ==0)
				sol.currUB[itr]=  Math.min(actCost, sol.currUB[itr]);

			if( (itr ==1) && 	((sol.bestUB-newLB)/newLB > 1)){

				// If the upperbound is too high then we may need to start with a smaller step size. 
				// This is invoked only in the first iteration.
				//		step = step /10;
			}

			if (sol.currUB[itr] < sol.bestUB){
				UBimpCntr = 0;
				PatObj.setBestpattern(newPattern);
				sol.bestUB = sol.currUB[itr];
			}
			else 
				UBimpCntr++;			

			if ( (sol.currLB[itr] > sol.bestLB) && sol.viol[itr] > 0){
				LBimpCntr =0;
				sol.bestLB = 100*Math.ceil(sol.currLB[itr]/100);
				step = Math.min(2,step*1.3);				
				sol.setBestLambda(lambda);
			}
			else{
				step = step*0.9;
				LBimpCntr++;
			}

			//Resetting lambda 
			if ( (step < 1e-2) && ( (data.conf.LR_TIME_LIMIT - cumTime) > 300)  && 
					(lam_reset_gap != sol.gap)){
				lambda = sol.getBestLambda();
				System.out.println("Resetting lambda in iteration-"+itr);
				lam_reset_gap = sol.gap;
			}

			if ( (step < 0.5e-2) && ( (data.conf.LR_TIME_LIMIT - cumTime) > 300) ){
				step =2;
				System.out.println("Resetting step to 2-"+itr);		
			}



			System.out.println("Iteration : "+itr+"\t "+ PatObj.makeString(PatObj.getNewpattern())+
					"\t UB* = "+  Math.round(sol.bestUB));

			for(int m=0; m < nTypes; m++){
				double num=0;
				double denom =0;
				for(int t=0; t< nPeriods; t++){
					num += (S[m][t] - delta[m][t])*S[m][t];
					denom += Math.pow((S[m][t] - delta[m][t]), 2);
				}

				double gamOpt = (denom==0? 0: num/denom);
				String strgamma ="";
				if(m==0) strgamma+= "GammaOpt - "+itr+" = [ " + gamOpt;
				if(m==1) strgamma+=",\t " + gamOpt;		
				if(m==2) strgamma+= ",\t " + gamOpt+"] ";

				// System.out.println(strgamma);
				// if(sol.ChoiceArray[itr]==0) gamOpt = 0.1;

				if(LBimpCntr >= 10 && m==0)  { jump =4; LBimpCntr =0;}
				if(jump > 0){
					gamMax =0.9;
					if(m==0) jump--;
				}
				else
					gamMax =0.65;

				gamOpt = ((gamOpt < 0)? gamMax/10.0: Math.min(gamMax, gamOpt));

				if(itr==1) gamOpt = 1;
				//		System.out.println("GammaOpt-"+itr+ " Tau-"+m+" : "+ gamOpt);

				for(int t=0; t< nPeriods; t++){
					S[m][t] = (1-gamOpt)*S[m][t]+ gamOpt*delta[m][t];
					// S[m][t] = gamOpt*S[m][t]+ (1-gamOpt)*delta[m][t];
				}
			}


			cumTime = printIterationSummary(Utils, step, start, itr);


			if ( (step < 1e-3) || 
					(sol.gap < data.conf.LR_GAP_LIMIT) || 
					(cumTime > data.conf.LR_TIME_LIMIT) )
				break;

			//*************Lambda****************************

			double[] normS =  Utils.norm(S); // for each type		

			for(int m=0; m < nTypes; m++){
				if(normS[m]==0) continue;

				for(int t=0; t < nPeriods; t++){
					//	if(t> 0 && delta[m][t] < 0 && delta[m][t-1] >= 0) lastPos = Math.max(0, t-1);
					//	if(t> 0 && delta[m][t] >= 0 && delta[m][t-1] < 0 ) nextPos = t;

					double subTerm = S[m][t]*(sol.bestUB-sol.bestLB)/Math.pow(normS[m],2)*step;
					//	System.out.println("Wedelin \t t="+ t+"\t m="+m+"\t"+ lastPos+"\t"+nextPos);
					for(int i=0; i < nMines; i++){	
						lambda[i][m][t] = Math.max(0, lambda[i][m][t] - subTerm);

						addWedelinPerturbation(data, lambda, delta, m, t, i, LBimpCntr, UBimpCntr);

					} // mine loop					
				}
			}

			for(int m=0; m < nTypes; m++)
				for(int t=0; t < nPeriods; t++){
					int tStart = Math.max(0,t-data.TrClass[m].sTime);
					int tEnd = Math.min(nPeriods-1,t+data.TrClass[m].e_tau);
					for(int i=0; i < nMines; i++){
						double tmp=0;
						for(int t1=tStart; t1< tEnd; t1++)
							tmp += lambda[i][m][t1];
						data.mine[i].orderCost[m][t] = data.mine[i].OC    + tmp;
					}
				}

			Utils.printf("\n\n ##### ITERATION - "+itr+"####\n", "cplex_log.txt");
		}


		System.out.println("Final Pattern =: "+ PatObj.makeString(PatObj.getBestpattern())+" Cost = " + Math.round(sol.bestUB));


	}

	private void addWedelinPerturbation(Data data, double[][][] lambda,
			double[][] delta, int m,  int t, int i, int LBCnter, int UBCntr) {
		//						// System.out.println("Wedelin conflict  m ="+m +"\t t= "+t);
		//						if(lastPos < nextPos) 
		//							System.out.println("\nWedelin + for mine " +"\t"+ lastPos+"\t"+nextPos+"\t"+delta[m][nextPos-1]);
		//						for(int t1 = lastPos; t1 < nextPos ; t1++)
		//							if(data.mine[i].numTrRequests[m][t1] > 0 && delta[m][t1] < 0)
		//							System.out.print(": \t m = " + m+"\t t=" +t1);
		//							    
		// If the mine used the resource at lastPos, then we favour i to use in conflicting period
		if(t ==0) return;		// Default it will be between .1 and .2 %		
		double lowerLimit = 1, range = 1; // multiplied with 0.001

		if( LBCnter < 10 || LBCnter <10 ){
			return; // no wedelin
		}  else if ( LBCnter > 30 && LBCnter >30 ){
			lowerLimit = 5; range = 10;
		}
		else if ( LBCnter > 20 && LBCnter >20 ){
			lowerLimit = 2; range = 5;
		}


		if(delta[m][t] < 0 && delta[m][t-1] >= 0){
			// True means there is a conflict at t and there is no conflict at t-1
			double perturb = 0.001 *(lowerLimit - range*delta[m][t] / (nTypes - data.TrClass[m].number) );	
			MineSol  MS = data.mine[i].getCurrentSolution(); 
			if(MS.noRunningTrains[m][t-1] >0){
				// It was running previously, so favour it
				int t1=t;
				while(MS.noRunningTrains[m][t1] >0){							
					lambda[i][m][t1] *= (1-perturb); // reduce lambda
					t1++;
				}
			} else if(MS.noRunningTrains[m][t] >0){
				// due to this mine conflict occurred. discourage him
				int t1= t;
				while(MS.noRunningTrains[m][t1] >0){							
					lambda[i][m][t1] *= (1+perturb);
					t1++;
				}								
			}
		}
		//	return lastPos;
	}

	private double printIterationSummary(MyUtils Utils, double step, long start, int itr) {

		DecimalFormat twoDec = new DecimalFormat("#.##");
		DecimalFormat fourDec = new DecimalFormat("#.####");

		if(sol.bestLB >0) sol.gap = (sol.bestUB-sol.bestLB)/sol.bestUB;
		else  sol.gap = 1e4;

		double cumTime = (System.currentTimeMillis() - start)/1000;

		Utils.printf(itr+", \t"+twoDec.format(sol.bestLB)+
				",\t "+ twoDec.format(sol.bestUB) +
				",\t "+ twoDec.format(sol.gap*100)+",\t "+ twoDec.format(cumTime) +				
				", \t"+ fourDec.format(step)+
				",\t "+sol.viol[itr],"summary.txt");
		return cumTime;
	}

	private void initialiseVariables(Data data, double[][][] lambda, double[][] S) {	
		for(int m=0; m < nTypes; m++)
			for(int t=0; t < nPeriods; t++){				
				S[m][t] = 0;
				for(int i=0; i < nMines; i++)
					lambda[i][m][t] = 0;
			}
	}


	private void getPattern(Data data, Pattern PatObj){

		int[][] noTrains = { {3, 1, 0}, {4, 0, 2}, {2,0,1}, {1,1,0},{2,2,0}};

		for(int i=0; i < nMines; i++){
			String str = PatObj.makeString(noTrains[i]);				
			for(int j=0; j< PatObj.getList(i).size(); j++ ){
				if(PatObj.getList(i).get(j).equals(str)){
					System.out.println("mine -"+i+" pat = "+ j);				
					break;
				}
			}	
		}
	}

	private int identifyPattern(Data data, Pattern PatObj, int i) throws IloException {
		//Pattern identification
		int out = 0;	
		MineSol MS = data.mine[i].getCurrentSolution();
		String str = PatObj.makeString(MS.TrCombo);				
		for(int j=0; j< PatObj.getList(i).size(); j++ ){
			if(PatObj.getList(i).get(j).equals(str)){
				out = j;				
				break;
			}
		}	
		return out;
	}


	//===========================================================================	
	private double[][] computeViolation() throws IloException{
		Data data = intData;
		MineSol[] MS = new MineSol[nMines];
		for(int i=0; i < nMines; i++)
			MS[i] = data.mine[i].getCurrentSolution();

		double[][] Delta =  new double[nTypes][nPeriods];		
		for(int m=0; m < nTypes; m++)
			for(int t=0; t < nPeriods; t++){
				double sum=0; 
				for(int i=0; i < nMines; i++)
					sum += MS[i].noRunningTrains[m][t]; 				

				Delta[m][t] = (data.TrClass[m].number - sum);				
			}			
		return Delta;
	}
	//===========================================================================
	private double computeUB(IloCplex cplex, int itr, int impCntr, Pattern Pobj) throws IloException{
		double compUB= sol.bestUB;
		Data tData = intData;

		int choice =2;
		int fixX = 1;
		//		if(impCntr >= 50  && itr % 10 ==0 ) {
		//			choice =0;
		//			System.out.println("calling Xt <= tp Model");
		//		}
		// 	if(impCntr > 13  && impCntr < 21) fixX = false;

		// if(itr % 5 !=0 ) return sol.bestUB; 

		MyUtils Utils = new MyUtils(tData.conf.filePrefix);
		sol.ChoiceArray[itr] = choice;		
		RailOpr RO12 = new RailOpr();

		if(itr >0 && choice !=0){ // if itr==0, then Ub will be computed with decentralised rail opr model
			int[] currPat = Pobj.getNewpattern();
			String pat_str = Pobj.makeString(currPat);

			if(fixX==1 ){			
				pat_str += ("--"+ sol.viol[itr]);
				if (sol.evaluatedPatX.contains(pat_str)){			
					System.out.println("Already evaluated pattern (fix X) " + pat_str);
					return sol.bestUB;
				}
				else
					sol.evaluatedPatX.add(pat_str);
			}else{
				// x_t = tp model
				if (sol.evaluatedPat.contains(pat_str)){			
					System.out.println("Already evaluated pattern (Xt=tP) " + pat_str);
					return sol.bestUB;
				}
				else
					sol.evaluatedPat.add(pat_str);
			}
		}

		if (itr == 0){
			return RO12.getInitialSol(tData, cplex);
		}


		tData.resetOrderCost();


		double UB1 = RO12.solveWithPattern(cplex, tData, Pobj, choice, sol.bestUB, fixX);
		return Math.min(UB1, compUB);
	}
}
