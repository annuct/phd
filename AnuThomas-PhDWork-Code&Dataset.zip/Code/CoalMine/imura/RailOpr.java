package imura;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloNumVar;
import ilog.cplex.IloCplex;
import imura.Mine.MineSol;

public class RailOpr {

	int Tmax;
	int nJobs;
	int nTrains;
	int[][] TrAvailability;

	// boolean ch= 1; 
	boolean newRailObj=true;

	Job[]  Jobs;
	int[][] JobSched;
	int[] colArray;
	double ObjVal;
	int objScaling = 100;
	boolean columnFlag = true;
	boolean privateProdInfo = false;
	String summary_str="";

	public RailOpr(boolean privateProdInfo) {
		super();
		this.privateProdInfo = privateProdInfo;
	}

	public RailOpr() {
		super();
		this.privateProdInfo = false;
	}

	public class Job { //Mine class
		int rDate; //holding cost at mine
		int reachTime; // the time in which it is requested from the mines
		int dDate;
		int jTime; // journey time
		int pTime; // processing time
		int lTime; // loading time
		int cDate;// actual completion date 
		int mIdx;// associated mine
		int tIdx;// associated train class	
		int eTau;
		int wgt;
		int idx;
		double vol;
	}



	//================================================================================================================================
	public void makeJobs(Data data){


		MineSol[] MS = new MineSol[data.nMines];
		int jCnt=0; // job counter		
		// int totalDemand=0;
		for (int i=0; i < data.nMines; i++)		{
			MS[i] = data.mine[i].getCurrentSolution();
			for (int t =0; t < data.nPeriods; t++)
				for(int k=0; k < data.nTypes; k++ )
					if (MS[i].TrRequest[k][t]==1)// all are boolean values
						jCnt++ ; 		
			// 		totalDemand += M[i].Order[M[i].Order.length-1];		
		}		

		Jobs =  new Job[jCnt];
		nJobs = jCnt;

		for(int j=0; j < Jobs.length; j++)
			Jobs[j]=  new Job();	


		jCnt=0;
		for (int t =0; t < data.nPeriods; t++)
			for (int i=0; i < data.nMines; i++)	{	

				for(int k=0; k < data.nTypes; k++ )
					if (MS[i].TrRequest[k][t]==1) {
						Jobs[jCnt].reachTime = t;
						Jobs[jCnt].mIdx = i;
						Jobs[jCnt].tIdx = k;
						Jobs[jCnt].rDate =  Math.max(1,t-data.TrClass[Jobs[jCnt].tIdx].sTime); // no jobs before t=1
						Jobs[jCnt].pTime = data.TrClass[k].pTime;
						Jobs[jCnt].lTime = data.TrClass[k].lTime;
						Jobs[jCnt].jTime = data.TrClass[k].g_tau;
						Jobs[jCnt].dDate = Jobs[jCnt].rDate + Jobs[jCnt].jTime ;
						Jobs[jCnt].eTau = data.TrClass[k].lTime +data.TrClass[k].pTime;
						Jobs[jCnt].wgt = 1;
						Jobs[jCnt].idx = jCnt;
						Jobs[jCnt].vol = data.TrClass[k].vol;						
						jCnt++;
					}	
			}
		System.out.println("Number of jobs = "+jCnt);
	}

	public double solveRailProb(IloCplex cplex, Data data) {
		return solveRailProb( cplex,  data, 0);
	}

	//======================================================================================

	public double solveRailProb(IloCplex cplex, Data data, int itr) {

		Tmax			= getTmax(data);	
		MyUtils Utils = new MyUtils(data.conf.filePrefix);
		double out = 1e20;
		if (nJobs==0) return out;
		//	if(data.conf.Model_Choice==45)
		//		decentralised = true;
		try {
			cplex.clearModel();
			IloNumVar[][] Z 	= new IloNumVar[nJobs][];
			IloNumVar[][] Span 	= new IloNumVar[data.nTypes][2];

			for (int j = 0; j < nJobs; j++) 
				Z[j]   = cplex.boolVarArray(Tmax);

			if(newRailObj)
				for(int k=0; k < data.nTypes; k++){
					Span[k] = cplex.numVarArray(2, 0, Tmax);
					Span[k][0].setName("Span_"+k+"_min");
					Span[k][1].setName("Span_"+k+"_max");
				}

			// Pre-computed weighted tardiness coefficient
			double [][] tar_cost =  new double[nJobs][Tmax];		
			double [][] ear_cost =  new double[nJobs][Tmax];
			for (int j=0; j< nJobs; j++ ){
				for(int t=0; t< Tmax; t++){
					Z[j][t].setName("z_"+j+"_"+t);
					tar_cost[j][t] = Jobs[j].wgt*Math.max(0, t- Jobs[j].dDate); 
					ear_cost[j][t] = 2*Jobs[j].wgt*Math.max(0, Jobs[j].dDate-t);
				}
				if(!privateProdInfo) //This is only to get a feasible solution 
					Jobs[j].rDate = Math.max(0, (int)Jobs[j].vol/data.mine[Jobs[j].mIdx].prodCap-Jobs[j].pTime);
			}

			for (int j = 0; j < nJobs; j++)				
				cplex.addEq(Z[j][Tmax-1], 1);			// All jobs must be completed 
			//		cplex.addEq(Z[j][rTime[j]+data.Tmax/3],1);// maximum delay is Tmax/3

			addConstraints_R2_R3_R5_R6(cplex, data, Z);

			IloNumExpr  objtmp = cplex.numExpr();
			//	IloNumExpr  mkSpan = cplex.numExpr();
			for (int j = 0; j < nJobs; j++){
				for (int t = 1; t < Tmax; t++){
					double tmp_cost = tar_cost[j][t];
					if(!privateProdInfo)
						tmp_cost += ear_cost[j][t];
					objtmp = cplex.sum(objtmp, cplex.prod(tmp_cost, cplex.diff(Z[j][t], Z[j][t-1])));					
				}
				//	cplex.addEq(Z[j][Jobs[j].dDate],1).setName("SettingJobs"); //only for the validation
			}

			for(int i=0; i< data.nMines; i++){		
				for(int k =1; k <  data.mine[i].Order.length; k++){
					int time = data.mine[i].dueDate[k];
					IloNumExpr cumDelivery = cplex.numExpr();
					for(Job j : getJobsOfMine(i))
						cumDelivery = cplex.sum(cumDelivery, cplex.prod(Z[j.idx][time], j.vol));
					cplex.addGe(cumDelivery,  data.mine[i].Order[k-1]).setName("Order_"+(k-1)+"_should_be_met_before_"+time);
				}

				if(!privateProdInfo){ // should have sufficient production
					for(int t= 0; t< Tmax; t++ ){
						IloNumExpr cumSupply = cplex.numExpr();
						for(Job j : getJobsOfMine(i))					
							cumSupply = cplex.sum(cumSupply, cplex.prod(Z[j.idx][Math.min(Tmax-1,t+j.eTau)], j.vol));
						cplex.addLe(cumSupply, t*data.mine[i].prodCap).setName("ProdCap_"+i+"_"+t); 
					}
				}
			}

			if(newRailObj){
				//Creating a new objective for the rail operator
				objtmp = cplex.numExpr(); 				
				for(Job j : Jobs){	
					for(int t= 1; t< Tmax; t++ ){
						if(t+j.jTime < Tmax)
							cplex.addLe(Span[j.tIdx][0],  cplex.prod(t, Z[j.idx][t+j.jTime])).setName("span_min_"+j.idx+"_"+t);
						cplex.addLe(cplex.prod(t, cplex.sum(Z[j.idx][t], cplex.prod(-1,Z[j.idx][t-1]))), Span[j.tIdx][1]).setName("span_max_"+j.idx+"_"+t);
					}
				}
				for(int k=0; k< data.nTypes; k++){
					objtmp = cplex.sum(objtmp, cplex.sum(Span[k][1], cplex.prod(-1, Span[k][0]))); // Span_max  --- Span_min
				}

			}else{
				// tardiness^2 or earliness cost etc
			}
			cplex.addMinimize(objtmp); 
			cplex.exportModel("rail_sol.lp");
			if(!Utils.solveAndRecord(cplex,  "Rail"))
				return out;

			ObjVal = cplex.getObjValue();
			Utils.printf("Rail Obj " + ObjVal);
			System.out.println("Rail Obj " + ObjVal);
			summary_str = "DMOUT:: "+nJobs+","+ObjVal ;
			JobSched=  new int[nJobs][Tmax];

			for(int j=0; j < nJobs; j++)
				for(int t=0; t < Tmax; t++)
					JobSched[j][t] =  Math.round( (float) cplex.getValue(Z[j][t]));

			writeOutputs(data.conf.filePrefix);

			readAllSolutions(cplex, data, Z, false);
			out = logMineSolutions(data, Utils, itr, !columnFlag);
			summary_str += " = " +out;
			Utils.printf(summary_str);			
		}
		catch (IloException exc) {
			System.err.println("Concert exception '" + exc + "' caught");			
		}
		return out;
	}

	//=================================================================================================
	private void addConstraints_R2_R3_R5_R6(IloCplex cplex, Data data, IloNumVar[][] Z) throws IloException {


		for(int j=0;  j < Jobs.length; j++){
			for (int t = 1; t < Tmax; t++) {
				if (t < (Jobs[j].rDate+Jobs[j].jTime))
					//R2
					cplex.addEq(Z[j][t], 0).setName("Rel_date_"+j+"_"+t);			// release date constraint
				else //R3
					cplex.addGe(Z[j][t], Z[j][t-1]);		// Once done, stays there
			}
			cplex.addEq(Z[j][0], 0);			// All jobs must be zero at t=0
		}


		//R5
		for (int i=0; i < data.nMines; i++)
			for (int t = 1; t < Tmax; t++) {
				IloNumExpr  tmp = cplex.numExpr();					
				for (int j = 0; j < nJobs; j++) {
					// check whether it is loading R3
					int t1 = t+Jobs[j].pTime+Jobs[j].lTime;						
					if ((Jobs[j].mIdx == i) && ( t1 < Tmax) )
						tmp = cplex.sum(tmp, cplex.diff(Z[j][t1], Z[j][t+Jobs[j].pTime]));						
				}
				//Not more than one job on any mine for loading: R3
				if(!isNumExprEmpty(tmp, cplex)) 
					cplex.addLe(tmp, 1).setName("LoadingRestriction_"+i+"_"+t);				
			}

		//	R6
		for (int k=0; k < data.nTypes; k++)
			for (int t = 0; t < Tmax; t++) {
				IloNumExpr  tmp = cplex.constant(0);
				for (int j = 0; j < nJobs; j++) 
					if ((Jobs[j].tIdx==k) && (t+ Jobs[j].jTime < Tmax) )
						tmp = cplex.sum(tmp, cplex.diff(Z[j][t+Jobs[j].jTime], Z[j][t]));
				//Number of trains with same type is finite
				if(!isNumExprEmpty(tmp, cplex))
					cplex.addLe(tmp, data.TrClass[k].number).setName("ResourceCons_"+k+"_"+t);
			}
	}
	//=================================================================================================

	public int[][][]  makeJobsFromPattern(Data data, Pattern P) throws IloException{

		int[] pat = P.getNewpattern();
		int[][] usedTrs = new int[data.nMines][data.nTypes];
		double[] totSupply = new double [data.nMines];
		int[][][]  JobClass =  new int[data.nMines][data.nTypes][];

		int jCnter=0;
		for (int i=0; i < data.nMines; i++)		{
			totSupply[i] =0;
			usedTrs[i] = P.getIntPattern(i, pat);			
			for(int k=0; k< data.nTypes; k++){
				JobClass[i][k] =  new int[usedTrs[i][k]];
				jCnter += usedTrs[i][k];
				totSupply[i] += usedTrs[i][k]*data.TrClass[k].vol;
			}
		}

		Jobs =  new Job[jCnter];
		nJobs = jCnter;

		for(int j=0; j < Jobs.length; j++)
			Jobs[j]=  new Job();


		jCnter=0;	
		for (int i=0; i < data.nMines; i++)	{			
			for(int m=0; m < data.nTypes; m++ )	{
				for(int u=0; u < usedTrs[i][m]; u++){
					//					System.out.println(" Job "+jCnter+" Mine - "+i+" TrainClass " + k);
					JobClass[i][m][u] = jCnter;
					Jobs[jCnter].mIdx = i;
					Jobs[jCnter].tIdx = m;									
					Jobs[jCnter].rDate = (int)Math.ceil((float)data.TrClass[m].vol/data.mine[i].prodCap)-data.TrClass[m].sTime;  
					Jobs[jCnter].pTime = data.TrClass[m].pTime;
					Jobs[jCnter].lTime = data.TrClass[m].lTime;
					Jobs[jCnter].jTime = data.TrClass[m].g_tau;
					Jobs[jCnter].dDate = Jobs[jCnter].rDate + Jobs[jCnter].jTime ;	
					Jobs[jCnter].eTau = data.TrClass[m].lTime +data.TrClass[m].pTime;
					Jobs[jCnter].wgt = 1; 
					Jobs[jCnter].vol = data.TrClass[m].vol;
					Jobs[jCnter].idx = jCnter;
					jCnter++;
				}
			}	
		}		
		System.out.println("Number of jobs from pattern = "+jCnter);
		return JobClass;
	}


	public void comparePatterns(IloCplex cplex, Data data) throws IloException{
		Pattern patt = new Pattern(data);
		List<int[] > goodPatterns = new ArrayList<int[] >();


		MyUtils utils = new MyUtils(data.conf.filePrefix);

		//P.setBestpattern(P.getRndPattern());
		patt.getInitialPattern(cplex);
		patt.addToVistedList(patt.getBestpattern());

		double bestCost = patt.bestCost/100;

		Random rand = new Random();
		CentModel CM = new CentModel(data);

		for(int i=0; i < 100; i++){
			long start = System.currentTimeMillis();
			int deg = 1+rand.nextInt(3);
			int[] newPat = patt.nbdSearch(deg); 
			patt.setNewPattern(newPat);

			if(!patt.checkPresence(newPat))
				patt.addToVistedList(newPat);
			else
				continue;

			double lowerBound = solveWithPattern(cplex, data, patt, 0, bestCost, 0);			
			if (lowerBound <0 || lowerBound >= bestCost) 
				continue;					 
			double upperBound = solveWithPattern(cplex, data, patt, 1, bestCost, 0);

			int[] arr = new int[newPat.length+2];
			int[] arr_copy = new int[newPat.length];	

			for(int k=2; k< arr.length; k++){
				arr[k] = newPat[k-2];
				arr_copy[k-2] = newPat[k-2];
			}
			goodPatterns.add(arr);			

			if( upperBound < bestCost){
				double newUB = CM.solve(cplex, patt, arr_copy, 0.05, 300, upperBound);
				if( newUB > 0)
					upperBound = newUB;
				System.out.println("286: bestCost = "+ bestCost +" sol from zj-2 "+ newUB);

				bestCost = upperBound;		
				patt.setBestpattern(newPat);
				goodPatterns = cleanUp(goodPatterns, bestCost);
			}

			arr[0] = (int)lowerBound;
			arr[1] = (int)upperBound;
			String str = (int)arr[0]+", \t" + (int)arr[1]+", etime = "+ (System.currentTimeMillis() - start)/1000F +" secs";

			str+=  " itr " + i+" #gP = "+ goodPatterns.size()+"\n";

			System.out.println(str);			
			utils.printf(str,"results.txt");
		}

		goodPatterns = cleanUp(goodPatterns, bestCost);
		String str ="";

		for(int k=0; k < goodPatterns.size(); k++)			
			str += "\n" + makeString(goodPatterns.get(k)) ;

		/*		str += "\n After filtering ";

		for(int k=0; k < goodPatterns.size(); k++){
			int[] tmpArr =  goodPatterns.get(k);

			int[] arr_copy = new int[tmpArr.length-2];				
			for(int k1=0; k1< arr_copy.length; k1++)
				arr_copy[k1] = tmpArr[k1+2];			

			double newUB = solveWithPattern(cplex, data, patt, arr_copy, 2, bestCost);

			//	double newUB = CM.solve(cplex, patt, arr_copy, 0.02, 300, bestCost);
			if( newUB > 0){ 
				bestCost = newUB;
				str += "\n" + makeString(tmpArr) + "\t CM-Cost " + bestCost;
			}
			else{
				System.out.println(" Removing (E) " + makeString(tmpArr));
				goodPatterns.remove(k);	
				k--;
			}
		}
		 */

		System.out.println(str);			
		utils.printf(str,"results.txt");
	}


	private List<int[] > cleanUp(List<int[] > list, double cost){
		for(int k=0; k < list.size(); k++)
			if(list.get(k)[0] > cost ){
				System.out.println(" Removing " + makeString(list.get(k)));
				list.remove(k);	
				k--;
			}
		return list;
	}

	private String makeString(int[] arr){
		String str="";
		for(int k=0; k< arr.length; k++){
			if(k>0 )  str +="-";
			str += (int)arr[k];
		}
		return str;
	}


	// called from main file under choice 8
	public double solveWithPattern(IloCplex cplex, Data data, Pattern P){
		// choice 1 = Xt = tp 
		// choice 0  normal 
		solveWithPattern(cplex, data, P, 2, 0, 0);
		return 0;
	}

	public double solveWithPattern(IloCplex cplex, Data data, Pattern P, 
			int choice, double currBound, int fixX){


		//choice 0: normal xt model
		//choice 1: xt = tp

		int nMines		= data.nMines;
		MyUtils Utils = new MyUtils(data.conf.filePrefix);	
		double out = -124;
		int baseUnit = 400;

		boolean adjustDemand = false;
		boolean costLogging = false;	
		currBound = currBound/objScaling;
		String pat_str="";
		if(data.conf.Model_Choice !=4){ //LR
			pat_str = "Pattern:"+ P.makeString(P.getNewpattern());
			pat_str += "__current UB "+ Math.ceil(currBound) ;
			System.out.println(pat_str);
		}
		try {
			cplex.clearModel();	
			Tmax			=  data.nPeriods;
			int[][][]  JobClass = makeJobsFromPattern(data, P);

			IloNumVar[][] Z 	= new IloNumVar[nJobs][];		
			IloNumVar[][] OS 	= new IloNumVar[nMines][Tmax];
			IloNumVar[][] X 	= new IloNumVar[nMines][Tmax];
			IloNumVar[][] Y 	= new IloNumVar[nMines][];
			IloNumVar[][] cost 	= new IloNumVar[nMines][3];		

			IloNumExpr  objtmp = cplex.numExpr();

			for (Job j : Jobs) {
				Z[j.idx]   = cplex.boolVarArray(Tmax);
				cplex.addEq(Z[j.idx][0], 0);
				for(int t=0; t < Tmax; t++)
					Z[j.idx][t].setName("z_"+j.idx+"_"+t);
			}

			IloNumExpr[] invHoldCost = new IloNumExpr[nMines];

			for(int i=0; i < nMines; i++){
				invHoldCost[i] = cplex.numExpr();
				cost[i] = cplex.numVarArray(3,0, Integer.MAX_VALUE);				
				OS[i] = cplex.numVarArray(Tmax, 0, Integer.MAX_VALUE);
				cplex.addEq(OS[i][0], 0);	

				X[i] = cplex.numVarArray(Tmax, 0, Tmax*data.mine[i].prodCap/baseUnit);
				cplex.addEq(X[i][0], 0);	

				Y[i] =  cplex.intVarArray(Tmax, 0,1);
			}

			for (int j=0; j< nJobs; j++ ){
				for(int t=0; t< Tmax; t++){
					Z[j][t].setName("z_"+j+"_"+t);
				}
			}

			boolean[] extraTrains = checkForExtraTrains(data);
			double[] Overstock = new double[nMines];

			for (int t = 1; t < Tmax; t++) {
				for(int i=0; i < nMines; i++){
					OS[i][t].setName("OS_"+i+"_"+t);
					X[i][t].setName("X_"+i+"_"+t);
					Y[i][t].setName("Y_"+i+"_"+t);

					IloNumExpr cumDelivery = cplex.numExpr();
					IloNumExpr currSupply = cplex.numExpr();
					double totalSupply =0;

					Job[] MineiJobs = getJobsOfMine(i);
					int minEtau = Tmax;
					IloNumExpr cumDeliveryInt = cplex.numExpr();
					double baseVol = MineiJobs[0].vol;
					for (Job j : MineiJobs ){						
						totalSupply += j.vol;
						minEtau = Math.min(minEtau, j.eTau);
						currSupply = cplex.sum(currSupply, cplex.prod(
								cplex.diff(Z[j.idx][cTime(t+j.eTau)],Z[j.idx][cTime(t+j.eTau-1)]), j.vol));
						cumDelivery = cplex.sum(cumDelivery, cplex.prod(Z[j.idx][t], data.TrClass[j.tIdx].vol));
						cumDeliveryInt = cplex.sum(cumDeliveryInt, cplex.prod(Z[j.idx][t], Math.ceil(data.TrClass[j.tIdx].vol/baseVol)));
					} // j loop ends

					if(t==Tmax-1){
						if(adjustDemand)
							Overstock[i] = totalSupply - data.mine[i].Demand[t];
						cplex.addGe(cumDelivery, data.mine[i].Demand[t]);
						if(!extraTrains[i] || choice != 0)
							for (Job j : MineiJobs )
								cplex.addEq(Z[j.idx][Tmax-1], 1).setName("JobCompletion_"+j.idx);			// All jobs must be completed if there is no extra job
					}

					int ordLen = data.mine[i].Order.length;
					double dem_At_t = data.mine[i].Demand[Math.min(data.nPeriods-1, t)];
					if(adjustDemand && !extraTrains[i] && t >= data.mine[i].dueDate[ordLen-1])
						dem_At_t = totalSupply;					

					cplex.addGe(OS[i][t], cplex.diff(cumDelivery, dem_At_t)).setName("OS_defn_"+i+"_"+t);
					objtmp = cplex.sum(objtmp, cplex.prod(OS[i][t], data.mine[i].hCostT));

					//**********************************START********************************************					

					objtmp = addChoiceBasedConstraints(cplex, data, choice, baseUnit, Z, X, objtmp, t, i, currSupply, totalSupply, invHoldCost);

					objtmp = additionalYConstraints(cplex, data, OS, Y, objtmp, t, i, cumDelivery, 
							cumDeliveryInt, baseVol,JobClass, Z, extraTrains, minEtau, P);

					//***************END***************************************************************


				} // i loop
			} // t loop

			//symmetry in same mine 
			for (int j = 0; j < nJobs; j++) {
				if(j >0  && Jobs[j].mIdx == Jobs[j-1].mIdx && Jobs[j].tIdx == Jobs[j-1].tIdx)
					for (int t = 1; t < Tmax; t++) 
						cplex.addLe(Z[j][t], Z[j-1][Math.max(0, t-Jobs[j].lTime)]);

			}

			addConstraints_R2_R3_R5_R6(cplex, data, Z);

			if((data.conf.Model_Choice ==4 || data.conf.Model_Choice ==41)  && choice == 2)			
				fixProduction(X, Y, Z, data, cplex, baseUnit, fixX);


			// ### Fixing a solution
			//	fix_a_solution(cplex, Z);

			/// *****************************************

			objtmp = cplex.sum(objtmp, Jobs.length*100); //order placing cost
			objtmp = cplex.prod(objtmp, 1.0/objScaling);

			IloNumExpr totalOScost = cplex.numExpr();
			IloNumExpr totalDemCost = cplex.numExpr();

			double minInve = 0;
			for(int i=0; i< nMines; i++){		
				IloNumExpr c2 = cplex.numExpr();
				IloNumExpr c3 = cplex.numExpr();
				for(int t=0; t< Tmax; t++){					
					c2 =cplex.sum(c2, cplex.prod(OS[i][t], data.mine[i].hCostT));
					if (data.mine[i].dueDate[0] <= t) 
						c3 =cplex.sum(c3, cplex.prod(Y[i][t], data.mine[i].demCost));										
				}	

				totalOScost = cplex.sum(totalOScost, c2);
				totalDemCost = cplex.sum(totalDemCost, c3);	

				cplex.addEq(cost[i][0], invHoldCost[i]).setName("InvHolding_"+i);

				if(costLogging){				
					cplex.addEq(cost[i][1], c2);
					cplex.addEq(cost[i][2], c3);
				}

				int[] tmpTrSeq = P.getIntPattern(i, P.getNewpattern());
				for(int k=0; k < tmpTrSeq.length; k++){
					int nTP = (int)data.TrClass[k].vol/data.mine[i].prodCap;
					minInve += tmpTrSeq[k]*(nTP*(nTP-1)/2* data.mine[i].prodCap + (data.TrClass[k].vol - nTP*data.mine[i].prodCap)*nTP);					
				}
			}

			//Upperbound on costs
			if(choice== 2 && currBound > 0){				
				currBound  = currBound*objScaling- minInve;	
				cplex.addLe(cplex.sum(totalOScost, totalDemCost), currBound).setName("UB_on_costs"); // this is without scaling
			}

			if((choice ==0 ) && currBound > 0 )
				cplex.addLe(objtmp, currBound).setName("ObjUB");

			cplex.addMinimize(objtmp); // tardiness^2				



			double objCost = currBound;
			int runTime = (choice ==0? 100: 10)*data.nMines;

			runTime  = Math.max(120, runTime);
			cplex.exportModel("Zj_model_"+choice+".lp");
			if( !Utils.solveAndRecord(cplex,  ("RailZj_"+choice),0.0, runTime) ){
				System.out.println("RO with Pattern: bound infeasibility ");
				if(currBound > 0)
					return (currBound*objScaling);
				else
					return -134;
			}

			objCost = cplex.getObjValue();
			Utils.printf("\n \nRail Obj " + objCost);

			if(columnFlag){
				readAllSolutions(cplex, data, Z, true);
				//				for(int i=0; i < data.nMines; i++)
				//					data.mine[i].computeActualCost(this, data);
			}

			out = postOptimisationWorks(cplex, data, choice, adjustDemand, costLogging, 
					Z, cost, extraTrains, Overstock, objCost);


		}
		catch (IloException exc) {
			exc.printStackTrace();
			System.err.println("Concert exception '" + exc + "' caught");			
		}
		return (out*objScaling);
	}



	private IloNumExpr additionalYConstraints(IloCplex cplex, Data data,
			IloNumVar[][] OS, IloNumVar[][] Y, IloNumExpr objtmp, int t, int i,
			IloNumExpr cumDelivery, IloNumExpr cumDeliveryInt, double baseVol,
			int[][][] JobClass, IloNumVar[][] Z, boolean[] extraTrains,   
			int minEtau, Pattern P) throws IloException {

		int[] dueDate = data.mine[i].dueDate;

		for(int k=0; k< dueDate.length; k++){					
			int noTrainsReq = (int)Math.ceil(data.mine[i].Order[k]/baseVol);
			if((k== dueDate.length-1 && t >= dueDate[k]) || (dueDate[k] <= t && t < dueDate[k+1] ))
				cplex.addGe(cumDeliveryInt, cplex.prod(noTrainsReq,cplex.diff(1.0, Y[i][t]))).setName("No_Tr_cuts_"+i+"_"+k+"_"+t);
		}
		objtmp = data.mine[i].addCommonYConstraints(cplex, objtmp, t, cumDelivery, Y[i], 
				OS[i], data.TrClass[data.TrClass.length-1].vol);


		int[] pat = P.getNewpattern();
		int[] usedTrs = P.getIntPattern(i, pat);	
		int[][] choices = P.generateAllChoices(usedTrs);

		for(int kl=1; kl < choices.length; kl++){
			double supply = 0; 
			IloNumExpr mustJob = cplex.numExpr();
			for(int km=0; km < choices[kl].length; km++){
				supply += choices[kl][km] * data.TrClass[km].vol;
				if (choices[kl][km] < usedTrs[km])
					mustJob = cplex.sum(mustJob, Z[JobClass[i][km][choices[kl][km]]][t]);
			}
			double Vmax = data.TrClass[choices[kl].length-1].vol;
			if( (supply < data.mine[i].Demand[t]) && 
					(supply + Vmax >= data.mine[i].Demand[t]) && 
					(!isNumExprEmpty(mustJob, cplex)) )
				cplex.addGe(cplex.sum(mustJob, Y[i][t]), 1).setName("Y_Z_cuts_Ch_"+kl+"_mine_"+i+"_t_"+t);

		}

		return objtmp;
	}


	private void fixProduction(IloNumVar[][] X, IloNumVar[][] Y, IloNumVar[][] Z, Data data, IloCplex cplex,
			int baseUnit, int Xchoice) throws IloException {

		double[][] reqProduction = new double[data.nMines][Tmax];
		for(int i=0; i < data.nMines; i++){
			if(Xchoice==0){
				int maxProd = (int)Math.ceil((data.mine[i].Demand[data.nPeriods-1] + data.TrClass[data.TrClass.length-1].vol)/data.mine[i].prodCap);
				for(int t = 0;  t < Tmax; t++)
					reqProduction[i][t] =  Math.min(t, maxProd)*data.mine[i].prodCap;
			}else{
				MineSol  Msi;
				if(Xchoice==2)
					Msi = data.mine[i].colVector.get(colArray[i]);
				else //expecting Xchoice ==1
					Msi = data.mine[i].getCurrentSolution();

				reqProduction[i][0] = 0;
				for(int t = 1;  t < Tmax; t++)
					reqProduction[i][t] =  reqProduction[i][t-1] + Msi.ProdPlan[t];
			}

			for(int t = 1;  t < Tmax; t++){
				cplex.addEq(cplex.prod(baseUnit, X[i][t]), reqProduction[i][t] );
				if(Xchoice !=0){
					MineSol  Msi;
					if(Xchoice==2)
						Msi = data.mine[i].colVector.get(colArray[i]);
					else //expecting Xchoice ==1
						Msi = data.mine[i].getCurrentSolution();
					if (t > data.mine[i].dueDate[0] && Msi.SolY[t] > 0)	
						cplex.addEq(Y[i][t], 1).setName("fixY_"+i+"_"+t);					
				}

				double baseVol = data.TrClass[0].vol;
				IloNumExpr tmpSum = cplex.numExpr();
				for (Job j : getJobsOfMine(i))	
					tmpSum = cplex.sum(tmpSum, cplex.prod((int)Math.floor(j.vol/baseVol), Z[j.idx][cTime(t+j.eTau)]));

				int noTrainsReq = (int)Math.ceil(reqProduction[i][t]/baseVol);
				cplex.addLe(tmpSum, noTrainsReq).setName("IntCut_on_X_"+i+"_"+t);
			} //t		
		}	// i
	}


	private double postOptimisationWorks(IloCplex cplex, Data data, int choice, boolean adjustDemand, boolean costLogging,
			IloNumVar[][] Z, IloNumVar[][] cost, boolean[] extraTrains, double[] Overstock, double objcost) throws IloException {

		double out = objcost;
		double corrCost = out;
		int nMines = data.nMines;

		try{
			JobSched=  new int[nJobs][Tmax];
			for(int j=0; j < nJobs; j++){
				for(int t=0; t < Tmax; t++){
					JobSched[j][t] =  Math.round( (float) cplex.getValue(Z[j][t]));
				}
			}
			out = objcost;
			writeOutputs(data.conf.filePrefix);			

			if(costLogging){
				for(int i=0;i< nMines; i++){
					System.out.print("\n Mine "+i );							
					for(int t=0; t< 3; t++) 
						System.out.print("\t Cost-"+t+" = "+ Math.round(cplex.getValue(cost[i][t])));
				}
			}	

		} catch(Exception e){
			e.printStackTrace();
			System.out.println("Error in result writing part");
		}

		if(choice > 0){ // if we wanted to compute the corrected inv holding cost
			double[][] InvHolding = new double[nMines][Tmax];			
			for(int i=0; i< data.nMines; i++){
				double[] Prodplan = data.mine[i].createProdPlan(this, data);
				InvHolding[i][0] =0;
				for(int t=1; t< Tmax; t++){
					InvHolding[i][t] = InvHolding[i][t-1]+Prodplan[t];
				}

				for(Job j : getJobsOfMine(i)){
					int time = j.cDate - j.jTime + j.pTime;
					for(int t=time; t< Tmax; t++)
						InvHolding[i][t] -= j.vol;
				}				

				double ttsum=0;
				for(int t=1; t< Tmax; t++){
					ttsum += InvHolding[i][t];
				}
				corrCost = corrCost - Math.round(cplex.getValue(cost[i][0]))/100+ ttsum/100;
			}	
			out= corrCost;	
		}


		// COST verification 
		//		double CMcost = verifyWithCM(cplex, data);	
		//		out = CMcost/objScaling;
		//		System.out.println(" Cost : Zj >> CM "+ CMcost);
		//		for(int i=0; i< data.nMines; i++)
		//			System.out.println(" Mine- "+i +"  "+ cplex.getValue(data.mine[i].MV.ObjVar));			
		//		System.out.println(" Zj = " + Math.round(objcost)+", CorrCost = "+ Math.round(corrCost)+ ", CM = "+ CMcost/100);

		System.out.println(" Zj = " + Math.round(objcost)+", CorrCost = "+ Math.round(corrCost));
		return out;
	}


	private void readAllSolutions(IloCplex cplex, Data data,  IloNumVar[][] Z, boolean chUBM) throws IloException {

		int nMines = data.nMines;		
		int NSols = 1;// cplex.getSolnPoolNsolns();

		for(int u=NSols-1; u >=0 ; u--){
			JobSched=  new int[nJobs][Tmax];
			for(int j=0; j < nJobs; j++){
				for(int t=0; t < Tmax; t++){
					JobSched[j][t] =  Math.round( (float) cplex.getValue(Z[j][t], u));					
					if (t>0 && JobSched[j][t]- JobSched[j][t-1] ==1 )					
						Jobs[j].cDate = t;
				}
			}		

			writeOutputs(data.conf.filePrefix);		
			for(int i=0; i< data.nMines; i++){
				data.mine[i].computeActualCost(this, data);
				//	data.mine[i].checkColumnFeasibility(cplex, data, -1);
			}
		}
	}



	private void fix_a_solution(IloCplex cplex, IloNumVar[][] Z) throws IloException {

		System.out.println("Fixing a solution.....");

		//		cplex.addEq(Z[0][41],1);	cplex.addEq(Z[1][48],1);	cplex.addEq(Z[2][59],1);	cplex.addEq(Z[3][63],1);	cplex.addEq(Z[4][98],1);	cplex.addEq(Z[5][22],1);	cplex.addEq(Z[6][36],1);	cplex.addEq(Z[7][92],1);	cplex.addEq(Z[8][97],1);	cplex.addEq(Z[9][45],1);	cplex.addEq(Z[10][110],1);	cplex.addEq(Z[11][131],1);	cplex.addEq(Z[12][134],1);	cplex.addEq(Z[13][134],1);	cplex.addEq(Z[14][61],1);	cplex.addEq(Z[15][110],1);	cplex.addEq(Z[16][52],1);	cplex.addEq(Z[17][56],1);	cplex.addEq(Z[18][91],1);	cplex.addEq(Z[19][100],1);	cplex.addEq(Z[20][102],1);	cplex.addEq(Z[21][55],1);	cplex.addEq(Z[22][120],1);	cplex.addEq(Z[23][131],1);	cplex.addEq(Z[24][37],1);	cplex.addEq(Z[25][76],1);	cplex.addEq(Z[26][87],1);	cplex.addEq(Z[27][50],1);	cplex.addEq(Z[28][64],1);	cplex.addEq(Z[29][83],1);	cplex.addEq(Z[30][28],1);	cplex.addEq(Z[31][42],1);	cplex.addEq(Z[32][69],1);	cplex.addEq(Z[33][80],1);	cplex.addEq(Z[34][87],1);	cplex.addEq(Z[35][27],1);	cplex.addEq(Z[36][41],1);	cplex.addEq(Z[37][67],1);	cplex.addEq(Z[38][74],1);	cplex.addEq(Z[39][111],1);	cplex.addEq(Z[40][69],1);	cplex.addEq(Z[41][78],1);	cplex.addEq(Z[42][106],1);	cplex.addEq(Z[43][111],1);
		//		cplex.addEq(Z[0][40],0);	cplex.addEq(Z[1][47],0);	cplex.addEq(Z[2][58],0);	cplex.addEq(Z[3][62],0);	cplex.addEq(Z[4][97],0);	cplex.addEq(Z[5][21],0);	cplex.addEq(Z[6][35],0);	cplex.addEq(Z[7][91],0);	cplex.addEq(Z[8][96],0);	cplex.addEq(Z[9][44],0);	cplex.addEq(Z[10][109],0);	cplex.addEq(Z[11][130],0);	cplex.addEq(Z[12][133],0);	cplex.addEq(Z[13][133],0);	cplex.addEq(Z[14][60],0);	cplex.addEq(Z[15][109],0);	cplex.addEq(Z[16][51],0);	cplex.addEq(Z[17][55],0);	cplex.addEq(Z[18][90],0);	cplex.addEq(Z[19][99],0);	cplex.addEq(Z[20][101],0);	cplex.addEq(Z[21][54],0);	cplex.addEq(Z[22][119],0);	cplex.addEq(Z[23][130],0);	cplex.addEq(Z[24][36],0);	cplex.addEq(Z[25][75],0);	cplex.addEq(Z[26][86],0);	cplex.addEq(Z[27][49],0);	cplex.addEq(Z[28][63],0);	cplex.addEq(Z[29][82],0);	cplex.addEq(Z[30][27],0);	cplex.addEq(Z[31][41],0);	cplex.addEq(Z[32][68],0);	cplex.addEq(Z[33][79],0);	cplex.addEq(Z[34][86],0);	cplex.addEq(Z[35][26],0);	cplex.addEq(Z[36][40],0);	cplex.addEq(Z[37][66],0);	cplex.addEq(Z[38][73],0);	cplex.addEq(Z[39][110],0);	cplex.addEq(Z[40][68],0);	cplex.addEq(Z[41][77],0);	cplex.addEq(Z[42][105],0);	cplex.addEq(Z[43][110],0);

		//		cplex.addEq(Z[0][20],1);	cplex.addEq(Z[1][21],1);	cplex.addEq(Z[2][29],1);	cplex.addEq(Z[3][37],1);	cplex.addEq(Z[4][96],1);	cplex.addEq(Z[5][52],1);	cplex.addEq(Z[6][66],1);	cplex.addEq(Z[7][94],1);	cplex.addEq(Z[8][106],1);	cplex.addEq(Z[9][43],1);	cplex.addEq(Z[10][109],1);	cplex.addEq(Z[11][110],1);	cplex.addEq(Z[12][134],1);	cplex.addEq(Z[13][120],1);	cplex.addEq(Z[14][46],1);	cplex.addEq(Z[15][134],1);	cplex.addEq(Z[16][99],1);	cplex.addEq(Z[17][115],1);	cplex.addEq(Z[18][123],1);	cplex.addEq(Z[19][130],1);	cplex.addEq(Z[20][131],1);	cplex.addEq(Z[21][38],1);	cplex.addEq(Z[22][50],1);	cplex.addEq(Z[23][134],1);	cplex.addEq(Z[24][41],1);	cplex.addEq(Z[25][76],1);	cplex.addEq(Z[26][77],1);	cplex.addEq(Z[27][22],1);	cplex.addEq(Z[28][36],1);	cplex.addEq(Z[29][92],1);	cplex.addEq(Z[30][63],1);	cplex.addEq(Z[31][31],1);	cplex.addEq(Z[32][42],1);	cplex.addEq(Z[33][86],1);	cplex.addEq(Z[34][87],1);	cplex.addEq(Z[35][24],1);	cplex.addEq(Z[36][78],1);	cplex.addEq(Z[37][61],1);	cplex.addEq(Z[38][74],1);	cplex.addEq(Z[39][104],1);	cplex.addEq(Z[40][64],1);	cplex.addEq(Z[41][80],1);	cplex.addEq(Z[42][108],1);	cplex.addEq(Z[43][122],1);
		//		cplex.addEq(Z[0][19],0);	cplex.addEq(Z[1][20],0);	cplex.addEq(Z[2][28],0);	cplex.addEq(Z[3][36],0);	cplex.addEq(Z[4][95],0);	cplex.addEq(Z[5][51],0);	cplex.addEq(Z[6][65],0);	cplex.addEq(Z[7][93],0);	cplex.addEq(Z[8][105],0);	cplex.addEq(Z[9][42],0);	cplex.addEq(Z[10][108],0);	cplex.addEq(Z[11][109],0);	cplex.addEq(Z[12][133],0);	cplex.addEq(Z[13][119],0);	cplex.addEq(Z[14][45],0);	cplex.addEq(Z[15][133],0);	cplex.addEq(Z[16][98],0);	cplex.addEq(Z[17][114],0);	cplex.addEq(Z[18][122],0);	cplex.addEq(Z[19][129],0);	cplex.addEq(Z[20][130],0);	cplex.addEq(Z[21][37],0);	cplex.addEq(Z[22][49],0);	cplex.addEq(Z[23][133],0);	cplex.addEq(Z[24][40],0);	cplex.addEq(Z[25][75],0);	cplex.addEq(Z[26][76],0);	cplex.addEq(Z[27][21],0);	cplex.addEq(Z[28][35],0);	cplex.addEq(Z[29][91],0);	cplex.addEq(Z[30][62],0);	cplex.addEq(Z[31][30],0);	cplex.addEq(Z[32][41],0);	cplex.addEq(Z[33][85],0);	cplex.addEq(Z[34][86],0);	cplex.addEq(Z[35][23],0);	cplex.addEq(Z[36][77],0);	cplex.addEq(Z[37][60],0);	cplex.addEq(Z[38][73],0);	cplex.addEq(Z[39][103],0);	cplex.addEq(Z[40][63],0);	cplex.addEq(Z[41][79],0);	cplex.addEq(Z[42][107],0);	cplex.addEq(Z[43][121],0);



		//P7
		//			cplex.addEq(Z[0][75],1);	cplex.addEq(Z[1][97],1);	cplex.addEq(Z[3][50],1);	cplex.addEq(Z[4][63],1);	cplex.addEq(Z[5][42],1);	cplex.addEq(Z[6][53],1);	cplex.addEq(Z[7][64],1);	cplex.addEq(Z[8][119],1);	cplex.addEq(Z[9][130],1);	cplex.addEq(Z[10][64],1);	cplex.addEq(Z[11][97],1);	cplex.addEq(Z[12][99],1);		cplex.addEq(Z[14][32],1);	cplex.addEq(Z[15][86],1);	cplex.addEq(Z[16][149],0);		cplex.addEq(Z[18][49],1);	cplex.addEq(Z[19][60],1);	cplex.addEq(Z[20][115],1);	cplex.addEq(Z[21][36],1);	cplex.addEq(Z[22][44],1);	cplex.addEq(Z[23][81],1);	cplex.addEq(Z[24][108],1);		cplex.addEq(Z[26][112],1);	cplex.addEq(Z[27][57],1);		cplex.addEq(Z[29][41],1);	cplex.addEq(Z[30][48],1);
		//			cplex.addEq(Z[0][74],0);	cplex.addEq(Z[1][96],0);		cplex.addEq(Z[3][49],0);	cplex.addEq(Z[4][62],0);	cplex.addEq(Z[5][41],0);	cplex.addEq(Z[6][52],0);	cplex.addEq(Z[7][63],0);	cplex.addEq(Z[8][118],0);	cplex.addEq(Z[9][129],0);	cplex.addEq(Z[10][63],0);	cplex.addEq(Z[11][96],0);	cplex.addEq(Z[12][98],0);		cplex.addEq(Z[14][31],0);	cplex.addEq(Z[15][85],0);			cplex.addEq(Z[18][48],0);	cplex.addEq(Z[19][59],0);	cplex.addEq(Z[20][114],0);	cplex.addEq(Z[21][35],0);	cplex.addEq(Z[22][43],0);	cplex.addEq(Z[23][80],0);	cplex.addEq(Z[24][107],0);		cplex.addEq(Z[26][111],0);	cplex.addEq(Z[27][56],0);		cplex.addEq(Z[29][40],0);	cplex.addEq(Z[30][47],0);


		//p8			
		//			cplex.addEq(Z[0][84],1);	cplex.addEq(Z[1][95],1);	cplex.addEq(Z[2][59],1);	cplex.addEq(Z[3][64],1);	cplex.addEq(Z[4][40],1);	cplex.addEq(Z[5][62],1);	cplex.addEq(Z[6][73],1);	cplex.addEq(Z[7][117],1);	cplex.addEq(Z[8][128],1);		cplex.addEq(Z[10][73],1);	cplex.addEq(Z[11][22],1);	cplex.addEq(Z[12][36],1);	cplex.addEq(Z[13][97],1);	cplex.addEq(Z[14][99],1);			cplex.addEq(Z[17][50],1);	cplex.addEq(Z[18][113],1);	cplex.addEq(Z[19][115],1);	cplex.addEq(Z[20][60],1);	cplex.addEq(Z[21][30],1);	cplex.addEq(Z[22][44],1);	cplex.addEq(Z[23][81],1);	cplex.addEq(Z[24][80],1);	cplex.addEq(Z[25][29],1);	cplex.addEq(Z[26][51],1);	cplex.addEq(Z[27][106],1);		cplex.addEq(Z[29][112],1);	cplex.addEq(Z[30][46],1);	cplex.addEq(Z[31][48],1);
		//			cplex.addEq(Z[0][83],0);	cplex.addEq(Z[1][94],0);	cplex.addEq(Z[2][58],0);	cplex.addEq(Z[3][63],0);	cplex.addEq(Z[4][39],0);	cplex.addEq(Z[5][61],0);	cplex.addEq(Z[6][72],0);	cplex.addEq(Z[7][116],0);	cplex.addEq(Z[8][127],0);		cplex.addEq(Z[10][72],0);	cplex.addEq(Z[11][21],0);	cplex.addEq(Z[12][35],0);	cplex.addEq(Z[13][96],0);	cplex.addEq(Z[14][98],0);			cplex.addEq(Z[17][49],0);	cplex.addEq(Z[18][112],0);	cplex.addEq(Z[19][114],0);	cplex.addEq(Z[20][59],0);	cplex.addEq(Z[21][29],0);	cplex.addEq(Z[22][43],0);	cplex.addEq(Z[23][80],0);	cplex.addEq(Z[24][79],0);	cplex.addEq(Z[25][28],0);	cplex.addEq(Z[26][50],0);	cplex.addEq(Z[27][105],0);		cplex.addEq(Z[29][111],0);	cplex.addEq(Z[30][45],0);	cplex.addEq(Z[31][47],0);


		//
		//			//P8
		//			cplex.addEq(Z[0][91],1);	cplex.addEq(Z[1][102],1);	cplex.addEq(Z[2][61],1);	cplex.addEq(Z[3][63],1);	cplex.addEq(Z[4][58],1);	cplex.addEq(Z[5][69],1);	cplex.addEq(Z[6][80],1);	cplex.addEq(Z[7][124],1);	cplex.addEq(Z[8][135],1);	cplex.addEq(Z[9][149],1);	cplex.addEq(Z[10][75],1);	cplex.addEq(Z[11][33],1);	cplex.addEq(Z[12][35],1);	cplex.addEq(Z[13][97],1);	cplex.addEq(Z[14][99],1);	cplex.addEq(Z[15][14],1);	cplex.addEq(Z[16][36],1);	cplex.addEq(Z[17][113],1);	cplex.addEq(Z[18][115],1);	cplex.addEq(Z[19][149],1);	cplex.addEq(Z[20][60],1);	cplex.addEq(Z[21][47],1);	cplex.addEq(Z[22][49],1);	cplex.addEq(Z[23][81],1);	cplex.addEq(Z[24][80],1);	cplex.addEq(Z[25][25],1);	cplex.addEq(Z[26][47],1);	cplex.addEq(Z[27][113],1);	cplex.addEq(Z[28][149],1);	cplex.addEq(Z[29][112],1);	cplex.addEq(Z[30][46],1);	cplex.addEq(Z[31][48],1);
		//			cplex.addEq(Z[0][90],0);	cplex.addEq(Z[1][101],0);	cplex.addEq(Z[2][60],0);	cplex.addEq(Z[3][62],0);	cplex.addEq(Z[4][57],0);	cplex.addEq(Z[5][68],0);	cplex.addEq(Z[6][79],0);	cplex.addEq(Z[7][123],0);	cplex.addEq(Z[8][134],0);	cplex.addEq(Z[9][148],0);	cplex.addEq(Z[10][74],0);	cplex.addEq(Z[11][32],0);	cplex.addEq(Z[12][34],0);	cplex.addEq(Z[13][96],0);	cplex.addEq(Z[14][98],0);	cplex.addEq(Z[15][13],0);	cplex.addEq(Z[16][35],0);	cplex.addEq(Z[17][112],0);	cplex.addEq(Z[18][114],0);	cplex.addEq(Z[19][148],0);	cplex.addEq(Z[20][59],0);	cplex.addEq(Z[21][46],0);	cplex.addEq(Z[22][48],0);	cplex.addEq(Z[23][80],0);	cplex.addEq(Z[24][79],0);	cplex.addEq(Z[25][24],0);	cplex.addEq(Z[26][46],0);	cplex.addEq(Z[27][112],0);	cplex.addEq(Z[28][148],0);	cplex.addEq(Z[29][111],0);	cplex.addEq(Z[30][45],0);	cplex.addEq(Z[31][47],0);



		//			//optimal			
		cplex.addEq(Z[0][63],1);	cplex.addEq(Z[1][97],1);	cplex.addEq(Z[2][63],1);	cplex.addEq(Z[3][128],1);	cplex.addEq(Z[4][64],1);	cplex.addEq(Z[5][128],1);	cplex.addEq(Z[6][63],1);	cplex.addEq(Z[7][85],1);	cplex.addEq(Z[8][99],1);	cplex.addEq(Z[9][36],1);	cplex.addEq(Z[10][115],1);	cplex.addEq(Z[11][60],1);	cplex.addEq(Z[12][47],1);	cplex.addEq(Z[13][115],1);	cplex.addEq(Z[14][37],1);	cplex.addEq(Z[15][81],1);	cplex.addEq(Z[16][44],1);	cplex.addEq(Z[17][81],1);	cplex.addEq(Z[18][104],1);	cplex.addEq(Z[19][112],1);	cplex.addEq(Z[20][57],1);	cplex.addEq(Z[21][48],1);	cplex.addEq(Z[22][46],1);	cplex.addEq(Z[23][48],1);
		cplex.addEq(Z[0][62],0);	cplex.addEq(Z[1][96],0);	cplex.addEq(Z[2][62],0); cplex.addEq(Z[3][127],0);	cplex.addEq(Z[4][63],0);	cplex.addEq(Z[5][127],0);	cplex.addEq(Z[6][62],0);	cplex.addEq(Z[7][84],0);	cplex.addEq(Z[8][98],0);	cplex.addEq(Z[9][35],0);	cplex.addEq(Z[10][114],0);	cplex.addEq(Z[11][59],0);	cplex.addEq(Z[12][46],0);	cplex.addEq(Z[13][114],0);	cplex.addEq(Z[14][36],0);	cplex.addEq(Z[15][80],0);	cplex.addEq(Z[16][43],0);	cplex.addEq(Z[17][80],0);	cplex.addEq(Z[18][103],0);	cplex.addEq(Z[19][111],0);	cplex.addEq(Z[20][56],0);	cplex.addEq(Z[21][47],0);	cplex.addEq(Z[22][45],0);	cplex.addEq(Z[23][47],0);
	}



	private boolean[] checkForExtraTrains(Data data) {
		// TODO Auto-generated method stub
		boolean[] out = new boolean[data.nMines];

		for(int i=0; i< data.nMines; i++){
			Job[] MineiJobs = getJobsOfMine(i);		
			out[i] = false;

			double totalSupply =0.0;
			for (Job j : MineiJobs )						
				totalSupply += j.vol;

			double demand = data.mine[i].Demand[data.nPeriods-1];		
			for(int k=0; k < data.nTypes-1; k++)
				if (totalSupply - data.TrClass[k].vol >= demand){
					out[i] = true;
					break;
				}
		}
		return out;
	}



	public Job[] getJobsOfMine( int i) {
		// TODO Auto-generated method stub
		int cnt=0;
		for(int j=0; j < Jobs.length; j++)
			if(Jobs[j].mIdx ==i){
				//	out[cnt] = j;
				cnt ++;
			}
		Job[] out = new Job[cnt];

		cnt=0;
		for(int j=0; j < Jobs.length; j++)
			if(Jobs[j].mIdx ==i){
				out[cnt] = Jobs[j];
				cnt ++;
			}		
		return out;
	}



	private IloNumExpr addChoiceBasedConstraints(IloCplex cplex, Data data, int choice, int baseUnit, IloNumVar[][] Z,  
			IloNumVar[][] X, IloNumExpr objtmp, int t, int i,
			IloNumExpr currSupply, double totalSupply, IloNumExpr[] invHoldCost) throws IloException {

		int prodPerPeriod =  data.mine[i].prodCap/baseUnit;

		IloNumExpr reqProduction = cplex.numExpr();
		IloNumExpr[] tmpsumArr = new IloNumExpr[4];
		for(int f=0; f < tmpsumArr.length; f++)
			tmpsumArr[f] = cplex.numExpr();
		int minDays = Tmax;			

		Job[] MineiJobs = getJobsOfMine(i);

		for (Job j: MineiJobs ){				
			reqProduction   = cplex.sum(reqProduction, cplex.prod(Z[j.idx][cTime(t+j.eTau)], j.vol));

			int arrTime = t+j.eTau;
			double unitsRequired = (j.vol/baseUnit);
			minDays = (int)Math.min(minDays, Math.floor(unitsRequired/prodPerPeriod));	

			for(int f=0; f < tmpsumArr.length; f++){
				if(unitsRequired-f*prodPerPeriod <= 0 ) break;
				tmpsumArr[f] = cplex.sum(tmpsumArr[f], cplex.prod(unitsRequired-f*prodPerPeriod, Z[j.idx][cTime(arrTime)]),
						cplex.prod(f*prodPerPeriod, Z[j.idx][Math.max(0, cTime(arrTime)-f)]));
			}
		} // j loop ends

		cplex.addGe(cplex.prod(X[i][t], baseUnit), reqProduction).setName("ProdConstraint_"+i+"_"+t);
		cplex.addGe(X[i][t], X[i][t-1]);	

		if(choice==1){ // Xt = tp model
			cplex.addEq(X[i][t], t*prodPerPeriod).setName("ProdEvryTime_"+i+"_"+t);
		} else if(choice==0){// choice ==0 
			cplex.addLe(cplex.diff(X[i][t], X[i][t-1]), prodPerPeriod).setName("MaxProd_"+i+"_"+t);		
			cplex.addLe(X[i][t], Math.min((int)totalSupply/baseUnit+1, prodPerPeriod*t));

			for(int f=0; f < tmpsumArr.length; f++){
				if(!isNumExprEmpty(tmpsumArr[f], cplex))
					cplex.addLe(tmpsumArr[f], X[i][Math.max(0,t-f)]).setName("minProd_cons_f_"+f+"_t_"+t);							
			}
		}		
		objtmp = cplex.sum(objtmp, cplex.diff(cplex.prod(X[i][t],baseUnit), reqProduction));
		invHoldCost[i] = cplex.sum(invHoldCost[i], cplex.diff(cplex.prod(X[i][t],baseUnit), reqProduction) ) ;

		return objtmp;
	}


	private double verifyWithCM(IloCplex cplex, Data data) throws IloException {
		IloNumExpr objtmp;
		int cnt;
		double out;		
		cplex.clearModel();
		data.resetOrderCost();

		objtmp = cplex.numExpr();
		//LOOPING OVER ALL MINES and adding constraints
		for(int i=0; i < data.nMines; i++){
			data.mine[i].relax = false;
			data.mine[i].addConstraints(data, cplex);
			objtmp = cplex.sum(objtmp, data.mine[i].MV.ObjVar);
		}

		for(int i=0; i < data.nMines; i++)
			for(int m=0; m < data.nTypes; m++){
				cnt=1;
				for(int t=0; t< Tmax; t++) {
					for(int j=0; j < Jobs.length; j++){
						if( i == Jobs[j].mIdx &&  m == Jobs[j].tIdx && 		
								(t== Jobs[j].cDate-Jobs[j].jTime+Jobs[j].pTime) ){
							cplex.addEq(data.mine[i].MV.AQty[m][t], cnt);
							cplex.addEq(data.mine[i].MV.AQty[m][t-1], cnt-1);
							cnt++;
						}							
					}					
				}
			}
		cplex.addMinimize(objtmp);
		cplex.exportModel("rail_cent.lp");
		cplex.solve();
		cplex.writeMIPStart("cent_best.mst");
		out = cplex.getObjValue();
		return out;
	}


	private boolean isNumExprEmpty(IloNumExpr expr, IloCplex cp) throws IloException {
		// TODO Auto-generated method stub		
		return expr.getClass().toString().equals(cp.numExpr().getClass().toString());
	}

	private int cTime(int t){
		return Math.min(Tmax-1, Math.max(0, t));
	}

	//============================================================
	public void writeOutputs(String filePrefix){

		MyUtils Utils = new MyUtils(filePrefix);
		int nJobs = Jobs.length;

		//		for (int j=0; j < nJobs; j++){
		//			for(int t=1; t < Tmax; t++){
		//				if (JobSched[j][t]- JobSched[j][t-1] ==1 ){
		//			//		Jobs[j].cDate =	t;		// completion time 	
		//					break;
		//				}
		//			}			
		//		}

		String outStr="\nJob";
		for (int j=0; j < nJobs; j++)
			outStr +=","+j;	
		outStr +="\nMine";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ Jobs[j].mIdx;		
		outStr +="\nTrain";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ Jobs[j].tIdx;		
		outStr +="\nReady";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ Jobs[j].rDate;	
		outStr +="\nReach(AQ)";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ (Jobs[j].cDate - Jobs[j].jTime+Jobs[j].pTime);	
		outStr +="\nDue";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ Jobs[j].dDate;
		outStr +="\nCompletion";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ Jobs[j].cDate;

		Utils.printf(outStr);		
	}


	private int getTmax(Data data){		
		int Tmax = data.nPeriods;
		//		Job[] tempJ = new Job[Jobs.length] ;
		//		for(int j=0; j < Jobs.length; j++){
		//			tempJ[j] =  Jobs[j];
		//		}
		//
		//		for(int j=0; j < Jobs.length; j++){
		//			for(int t= Jobs[j].dDate; t < data.nPeriods*data.nMines ; t++){
		//				if (checkAvailability(data, tempJ, j, t)){
		//					tempJ[j].cDate = t;
		//					//	System.out.print("\t ["+ j+", "+ t+"] ");
		//					Tmax = Math.max(Tmax, t+1);
		//					break;
		//				}
		//			}
		//		}
		//		//	System.out.println("Tmax = "+ Tmax);
		return Tmax;
	}


	//===========================================================================

	private boolean checkAvailability(Data data, Job[] J, int idx, int time) {

		int[] nActiveTrains = new int[time+1];
		for(int t=0; t < nActiveTrains.length; t++)
			nActiveTrains[t] =0;

		int trType = J[idx].tIdx;
		int jrTime = data.TrClass[trType].g_tau; 
		int N = data.TrClass[trType].number; 

		for(int j=0; j< idx; j++){
			for(int t=0; t <= time; t++)
				if (J[j].tIdx == trType)
					if (J[j].cDate == t)
						for(int t1= Math.max(0, t - jrTime); t1 <t; t1++)
							nActiveTrains[t1]++;
		}	
		if(time < jrTime)
			System.out.println(" error ");
		return (nActiveTrains[time-jrTime] < N );
	}

	//===========================================================================
	public Job Job() {
		// TODO Auto-generated method stub
		return new Job();
	}

	public double getInitialSol(Data tData, IloCplex cplex) throws IloException{
		return getInitialSol(tData, cplex, null);
	}

	public double getInitialSol(Data tData, IloCplex cplex, Pattern PObj) throws IloException{	
		int[] BP = null;
		if (PObj != null)
			BP = PObj.getBestpattern();

		for(int i=0; i < tData.nMines; i++){
			cplex.clearModel();	
			tData.mine[i].msgflag = false;
			if(PObj == null){
				tData.mine[i].solveMineProb(cplex, tData);
				if(columnFlag) tData.mine[i].addColumnAndValue(0);// .addAllColumns(cplex, tData);
			}
			else{			
				int[] TrCombo =  PObj.getIntPattern(i, BP);
				tData.mine[i].solveMineProb(cplex, tData, TrCombo);
			}
		}

		makeJobs(tData);
		solveRailProb(cplex, tData);
		tData.resetOrderCost();		

		double out = logMineSolutions(tData, null, -1); 
		//	addColumnToMine(tData, (int)Math.round(cplex.getObjValue()), 0);		
		return  out;		
	}

	public double logMineSolutions(Data data, MyUtils Utils, int itr) {
		return logMineSolutions(data, Utils, itr, true);
	}

	public double logMineSolutions(Data data, MyUtils Utils, int itr, boolean flag) {
		//*************Logging****************************	
		String newStr ="Mine, Obj, ActCost";
		double[] sum1 = new double[3];
		String solstr ="";
		for(int i=0; i < data.nMines; i++){
			if(itr==-1) data.mine[i].computeActualCost(this, data);
			double c1 = data.mine[i].objcost;
			double c2 = data.mine[i].getActualCost();
			solstr += ("\n"+ data.mine[i].getMineSolnString(-10));
			newStr += "\n"+i+", "+Math.round(c1)+", "+ Math.round(c2);
			sum1[0] += c1;
			sum1[1] += c2;
			sum1[2] += (c2*data.mine[i].getBaseValue());
			summary_str += (i==0? "," : "+") + c2;
		}
		newStr += "\n-------- Itr: "+itr+" --------------------------"+
				"\nTotal = "+", "+Math.round(sum1[0])+", "+ Math.round(sum1[1])+
				"\nRailOpr = "+ObjVal+
				"\n----------------------------------\n";
		if(flag && Utils != null)
			Utils.printf(newStr,"summary.txt");
		if(Utils != null){
			solstr = "From the rail operator : Total sys cost ="+Math.round(sum1[2]) +solstr;
			Utils.printf(solstr,"solutions.txt");
		}

		//***********************************************
		return sum1[1]; //actual cost
	}
}
