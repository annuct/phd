package imura;

import ilog.concert.*;
import ilog.cplex.*;


import imura.Data.Train;

public class CentModel {

	Data intData;
	boolean relax = false;
	double scaling =100;
	boolean writeMST = false;

	boolean mstFlag = false;

	public CentModel(Data d){
		intData = d;
	}
	double solve(IloCplex cplex) {
		return solve(cplex, 0, 0);
	}

	public double solve(IloCplex cplex,double gap, int time) {	
		return solve(cplex, null, null, gap, time);
	}
	public double solve(IloCplex cplex, double gap, int time, double currUB) {	
		return solve(cplex, null, null, gap, time, currUB);
	}
	public double solve(IloCplex cplex, Pattern P, int[] Pat, double gap, int time){
		return solve(cplex, P, Pat, gap, time, 0);
	}
	//====================================================================
	public double solve(IloCplex cplex, Pattern P, int[] Pat, double gap, int time, double currUB) {		

		Data data = intData;
		int nMines 		= data.nMines;
		Mine[]  mine 	= data.mine;	
		int nTypes      = data.nTypes;
		String fname = "cent_best.mst";

		boolean dummyFlag = ((data.TrClass[0].vol < 1)?  true: false);

		//	int[] ObjValues = {308800, 312600, 223500,379700, 471200, 315300, 287700};
		//	int[] ObjValues = {1055300,  767100, 646000,  954600, 1735500,  971500,  2429600}; //p4

		double[] ObjValues = null;
		if (Pat != null)
			ObjValues = getObjLowerBounds(data, P, Pat);

		int CentModelLB=0; 

		MyUtils Utils = new MyUtils(data.conf.filePrefix);


		if ((Pat != null) && (!P.validate(Pat)))
			return -101;

		if (Pat != null)
			for(int i=0; i < nMines; i++){
				CentModelLB += Math.round(ObjValues[i]);
				// System.out.println(" cm obj  "+ CentModelLB);
			}

		if ((Pat != null) &&  (P.bestCost < CentModelLB))
			return P.bestCost;

		// VARIABLE INITIALIZATION
		try {
			Utils.resetCplexParameters(cplex);
			IloNumVar newObj = createBasicModel(cplex, data, CentModelLB);

			if(Pat != null){
				for(int i=0; i < nMines; i++)			
					cplex.addGe(mine[i].MV.ObjVar, ObjValues[i]).setName("Ind_LB_"+i);
				System.out.println("Cost of unconstrained problem = "+ CentModelLB);
				System.out.println("Pattern " + P.makeString(Pat) );
			}

			if(dummyFlag){
				for(int t=1; t< data.nPeriods-1; t++){
					IloNumExpr sumTrains = cplex.numExpr();
					for (int i=0; i < data.nMines; i++)
						for(int m=0; m < nTypes; m++)
							sumTrains = cplex.sum(sumTrains, cplex.diff(mine[i].MV.AQty[m][t], mine[i].MV.AQty[m][t-1]));
					cplex.addLe(sumTrains, data.nMines).setName("NewConst");		
				}
			}

			//**************************
			if (Pat != null) {
				P.addConstraints(cplex, Pat);			
				cplex.addLe(newObj, P.bestCost/scaling);
			}
			//*****************************************


			if(currUB > 0){
				currUB = Math.ceil(currUB);
				cplex.addLe(newObj,currUB);
				System.out.println("Given upperbound = " + currUB);
			}


			//	cplex.exportModel("centralised_model.lp");

			if(mstFlag) {			
				System.out.println("looking for MST file");
				try{
					cplex.readMIPStart(fname);
					//					cplex.setParam(IloCplex.IntParam.IntSolLim, 3);
				}catch(Exception e){
					System.out.println("could not find MST file");
				}
			}

			if (!Utils.solveAndRecord(cplex, "center", gap, time)){
				Utils.printf("Could not solve ");
				System.out.printf("Could not solve CM: 159 ");
				return -100;
			}


			if(mstFlag){
				if (cplex.getSolnPoolNsolns() > 1) {
					cplex.writeMIPStart(fname);
					System.out.println("MST is ready!");
				}
				else
					return -144;// no need to call CM again without finding another starting point
			}

			cplex.writeMIPStart("cm_solution.mst");


			double ObjValue =  cplex.getObjValue();
			Utils.printf("Obj " + ObjValue);			


			for(int i=0; i<nMines; i++){
				mine[i].msgflag = !relax;
				mine[i].writeOutputs(cplex, data);
				mine[i].msgflag = relax;
				if(relax){
					mine[i].relaxedSol = new double[nTypes];
					for(int m=0;  m < nTypes; m++)
						mine[i].relaxedSol[m] = cplex.getValue(data.mine[i].MV.AQty[m][data.nPeriods-1]);

					/*System.out.println("Mine "+i);
					System.out.print("\t"+cplex.getValue(data.mine[i].MV.AQty[0][data.nPeriods-1]));
					System.out.print("\t"+cplex.getValue(data.mine[i].MV.AQty[1][data.nPeriods-1]));
					System.out.print("\t"+cplex.getValue(data.mine[i].MV.AQty[2][data.nPeriods-1]));
					 */
				}
			}

			return ObjValue;			
		}catch(Exception e){
			e.printStackTrace();
			return -100;
		}
	}
	public IloNumVar createBasicModel(IloCplex cplex, Data data,  int CentModelLB)	throws IloException {

		data.resetOrderCost();
		cplex.clearModel();	
		//LOOPING OVER ALL MINES and adding constraints
		Train[] TrClass = data.TrClass ;
		Mine[] mine = data.mine;
		IloNumExpr  objtmp = cplex.numExpr();

		for(int i=0; i < data.nMines; i++){
			mine[i].relax = relax;
			mine[i].addConstraints(data, cplex);

			objtmp = cplex.sum(objtmp, mine[i].MV.ObjVar);	
		}
		//scaling
		IloNumVar newObj;
		if(relax){
			System.out.println(" Solving relaxed problem ");
			newObj = cplex.numVar(0, Integer.MAX_VALUE);
		}
		else
			newObj = cplex.intVar((int)(CentModelLB/scaling), Integer.MAX_VALUE);


		cplex.addGe(cplex.prod(newObj,scaling), objtmp);

		// LINKING: rail operators constraint
		for(int m=0; m < data.nTypes; m++){
			for(int t=1; t< data.nPeriods; t++){
				IloNumExpr  tmpSum =  cplex.constant(0);
				IloNumExpr  numTrs =  cplex.constant(0);

				for (int i=0; i < data.nMines; i++){											
					// for each mine, class and time 
					int tEnd = Math.min(data.nPeriods-1, t+TrClass[m].sTime);
					int tStart = Math.max(0, t-TrClass[m].e_tau);	
					tmpSum = cplex.sum(tmpSum, cplex.diff(mine[i].MV.AQty[m][tEnd], mine[i].MV.AQty[m][tStart]));
					numTrs  = cplex.sum(numTrs, mine[i].MV.AQty[m][t]);
				}	
				//	cplex.addEq(noActTrains[m][t], tmpSum);
				cplex.addLe(tmpSum,TrClass[m].number).setName("LinkingConst_"+m+"_"+t);

				//	cplex.addLe(numTrs, (int)((float)t+TrClass[m].e_tau)/TrClass[m].g_tau*TrClass[m].number);
			}
		}
		cplex.addMinimize(newObj);
		return newObj;
	}

	private double[] getObjLowerBounds(Data data, Pattern P, int[] arr){
		Data tmpData = data;
		double[] newLB = new double[tmpData.nMines];
		try{
			IloCplex cp = new IloCplex();		
			for(int i=0; i < tmpData.nMines; i++){
				cp.clearModel();	
				tmpData.mine[i].msgflag = false;
				tmpData.mine[i].solveMineProb(cp, tmpData, P.getIntPattern(i, arr));				
				newLB[i]= tmpData.mine[i].objcost;
				tmpData.mine[i].msgflag = true;
				//	System.out.println(" cm obj  "+ newLB[i]);
			}
			cp.end();
		}catch(Exception e){
			e.printStackTrace();
		}
		return newLB;
	}
}
