package imura;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Random;

import ilog.concert.*;
import ilog.cplex.*;
import imura.Mine.MineSol;

public class ColGen {

	protected Data intData;
	Solution solObj;

	int[] bestUbCnt = new int[3];// rail opr, Price and UBM
	double[] bounds = new double[4];
	double[][] dualPrices= null;
	double[][] dp_ST= null;
	double[][] STcenter= null;
	int[][] delta;
	int LBimpCntr=0;
	long startTime;
	long newseed = 1234567890;

	boolean hasAFeasSol = false;
	boolean normalised = false;
	boolean privateProdInfo = false;
	boolean privateResCons = false;
	boolean noUBheur = false;
	boolean stablCG = true;
	
	double eps1DENOM = 10.0;
	double eps2DENOM = 20.0;
	double eps1MAX = 0.5;

	DecimalFormat twoDec = new DecimalFormat("#.##");
	DecimalFormat fourDec = new DecimalFormat("#.####");
	DecimalFormat custDec =twoDec;

	public ColGen(Data d){
		intData = d;
		dualPrices = new double[d.nTypes][d.nPeriods];
		dp_ST = new double[d.nTypes][d.nPeriods];
		STcenter= new double[d.nTypes][d.nPeriods];	
	}

	private void setData(Data din){
		this.intData = din;
	}

	// HashSet <String> cent_model_cols= new HashSet <String>();
	//===========================================================================

	public void solveWithNormalisedColGen(IloCplex cplex, int option) throws IloException {
		// TODO Auto-generated method stub
		Data  td = intData;
		String str = "Normalized column generation  with ";
		normalised = true;
		custDec = fourDec;

		for(int i=0; i < td.nMines; i++)		
			td.mine[i].setBaseValue(cplex, td);


		if(option > 4){
			System.out.println(" No UB heuristics");
			noUBheur = true;
			option = option-2;
		}

		switch(option){
		case 1:  str+= "complete information"; break;
		case 2:  
			str+= "private production information"; 
			privateProdInfo = true;
			break;
		case 3:  
			str+= "private  resource constraint"; 
			privateResCons = true;
			for(int i=0; i < td.nMines; i++)
				td.mine[i].resConstraint = false;

			break;
		case 4:  
			str+= "private  resource constraint and production"; 
			privateProdInfo = true;
			privateResCons = true;
			for(int i=0; i < td.nMines; i++)
				td.mine[i].resConstraint = false;
			break;
		default:  str+= " wrong choice "; return;		
		}
		System.out.println(str);

		solveWithColGen(cplex);
	}

	public void solveWithColGen(IloCplex cplex) throws IloException{

		Data data = intData;
		// decentralised model		
		MyUtils Utils = new MyUtils(data.conf.filePrefix);
		cplex.clearModel();
		//	Pattern PatObj= new Pattern(data);

		int nMines = data.nMines;
		int nTypes = data.nTypes;
		int nPeriods = data.nPeriods;	
		int itrLimit = data.conf.itrLimit;

		double[][][] lambda 	=  new double[nMines][nTypes][nPeriods];
		double[][] S 	=  new double[nTypes][nPeriods];
		double[][] violH 	=  new double[nTypes][nPeriods];

		int  UBimpCntr =0, NLB =0;
		double  cumTime = 0, step=0.1,  gamMax=0.9;
		boolean intCall = false;
		initialiseVariables(data, lambda, S, violH);		

		//Initialise solution arrays
		solObj = new Solution(itrLimit, data);
		if(normalised)
			Utils.printf("Itr, \tLB,  \tUB, \tGap, \tcTime, \tMasterLB, \tLB-Gap, \tUB,","summary.txt");
		else
			Utils.printf("Itr, \tLB,  \tUB, \tGap, \tcTime, \tMasterLB, \tLB-Gap","summary.txt");

		startTime = System.currentTimeMillis();

		bestUbCnt[0]=1;bestUbCnt[1]=0;bestUbCnt[2]=0;	
		bounds[1] = 1e20;

		for(int itr=1; itr< itrLimit; itr++){
			double newLB=0;
			//LB computation
			//	int[] newPattern = new int[data.nMines];
			String costStr = " Cost =";
			for(int i=0; i < nMines; i++){
				cplex.clearModel();	
				data.mine[i].msgflag = false;
				data.mine[i].solveMineProb(cplex, data);
				data.mine[i].addAllColumns(cplex, data);
				//		newPattern[i]= identifyPattern(data, PatObj, i, null);
				newLB += data.mine[i].objcost;
				costStr += ("\t "+ custDec.format(data.mine[i].objcost));
			}		
			setData(data); // updating internal data
			//		delta = computeViolation();

			double penalty = 0; int cumViol=0; 
			for(int m=0; m < nTypes; m++)
				for(int t=0; t < nPeriods; t++){
					penalty += lambda[0][m][t]*data.TrClass[m].number;
					//		cumViol += ( (delta[m][t] < 0)? -1*delta[m][t]: 0);
				}			

			solObj.currLB[itr] = newLB-penalty;
			//			costStr += ("\t Pen \t "+ penalty+"\t Sum " + solObj.currLB[itr]);

			//	sol.viol[itr] = cumViol;
			if ( (solObj.currLB[itr] > solObj.bestLB)){
				LBimpCntr =0; NLB++;
				//sol.bestLB = 100*Math.ceil(sol.currLB[itr]/100);	
				solObj.bestLB = solObj.currLB[itr];
				step = Math.min(2,step*1.3);
				solObj.setBestLambda(lambda);
				solObj.setBestDual(dp_ST);
				STcenter = solObj.getBestDual();
			}
			else{
				step = step*0.9;
				LBimpCntr++;
			}

			bounds[0] = solObj.bestLB;
			double tempUB = solve_CG_model(cplex, data,  itr, false); // LP Version 
			solObj.currUB[itr] = tempUB;			
			if (solObj.currUB[itr] < solObj.bestUB){
				UBimpCntr = 0;
				//			PatObj.setBestpattern(newPattern);
				solObj.bestUB = solObj.currUB[itr];
			}
			else 
				UBimpCntr++;

			cumTime = printIterationSummary(Utils, itr, step);

			double lbGap = (bounds[1] - bounds[0])/bounds[1]*100;
			if ( (!intCall && (cumTime > data.conf.LR_TIME_LIMIT/2.0 ))
					|| (lbGap < 1 && itr%5 ==0)    ){ 
				solve_CG_model(cplex, data,  itr, true); // INT Version with all columns
				printIterationSummary(Utils,  itr, step);
				intCall = true;
			}

			if 	(cumTime+600 > data.conf.LR_TIME_LIMIT && lbGap > 1)
				intCall = false;

			if ( (solObj.gap < data.conf.LR_GAP_LIMIT) || 
					(cumTime+100 > data.conf.LR_TIME_LIMIT) || 
					(LBimpCntr > 20 && UBimpCntr > 20 && hasAFeasSol )  ||
					(lbGap < 0.001)){ // Master problems' LB and Lag LB are almost same{

				solve_CG_model(cplex, data,  -10, true); // INT Version with all columns

				//				solObj.bestLB = 100*Math.ceil( (solObj.bestLB-1e-4)/100); //rounding
				printIterationSummary(Utils, itr, step);
				break; //QUITTING THE LOOP
			}					

			//			P. Wentges. Weighted Dantzig-Wolfe decomposition of linear mixed-integer programming.
			//			Int. Trans. Opl. Res., 4(2):151{162, 1997.

			gamMax = (stablCG ? 0.5: 1); 	
			double gamOpt = (itr ==1? 1 : gamMax);
			for(int m=0; m < nTypes; m++){
				for(int t=0; t< nPeriods; t++){							
					if (NLB ==0)
						dp_ST[m][t] = (1-gamOpt)*dp_ST[m][t]+ gamOpt*dualPrices[m][t];
					else
						dp_ST[m][t] = (1-gamOpt)*STcenter[m][t]+ gamOpt*dualPrices[m][t];					
				} 
			}

			//*************Lambda****************************					                 
			for(int m=0; m < nTypes; m++){
				for(int t=0; t < nPeriods; t++){		
					for(int i=0; i < nMines; i++){
						lambda[i][m][t] = Math.max(0, -1*dp_ST[m][t]);					
					} // mine loop					
				}
			}

			for(int m=0; m < nTypes; m++)
				for(int t=0; t < nPeriods; t++){
					int tStart = Math.max(0,t-data.TrClass[m].sTime);
					int tEnd = Math.min(nPeriods-1,t+data.TrClass[m].e_tau);
					for(int i=0; i < nMines; i++){
						double tmp=0;
						for(int t1=tStart; t1< tEnd; t1++)
							tmp += lambda[i][m][t1];
						data.mine[i].orderCost[m][t] = data.mine[i].OC    + tmp;
					}
				}

			Utils.printf("\n\n ##### ITERATION - "+itr+"####\n", "cplex_log.txt");
			System.out.println("\n \n ************************************************ \n");
			Utils.printf("\n---------------------ITR:"+itr+"-------------------------------","solutions.txt");
			//	clearColumns(data); //cleaning columns
		}
		System.out.println("Best UB count: RO= "+ bestUbCnt[0]+" Pricing= "+ bestUbCnt[1]+" UBM= "+ bestUbCnt[2]);
	}


	private double solve_CG_model(IloCplex cp, Data td,  int itr,  boolean IntFlag) throws IloException {

		double currrBest  = solObj.bestUB; 

		if(itr ==1) // get initial feasible solution
			solObj.bestUB = computeUB(cp, 1, null, null);		
		if(IntFlag)
			System.out.println(" Solving the integer master problem ");

		IloNumVar[][] Xic = new IloNumVar[td.nMines][]; 

		int choiceFlag = (IntFlag ?  1:0);
		if (!solveMasterProblem(cp, td, itr, Xic, choiceFlag, null))
			return currrBest;
		else if(choiceFlag==1){
			try{ 
				//	cp.writeMIPStarts("colgen_startsoln.mst");
			}catch(Exception e){}
		}

		double cpObjVal = cp.getObjValue();

		String outStr;
		if(!IntFlag){
			outStr = "Relaxed prob objcost  = "+ custDec.format(cpObjVal) ;
			if(hasAFeasSol) bounds[1] = cpObjVal;
		}else
			outStr = "Integer Version  obj = "+ custDec.format(cpObjVal);

		int[] FeasCols =  new int[Xic.length]; 
		double[] minesCost =  new double[td.nMines];
		double actCost =0; 

		double[][] Xval = new double[td.nMines][];	
		double[][] redCost = new double[td.nMines][];		
		String solnstr ="";		
		int goodMine =0;

		for(int i=0; i < Xic.length; i++){
			int cnt=0; double xSum =0;
			Xval[i] = new double[Xic[i].length];
			if(!IntFlag) redCost[i] =  cp.getReducedCosts(Xic[i]);

			for(int c=0; c < Xic[i].length; c++){
				Xval[i][c] = cp.getValue(Xic[i][c]);	
				if(!IntFlag){
					if( (!cp.getBasisStatus(Xic[i][c]).toString().endsWith("Basic")) && Xval[i][c] ==0)				
						td.mine[i].colVector.get(c).nonBasicCnt++;
					else
						td.mine[i].colVector.get(c).nonBasicCnt =0;
				}
				xSum += Xval[i][c]; 
				if( Xval[i][c] > 1e-4){	
					if(IntFlag){
						minesCost[i]  = td.mine[i].allColumns.get(c).actcost;
						actCost += (int)Math.round((minesCost[i]*td.mine[i].getBaseValue()));
						solnstr += "\n" + td.mine[i].getMineSolnString(c);
					}else
						minesCost[i]  = td.mine[i].colVector.get(c).actcost;

					cnt++;
					int chance = (int)Math.round(100*Xval[i][c]);
					if(IntFlag)
						outStr += "\t ("+i+", "+c+", " +"["+custDec.format(minesCost[i])+"] ), ";//+ td.mine[i].colVector.get(c).source+") ";
					else
						outStr += "\t ("+i+", "+c+", "+ chance +"["+custDec.format(minesCost[i])+"] ), ";//+ td.mine[i].colVector.get(c).source+") ";

					FeasCols[i] =c;
				}
			}
			if(!IntFlag && !hasAFeasSol && xSum==1)
				goodMine ++;
		}
		if(!IntFlag && !hasAFeasSol && goodMine==td.nMines)
			hasAFeasSol = true; // To identify atleast one global solution 

		System.out.println(outStr);
		if(!IntFlag){ // valid only for LP version			
			currrBest = setDualPrice_and_UB(cp, td, itr, Xval);
		}else { //CG int version
			if(normalised){
				solnstr = "From Master prob. (INT) : Total sys cost =" + actCost +solnstr;
				System.out.println("Actual cost of Integer solution " + actCost);				
				MyUtils utils = new MyUtils(td.conf.filePrefix);
				utils.printf(solnstr,"solutions.txt");
				bounds[3] = actCost;
			}
			currrBest = Math.min(currrBest, cpObjVal);
			if(currrBest <  solObj.bestUB){
				bestUbCnt[1]++;
				solObj.bestUB = currrBest ;
			}
			bounds[2] = currrBest;

			if(itr>0 )	repairSolution(cp, td, itr, FeasCols, minesCost);
		}	

		return currrBest;
	}

	private boolean solveMasterProblem(IloCplex cp, Data td, int itr, IloNumVar[][] Xic, 
			int choiceFlag, int[] idxArray) throws IloException {
		IloNumVar[] MineValue = cp.numVarArray(td.nMines, 0, Integer.MAX_VALUE); 

		IloNumVar[][] Slack = new IloNumVar[td.nTypes][td.nPeriods]; 
		IloNumVar[][] Slack0 = new IloNumVar[td.nTypes][td.nPeriods];

		int[] colDim =  new int[td.nMines];
		double[] minValue =  new double[td.nMines];
		IloNumExpr obj = cp.numExpr();
		String col_string="";

		cp.clearModel();
		// choiceFlag==0 LP version, ==1; INT full version, ==2 INT last iteration

		for(int i=0; i < td.nMines; i++){			
			if(choiceFlag==1){
				colDim[i] = td.mine[i].allColumns.size();//  columns.size();	
				Xic[i] = cp.intVarArray(colDim[i], 0, 1);
			}else if(choiceFlag==0){
				colDim[i] = td.mine[i].colVector.size();//  columns.size();	
				Xic[i] = cp.numVarArray(colDim[i], 0, 1);
			}else if(choiceFlag==2){
				colDim[i] =   idxArray[i]+1;//  columns.size();
				Xic[i] = cp.intVarArray(1, 0, 1);
			}
			col_string += "_"+colDim[i];

			IloNumExpr colSum = cp.numExpr();	
			IloNumExpr tmpObj = cp.numExpr();
			int startIdx= (choiceFlag==2 ?  colDim[i]-1:0);
			for(int c = startIdx; c< colDim[i];  c++){

				Xic[i][c-startIdx].setName("Xcol_"+i+"_"+c);				

				double value;
				if(choiceFlag==1 || (choiceFlag==2 && idxArray != null)){
					value = td.mine[i].allColumns.get(c).actcost;
					if(c==0 || minValue[i] > value)
						minValue[i]  = value;	
				}else
					value = td.mine[i].colVector.get(c).actcost;

				tmpObj = cp.sum(tmpObj, cp.prod(Xic[i][c-startIdx], value));
				colSum = cp.sum(colSum, Xic[i][c-startIdx]);
			}

			if(choiceFlag==2 || !hasAFeasSol){
				cp.addLe(colSum, 1).setName("ColSelect_"+i);
				double penalty = (normalised ? 1e4: 1e8);
				tmpObj = cp.sum(tmpObj, cp.prod( cp.diff(1.0, colSum), penalty ));
			}else{
				cp.addEq(colSum, 1).setName("ColSelect_"+i);				
			}


			cp.addEq(MineValue[i], tmpObj).setName("MineObj_"+i);
			obj = cp.sum(obj, MineValue[i]);
		}
		System.out.println("Col String itr= "+ col_string);

		IloNumExpr obj2 = cp.numExpr();
		for(int m=0; m < td.nTypes; m++){
			if(choiceFlag==0 && stablCG){
				Slack[m] =  cp.numVarArray(td.nPeriods, 0, 100);
				Slack0[m] =  cp.numVarArray(td.nPeriods, 0, eps1MAX); // two stage stability function, first step is restricted upto 0.5 
			}
			for(int t=0; t < td.nPeriods; t++){				
				if(choiceFlag==0 && stablCG)
					Slack[m][t].setName("Slack_"+m+"_"+t);

				IloNumExpr tmpSum = cp.numExpr();
				for(int i=0; i < td.nMines; i++){
					int startIdx= (choiceFlag==2 ?  colDim[i]-1:0);
					for(int c= startIdx; c <colDim[i]; c++ ){	
						MineSol MS;
						if(choiceFlag==1 || (choiceFlag==2 && idxArray != null)){
							MS = td.mine[i].allColumns.get(c);
						}else
							MS = td.mine[i].colVector.get(c);						

						if(MS.noRunningTrains[m][t] >0)
							tmpSum = cp.sum(tmpSum, cp.prod(Xic[i][c-startIdx], MS.noRunningTrains[m][t]));
					}
					if(choiceFlag==1 && m==0 && t==0){
						//each mine will have cut off based on current UB^* and min value of others 
						double minContrb = -minValue[i]; 
						for(int i1=0; i1 < td.nMines; i1++)
							minContrb += minValue[i1];
						cp.addLe(MineValue[i], solObj.bestUB - minContrb).setName("Mine_cut_off"+ i); 
					}					
				}
				if(!isNumExprEmpty(tmpSum, cp) && choiceFlag==0 && stablCG){
					cp.addLe(cp.diff(tmpSum, cp.sum(Slack0[m][t], Slack[m][t])), td.TrClass[m].number).setName("ResConst_"+m+"_"+t);
					obj2 = cp.sum(obj2, cp.prod(-1*STcenter[m][t], cp.sum(Slack0[m][t], Slack[m][t])), stabilityFunction(cp, Slack[m][t], Slack0[m][t], itr));	
				}else if (!isNumExprEmpty(tmpSum, cp))
					cp.addLe(tmpSum,  td.TrClass[m].number).setName("ResConst_"+m+"_"+t);
			}
		}
		MyUtils Utils = new MyUtils("");

		if(choiceFlag==1){
			cp.addLe(obj, solObj.bestUB + 100);
			cp.addGe(obj, solObj.bestLB);
		}if(choiceFlag==0)
			cp.addMinimize(cp.sum(obj, obj2));
		else
			cp.addMinimize(obj);

		String lbl ="CG-"; int TL=0;
		if(choiceFlag==1){
			cp.exportModel("colgen_int.lp"); lbl +="MIP"; TL=300;

			try{
				//		cp.readMIPStarts("colgen_startsoln.mst");
			}catch(Exception e){

			}
		}else if(choiceFlag==2){
			cp.exportModel("colgen_intCurr.lp"); lbl +="MIP"; TL=300;

		}else{
			// cp.exportModel("colgen_A1_"+itr+".lp");
			cp.exportModel("colgen_relax.lp");
			lbl +="LP";
		}
		return Utils.solveAndRecord(cp, lbl, 0, TL);
	}

	private double setDualPrice_and_UB(IloCplex cp, Data td, int itr, double[][] Xval) 	throws IloException {

		double currrBest = solObj.bestUB;
		for(int i=0; i < dualPrices.length; i++){
			for(int j=0; j < dualPrices[i].length; j++){
				dualPrices[i][j] =0;
			}
		}
		for (Iterator it = cp.rangeIterator(); it.hasNext(); /* nothing */) {
			IloRange range = (IloRange)it.next();
			String name = range.getName();
			//	System.out.println(" Ilo "+ name +" \t slack "+ cp.getSlack(range));
			if(name != null  && name.startsWith("ResConst_")){
				String[] sub = name.split("_");
				int trClass = Integer.parseInt(sub[1]);
				int time = Integer.parseInt(sub[2]);
				dualPrices[trClass][time] = cp.getDual(range);	
				//		if(dualPrices[trClass][time] !=0)
				//			System.out.print("\t dp("+time+")=" + fourDec.format(dualPrices[trClass][time]));
			}
			else if (name != null  && name.startsWith("ColSelect_")){
				String[] sub = name.split("_");
				int mineIdx = Integer.parseInt(sub[1]);
				td.mine[mineIdx].dualPrice = cp.getDual(range);
				//				System.out.println(" mine["+mineIdx+"] dualPrice " +td.mine[mineIdx].dualPrice );
			}
		}

		if(itr==1) 		return currrBest; 
		//***************UBM********
		double masterGap = (bounds[1]-bounds[0])/bounds[1]*100;

		int MAX = (masterGap < 1 ? 5: 1); 

		for(int sam =0; sam < MAX; sam++){


			String colStr = "Column selection : ";
			String key_str ="";
			int[] FeasCols = new int[td.nMines];			
			for(int i=0; i < Xval.length; i++){
				int prob =0;
				FeasCols[i] = -1;
				int rNo = (new Random(1011201110+(sam-1)*1000+itr*100+10*i)).nextInt(100);
				for(int c=0; c < Xval[i].length; c++){
					if( Xval[i][c] <= 0) continue;		
					prob += (int)Math.round(100*Xval[i][c]);
					FeasCols[i] =c;
					if(prob >= rNo) break;
				}	
				if(FeasCols[i] >= 0){ 		
					colStr += "\t ("+i+", "+FeasCols[i]+", "+ rNo +") ";
					key_str += ("+"+ td.mine[i].colVector.get(FeasCols[i]).key_str);
				}else{
					return currrBest; 
				}
			}
			System.out.println(colStr);

			if (solObj.evaluatedPat.contains(key_str)){			
				System.out.println("Already evaluated pattern (repair) " + key_str);
				continue;
			}
			else
				solObj.evaluatedPat.add(key_str);


			//			int[] newPattern = new int[FeasCols.length];
			//			for(int i=0; i < FeasCols.length; i++){		
			//				int[] TrCombo = intData.mine[i].colVector.get(FeasCols[i]).TrCombo;
			//				newPattern[i]= identifyPattern(null, PatObj, i, TrCombo); //TrCombo;
			//			}	
			//
			//			PatObj.setNewPattern(newPattern);		
			double ub1 =  computeUB(cp, itr, null, null);
			System.out.println("Sol from UBM +RO "+custDec.format(ub1));
			if(ub1>0) currrBest  =  Math.min(currrBest , ub1);

			//Trying to create more number of globally feasible solns
			repairSolution(cp, td, itr, FeasCols, null);

		}
		// Bestcol will be affected if we delete any column from the list.
		for(int i=0; i < td.nMines; i++){			
			for(int c = td.mine[i].colVector.size()-1; c >= 0; c--){
				MineSol MS = td.mine[i].colVector.get(c);					
				if(MS.nonBasicCnt >= 10 ){						
					//			System.out.println("Removing columns " +c+" "+  MS.key_str+" from mine "+i);
					td.mine[i].lpColList.remove(MS.key_str);
					td.mine[i].colVector.remove(MS);
				}
			}
		}

		return currrBest;
	}


	private void repairSolution(IloCplex cp, Data td, int itr, int[] idxArray, double[]  mineCost) 	throws IloException {

		if(noUBheur) 
			return ; // time out

		boolean intSolution = (mineCost == null ? false: true); 

		int[] xVal  = new int[td.nMines];			
		if(!intSolution){
			IloNumVar[][] Xic = new IloNumVar[td.nMines][]; 
			if (!solveMasterProblem(cp, td, 0, Xic, 2, idxArray))
				return;

			for(int i=0; i < td.nMines; i++){
				xVal[i] = (int)Math.round(cp.getValue(Xic[i][0]));
			}
		}else{ // Full integer version 
			xVal = new int[td.nMines];
		}
		//Full version reads columns from allColumn vector, in other case it reads from LP vector
		ArrayList<Integer> mineArray = sortMines(xVal, td.nMines);

		int u=0;		
		while(true){	
			double cumTime = (System.currentTimeMillis() - startTime)/1000;
			if(cumTime > td.conf.LR_TIME_LIMIT)
				break ; // time out

			if(mineArray.size()==0)
				break;

			int badMine = mineArray.get(u).intValue();
			System.out.println("Repairing mine "+ badMine);

			Mine M = td.mine[badMine];
			MyUtils Utils = new MyUtils("");
			cp.clearModel();
			td.resetOrderCost();
			M.addConstraints(td, cp);
			cp.addMinimize(M.MV.ObjVar);
			//	cp.exportModel("mine_b4"+badMine+".lp");
			for(int t=0; t < td.nPeriods; t++)
				for(int m=0; m < td.nTypes; m++){					
					int availRes = td.TrClass[m].number;					
					for(int i=0; i < td.nMines; i++){
						if((!intSolution && xVal[i] != 1) || i == badMine) continue;						
						if(intSolution)
							availRes -= Math.round(td.mine[i].allColumns.get(idxArray[i]).noRunningTrains[m][t]);
						else
							availRes -= Math.round(td.mine[i].colVector.get(idxArray[i]).noRunningTrains[m][t]);							
					}
					//				// for each mine, class and time 
					int tEnd = Math.min(td.nPeriods-1, t+td.TrClass[m].sTime);
					int tStart = Math.max(0, t-td.TrClass[m].e_tau);	
					cp.addLe(cp.diff(M.MV.AQty[m][tEnd], M.MV.AQty[m][tStart]),availRes).setName("NewRes_"+m+"_"+t);
				}
			//	cp.exportModel("mine_after"+badMine+".lp");
			if(Utils.solveAndRecord(cp,  "MineRepair-"+badMine, 0, 100)){
				int prevCnt = M.allColumns.size();
				M.addAllColumns(cp, td);

				//double objV =  Math.round(cp.getObjValue());

				double objV =  cp.getObjValue();
				if(intSolution){
					if(objV < mineCost[badMine]- 1e-8){
						System.out.println(" Swapping mine "+M.mIdx+" cost "+ custDec.format(mineCost[badMine])+ " with  "+ custDec.format(objV));
						mineCost[badMine]= objV;
						if(M.allColumns.size() > prevCnt)
							idxArray[badMine] = M.getIdx_mipcol_list();
						u++;
					}
					else mineArray.remove(u); // no better solution
				}
				else mineArray.remove(u); // non integer call
			}
			else mineArray.remove(u); // could not solve

			if( u>= mineArray.size())
				u =0;
		}

		if(intSolution){
			double ub =0.0;
			for(int i=0; i < td.nMines; i++)
				ub += mineCost[i];
			solObj.bestUB = Math.min(solObj.bestUB, ub);
		}
		//		return 0;
	}

	private ArrayList<Integer> sortMines(int[] xVal, int nMines) {
		/// Sorting based on cost
		ArrayList<Integer> mineArray = new ArrayList<Integer>();		
		for(int u=0; u <nMines; u++){				
			if(xVal[u] == 1) continue;				
			mineArray.add(u);
		}
		Collections.shuffle(mineArray);
		return mineArray;
	}



	private IloNumExpr stabilityFunction(IloCplex cp, IloNumVar slack,  IloNumVar slack0, int itr) throws IloException {
		// TODO Auto-generated method stub
		// double weight =  1000*Math.pow(10, Math.floor((itr/5)));
		double weight =  (double)itr/eps2DENOM*solObj.bestLB;		
		return cp.sum(cp.prod(slack, weight), cp.prod(slack0, weight/eps1DENOM) );
	}


	private boolean isNumExprEmpty(IloNumExpr expr, IloCplex cp) throws IloException {
		// TODO Auto-generated method stub		
		return expr.getClass().toString().equals(cp.numExpr().getClass().toString());
	}

	private double printIterationSummary(MyUtils Utils, int itr, double step) {
		System.out.println("Iteration : "+itr+"\t "+ 	"\t UB* = "+  custDec.format(solObj.bestUB));				

		if(solObj.bestLB >0) solObj.gap = (solObj.bestUB-solObj.bestLB)/solObj.bestUB;
		else  solObj.gap = 1e4;

		double cumTime = (System.currentTimeMillis() - startTime)/1000;

		String str = itr+", \t"+ custDec.format(solObj.bestLB)+
		",\t "+ custDec.format(solObj.bestUB) +
		",\t "+ twoDec.format(solObj.gap*100)+
		",\t "+ Math.round(cumTime) +	
		",\t "+ custDec.format(bounds[1]) +
		",\t "+ twoDec.format((bounds[1]-bounds[0])/bounds[1]*100);

		if(normalised)
			str += ",\t "+ Math.round(bounds[3]);

		Utils.printf(str,"summary.txt");
		return cumTime;
	}

	private void initialiseVariables(Data data, double[][][] lambda, double[][] S, double[][] violH) {	
		for(int m=0; m < data.nTypes; m++)
			for(int t=0; t < data.nPeriods; t++){				
				S[m][t] = 0;
				violH[m][t] = 0;
				STcenter[m][t] =0;
				for(int i=0; i < data.nMines; i++)
					lambda[i][m][t] = 0;
			}
	}

	//	//===========================================================================	
	private double computeUB(IloCplex cplex, int itr, Pattern Pobj, int[] FeasCols) throws IloException{
		double compUB= solObj.bestUB;
		Data tData = intData;

		double cumTime = (System.currentTimeMillis() - startTime)/1000;
		if(cumTime > tData.conf.LR_TIME_LIMIT)
			return compUB; // time out

		int choice =2;
		solObj.ChoiceArray[itr] = choice;		
		RailOpr RO12 = new RailOpr(privateProdInfo);

		RO12.makeJobs(tData);
		compUB = RO12.solveRailProb(cplex, tData, itr);
		if(compUB < 1e15)
			hasAFeasSol = true;
		if(compUB>0 && compUB <  solObj.bestUB)
			bestUbCnt[0]++;
		//if(itr==1) 
		return compUB;
	}
}
