package imura;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.DecimalFormat;
import java.util.Random;

import ilog.concert.IloException;
import ilog.cplex.IloCplex;
import imura.Data.Configuration;

// This is the coMmon file to run all programs under this work


public class mainFile {
	static String DataPrefix;
	static String baseDir;
	static int modelChoice = -1;

	public static void main( String[] args ) {

		if(args.length >0)
			modelChoice = Integer.valueOf(args[0]);

		int[] mineNo = {7, 10, 5, 6, 8, 9, 12, 15};
		String[] dataLetter = {"A", "B", "C", "D","E","F", "G", "H","Z"};
		for(int u : (new int[]{0})){
			//	for(int u =0 ; u< 8; u++){
			long start = System.currentTimeMillis();
			System.out.println("starting ............");

			DataPrefix = dataLetter[u];
			String filename = "data/"+mineNo[u]+"mines/Data_"+dataLetter[u];
			try{
				runModel(filename, u);
			}catch(Exception e){
				e.printStackTrace();
			}
			System.out.println("Total execution time "+ (System.currentTimeMillis() - start)/1000F +" secs");
			System.out.println("\nfinished............"+ DataPrefix);
		}

		System.out.println("\nfinished............");

	}


	//
	private static void runModel(String dataseries, int u){

		try {

			IloCplex cplex = new IloCplex();
			// int[][] Colln ={{4, 7,8},{2,5,15}, {12,13,14},{4,7,13},{15},{1,2,3,4,5}};

			int[] Colln ={5}; //data set
			//
			for(int set : Colln){
			//	for(int set = 1; set < 31; set++){
				//		if(set==7) continue;

				String filename = dataseries +set+".dat";

				long start = System.currentTimeMillis();
				Data data =  readData(filename);
				for(int i=0; i < data.nMines; i++)
					data.mine[i].initTrAvailAndDelay(data);//init				

				if(modelChoice == -1)
					modelChoice = data.conf.Model_Choice;

				switch(modelChoice){
				case 1: 	
					// Centralised model
					data.conf.filePrefix ="CM_"+DataPrefix+"_";
					CentModel CM = new CentModel(data);
					CM.solve(cplex, data.conf.LR_GAP_LIMIT, data.conf.LR_TIME_LIMIT);
					//	CM.solve(0,0,"cent_sol_rail_p4.mst");
					break;

				case 2: 
					// Solving an individual mine
					data.mine[1].solveMineProb(cplex, data);					
					break;

				case 3:  
					// Decentralised model	
					data.conf.filePrefix ="DM_"+DataPrefix+"_";
					DecentModel DM = new DecentModel(data);
					DM.solve(cplex, 0);

					break;

				case 4: // Centralised + Lagrangian method
					data.conf.filePrefix ="LR_"+DataPrefix+"_";
					try{
						DecentModel DM1 = new DecentModel(data);
						DM1.solveWithLag(cplex);
					}catch(Exception e){
						e.printStackTrace();
						System.out.println("Error in data set - " + set);
					}
					break;

				case 41: // Centralised + column generation method
					data.conf.filePrefix ="CG_"+DataPrefix+"_";
					try{
						ColGen CG = new ColGen(data);
						CG.solveWithColGen(cplex);
					}catch(Exception e){
						e.printStackTrace();
						System.out.println("Error in data set - " + set);
					}
					break;

				case 45: 
					data.conf.filePrefix ="NmCG_"+DataPrefix+"_";
					try{
						ColGen CG = new ColGen(data);
						int option =1;
						//1:  Normalized column generation  with complete information
						// 2:  Normalized column generation  with private production information
						//3:  Normalized column generation  with private  resource constraint
						// 4:  Normalized column generation  with private  resource constraint and production
						//5:  3+ no UB heuristic
						// 6:  4+no Ub Heuristic
						CG.solveWithNormalisedColGen(cplex, option);
					}catch(Exception e){
						e.printStackTrace();
						System.out.println("Error in data set - " + set);
					}
					break;
				case 5: 	
					// Centralised model with pattern
					Pattern P = new Pattern(data);
					// P.getInitialPattern(cplex);
					P.solveWithPattern(cplex);
					break;

				case 6: 	
					// Centralised model with random pattern 
					Pattern P1 = new Pattern(data);
					double out = P1.solveWithRndPattern(cplex, -100);
					System.out.println("Cost = "+out);
					break;
				case 7:
					Pattern P2 = new Pattern(data);
					//	P2.makePatternList(data, 0);
					break;
				case 8:
					Pattern P22 = new Pattern(data);
					RailOpr RO = new  RailOpr();
					P22.setNewPattern(P22.getRndPattern());
					// RO.solveWithListHeuristic(cplex, data, P22);
					RO.solveWithPattern(cplex, data, P22);
					break;
				case 9:	
					for(int i=0; i< 1; i++){
						cplex.clearModel();
						RailOpr RO23 = new RailOpr();
						RO23.comparePatterns(cplex, data);
					}
					break;

				case 10:
					Pattern P2210 = new Pattern(data);
					//	P2210.getInitialPattern(cplex);
					RailOpr RO10 = new RailOpr();
					for(int i=0; i < 50; i++){
						P2210.setNewPattern(P2210.getRandomPattern());
						RO10.solveWithPattern(cplex, data, P2210);
					}
					break;
				case 11:
					getDataStat(data, filename);
					break;
				default: 
					System.out.println("Invalid choice");
				}	
				System.out.println("Set "+set+ " eTime "+ (System.currentTimeMillis() - start)/1000F +" secs");
			} // data set; Colln

			cplex.end();

		} catch (IloException e) {
			// TODO Auto-generated catch block		
			e.printStackTrace();
		}
	}

	private static void getDataStat(Data data, String fname) {
		// TODO Auto-generated method stub	
		double totalSupply =0, noOrders =0, prodDensity=0;
		for(int i=0; i < data.nMines; i++){			
			int[] Order = data.mine[i].Order;
			noOrders += Order.length;				
			totalSupply += Order[Order.length-1];
			prodDensity += (Order[Order.length-1]/ data.mine[i].dueDate[Order.length-1]);
		}
		double totTrains =0, avgCap =0;
		for(int k=0; k < data.TrClass.length; k++){
			totTrains += data.TrClass[k].number;
			avgCap += (data.TrClass[k].number* data.TrClass[k].vol);
		}
		avgCap = avgCap/totTrains;

		// System.out.println("Avg#Order "+ noOrders/data.nMines +
		//				"Avg#tripspermine = " + totalSupply/avgCap/data.nMines+ 
		//				"Avg#tripspertrain = " + totalSupply/avgCap/totTrains );
		DecimalFormat twoDec = new DecimalFormat("#.##");
		String str = fname+", "+ twoDec.format(noOrders/data.nMines)+", " +
				twoDec.format(totalSupply)+", " +
				twoDec.format(noOrders)+", " +
				twoDec.format(totalSupply/noOrders)+", " +
				// twoDec.format(totalSupply/prodDensity/data.nMines)+", " +
				twoDec.format(totalSupply)+", " + 		
				data.nMines+", "+ data.TrClass.length+", "+ totTrains+", "+	data.nPeriods;


		MyUtils Utils =  new MyUtils("");

		Utils.printf(str, "data_stat.csv");
	}


	private static void setConfigParameters(Data data){

		Configuration conf = data.conf;
		conf.itrLimit = 500;
		conf.LR_UB_Choice = 0;
		conf.Model_Choice = 3; 
		conf.Mine_CPX_Gap = 0.0;
		conf.CM_CPX_gap = 0.02;

		conf.Mine_CPX_TimeLimit = 0;
		conf.CM_CPX_TimeLImt = 0;

		// String filename = "data/10mines/Data_B"+fNo+".dat";
	}


	//================================================================================================================================

	private static Data readData(String filename) {

		System.out.println("Input data file : "+ filename);
		Data data =null;

		try {
			data = new Data(filename);
			setConfigParameters(data);
			data.conf.datafile = filename;
		} catch(FileNotFoundException ex)  	{
			System.out.println("File ("+filename+") not found.");
		}
		catch (Exception e) {
			System.out.println("ERROR in Input file reading");
			e.printStackTrace();
		}

		return data;
	}

	private static void createDataSets(){

		int nMines =	15;
		String rootDir  = "data/"+nMines+"mines/";
		File f = new File(rootDir);
		f.mkdir();

		int[] noTrains = new int[]{3, 2, 3, 2};
		int[] capacity = new int[]{3000, 5400, 7200, 8400};
		int [] lTime = new int[]{1, 2, 3, 4};
		int [] pTime = new int[]{5, 5, 6, 6};	
		int prod_cap = 400;
		int inv_cap = 20000;
		int hm = 1;
		int ht = 3;
		int dem = 50000;
		int order = 100;
		int periods = 200;
		int avgProd  = 25000;
		int maxN =  4;

		MyUtils utils = new MyUtils("");

		for(int no=0; no < 30; no++){

			String str="";

			str += makeString(noTrains);
			str += makeString(capacity);
			str += makeString(lTime);
			str += makeString(pTime);
			str += (nMines+ "\n");
			Random R = new Random();

			for(int i=0; i < nMines; i++){
				int nOrders = 1 + R.nextInt(maxN-1);
				int ordTime = 10;
				int ordQty =  100;
				str += "[";
				for(int k=0; k < nOrders; k++) {
					ordTime  += (10+ R.nextInt(Math.min(periods-ordTime-10, periods/nOrders-1)));

					ordQty += 100*Math.round((5000+ R.nextInt(10000))/100);
					if(k >0) str+= ", ";
					str += ("["+ordTime +", " + ordQty+"]");
				}
				str +="]\n";
			}

			str += prod_cap +"\n";
			str +=  inv_cap +"\n";
			str +=  hm +"\n";
			str +=  ht +"\n";
			str +=  dem +"\n";
			str +=  order +"\n";
			str +=  periods +"\n";
			utils.printf(str, rootDir+ "Data_H"+no+".dat");
		}

	}
	private static String makeString(int[] arr){
		String s="[";
		for(int i=0; i< arr.length; i++){
			if(i >0 ) s+=", ";
			s += arr[i];
		}
		s += "]\n";
		return s;
	}


}
