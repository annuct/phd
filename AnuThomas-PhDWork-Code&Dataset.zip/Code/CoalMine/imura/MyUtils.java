package imura;

import ilog.concert.IloException;
import ilog.cplex.IloCplex;
import imura.Data.Train;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Date;



public class MyUtils {

	// String prefix = "";
	String prefix = "B0-10_";

	public MyUtils(String str){
		prefix = str;
	}

	public double findMedian(double[] arr){

		int size =0;
		for(int i=0; i < arr.length; i++)
			if (arr[i]>= 1)
				size++;
			else
				arr[i] = 100000;

		Arrays.sort(arr);	

		return arr[size/2];
	} 

	//========================================================================
	//	public double custRund(double val, int k){
	//		return (double)Math.round(val*Math.pow(10.0,k))/Math.pow(10.0,k);
	//	}

	//====================================================================

	public void printf(String str){		
		printf(str, "diary.txt");
	}

	public void printf(String str, String filename){
		FileWriter fsum = null;	
		BufferedWriter fopsum =null;
		try {

			fsum = new FileWriter(prefix+filename, true);

			fopsum = new BufferedWriter(fsum);
			fopsum.write(str+"\n");
			fopsum.flush();
			fopsum.close();
		} catch (IOException e) {			
			e.printStackTrace();
		}
	} 



	// http://www.java2s.com/Code/Java/Development-Class/GreatestCommonDivisorGCDofpositiveintegernumbers.htm
	public final int gcd(int[] x) {
		if(x.length >2) {

			int tmp = gcd(x[x.length-1],x[x.length-2]);
			for(int i=x.length-3; i>=0; i--) {
				if(x[i]<0) {
					throw new IllegalArgumentException("Cannot compute the least "+
							"common multiple of "+
							"several numbers where "+
							"one, at least,"+
					"is negative.");
				}
				tmp = gcd(tmp,x[i]);
			}
			return tmp;
		}
		else if (x.length==1)
			return x[0];
		else if(x.length==2)
			return gcd(x[0],x[1]);
		else
			return 1;
	}



	/** 
	 * Method that calculates the Greatest Common Divisor (GCD) of two
	 * positive integer numbers.
	 * */
	public static final int gcd(int x1,int x2) {
		if(x1<0 || x2<0) {
			throw new IllegalArgumentException("Cannot compute the GCD "+
			"if one integer is negative.");
		}
		int a,b,g,z;

		if(x1>x2) {
			a = x1;
			b = x2;
		} else {
			a = x2;
			b = x1;
		}

		if(b==0) return 0;

		g = b;
		while (g!=0) {
			z= a%g;
			a = g;
			g = z;
		}
		return a;
	}


	public int[] subArray(int[] arr, int startIdx){
		if(startIdx > arr.length){
			System.err.println("Wrong inputs");
		}

		int []  newarr = new int[arr.length -startIdx];
		for(int i=0; i < newarr.length; i++){
			newarr[i] =  arr[i+startIdx];
		}

		return newarr;
	}

	public int[] subArray(Train[] arr, int startIdx){
		if(startIdx > arr.length){
			System.err.println("Wrong inputs");
		}

		int []  newarr = new int[arr.length -startIdx];
		for(int i=0; i < newarr.length; i++){
			newarr[i] =  (int)arr[i+startIdx].vol;
		}

		return newarr;
	}

	public boolean solveAndRecord(IloCplex model){
		return solveAndRecord(model, null, 0, 0);
	}

	public boolean solveAndRecord(IloCplex model,  String str1){
		return solveAndRecord(model, str1, 0, 0);
	}

	//================================================================================================================================
	public boolean solveAndRecord(IloCplex model,  String str1, double gap, int time){

		long start = System.currentTimeMillis();
		boolean stat = false;
		OutputStream output = null;	
		Date date = new Date();      

		boolean msg = (str1==null ? false: true);

		try {
			output = new FileOutputStream(prefix+"cplex_log.txt", true);

			printf("Now: "+ date.toString(), "cplex_log.txt");
		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		try{
			model.setOut(output);


			String str11 = "NoVars = " 			+model.getNcols()+
			", No Constraints= " 	+ model.getNrows() +
			", No Binary vars= " 	+model.getNbinVars() +
			", No Int Vars= " 		+model.getNintVars() ;

			//	if (msg) printf(str11);



			model.setParam(IloCplex.DoubleParam.EpGap, gap);
			if (time >0 )
				model.setParam(IloCplex.DoubleParam.TiLim, time);

			model.setParam(IloCplex.IntParam.MIPEmphasis, 4);
			//			if(str1.equalsIgnoreCase("Rail"))
			//				model.setParam(IloCplex.IntParam.SolnPoolIntensity,2);

			//		model.setParam(IloCplex.DoubleParam.ObjDif, 1);


			//	model.setParam(IloCplex.DoubleParam.EpGap, 1);

			// model.setParam(IloCplex.IntParam.BrDir, -1);
			// model.setParam(IloCplex.IntParam.MIRCuts, 2);
			// model.setParam(IloCplex.IntParam.GUBCovers, 2);
			// model.setParam(IloCplex.IntParam.FracCuts, 2);
			// model.setParam(IloCplex.IntParam.FPHeur, 4);
			// model.setParam(IloCplex.IntParam.HeurFreq, 100);


			try{
				//	model.readMIPStarts("cent_good.mst");
				//			model.readMIPStarts("MIP_start2.mst");
			}catch(Exception e1) {
				System.out.println("Could not find MST input file");
			}


			stat = model.solve();
			//	ctime = model.getCplexTime();
			//	model.writeMIPStarts("MIP_startdummy.mst");

			if( !stat){

				if(!str1.startsWith("MineRepair"))
					model.exportModel("infs_"+str1+".lp");

				String str = " Could not solve "+ model.getCplexStatus();
				System.err.println(str);							
				if (msg)
					printf(str,"time_record.txt");			

				return false;
			}

			//	System.out.println("Number of soln: " + model.getSolnPoolNsolns());

			//	System.out.println("Obj Value "+ model.getObjValue() + "\t Objective "+model.getObjective());
			long elapsed = System.currentTimeMillis() - start;		

			/*			System.out.println("bestObjValue " +model.getBestObjValue());
			System.out.println("objValue " +model.getObjValue());
			System.out.println("MIPRelGap "+model.getMIPRelativeGap());
			System.out.println("ObjGap "+model.getQuality(IloCplex.QualityType.ObjGap));
			System.out.println("LB " +model.getQuality(IloCplex.QualityType.DualObj));
			System.out.println("UB " +model.getQuality(IloCplex.QualityType.PrimalObj));
			 */			 	

			DecimalFormat twoDec = new DecimalFormat("#.##");
			String str = str1+", \t" + date.toString()+"\t eTime " 
			+elapsed/1000F+" secs,\t LB ";
			if(model.getBestObjValue() < model.getObjValue()+1000)
				str+= 	twoDec.format(model.getBestObjValue())+"\t UB " + 
				twoDec.format(model.getObjValue()) +
				" \t Gap= " + twoDec.format(100*model.getMIPRelativeGap())+" %";

			if (msg)
				printf(str,"time_record.txt");
			output.close();

		}
		catch(Exception e){
			e.printStackTrace();
		}		
		return stat;
	}

	public void resetCplexParameters(IloCplex cp) throws IloException{
		cp.setParam(IloCplex.DoubleParam.RelObjDif, 0);	
		cp.setParam(IloCplex.DoubleParam.TiLim, 10000);
	}


	public double[] norm(double[][] delta) {
		// TODO Auto-generated method stub
		double[] out = new double[delta.length];
		for(int i=0; i < out.length; i++){
			double s=0;
			for(int j=0; j< delta[i].length; j++)
				s += Math.pow(delta[i][j],2);

			out[i] = Math.pow(s, 0.5);
		}			
		return out;
	}


	// http://www.java2s.com/Open-Source/Java-Document/Science/JSci/JSci/maths/ArrayMath.java.htm
	public double[] range(double a, double b) {
		return range(a, b, 1);
	}

	public double[] range(double a, double b, double step) {
		if (step <= 0.0) {
			throw new IllegalArgumentException(
					"The argument step should be positive: " + step
					+ " < 0");
		}
		if (a == b) {
			double[] ans = new double[1];
			ans[0] = a;
			return (ans);
		}
		int sizeOfArray = (new Double(Math.abs(a - b) / step))
		.intValue() + 1;
		double[] ans = new double[sizeOfArray];
		ans[0] = a;
		if (a > b) {
			step = -step;
		}
		for (int k = 1; k < sizeOfArray; k++) {
			ans[k] = ans[k - 1] + step;
		}
		return (ans);
	}

	public double[] product(double[][] a, double[][] b){
		double[] out = null;
		try{
			out = new double[a.length];
			for(int i=0; i<a.length; i++)
				out[i]  = product(a[i], b[i]);
		}catch(Exception e){
			System.err.println("Invalid product. Pls check the array dimensions");
		}
		return out;
	}

	public double product(double[] a, double[] b){
		double out=0;
		try{		
			for(int j=0; j <a.length; j++)
				out += a[j]*b[j];
		}catch(Exception e){
			System.err.println("Invalid product. Pls check the array dimensions");
		}
		return out;
	}

}
