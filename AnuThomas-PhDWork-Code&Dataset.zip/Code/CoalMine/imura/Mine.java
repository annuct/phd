package imura;

import java.text.DecimalFormat;
import java.util.*;

import ilog.concert.IloException;
import ilog.concert.IloIntVar;
import ilog.concert.IloNumExpr;
import ilog.concert.IloNumVar;
import ilog.cplex.IloCplex;
import imura.Data;
import imura.Data.Train;
import imura.RailOpr.Job;

public class Mine { //Mine class

	int nOrders;
	int prodCap;
	int invCap;
	int initInv;
	int nTrClass;
	int mIdx;
	int nTypes;
	int nPeriods;
	int[] Order; // cumulative
	int[] dueDate; // due date of orders
	int[] Demand;
	int[] Delay;	
	int[][] TrAvail;	

	double hCostM; // holding cost at mine
	double hCostT;
	double demCost;
	double dualPrice=0;
	double objcost;

	double[][] orderCost;	 
	double OC; 
	private MineSol sol = null; 
	private double baseValue=1;

	IloMineVars MV = new IloMineVars();
	boolean relax= false;
	boolean resConstraint = true;
	double[] relaxedSol;
	boolean msgflag = true;
	Vector<String> lpColList = new Vector<String>();
	Vector<String> mipColList = new Vector<String>();
	Vector<String> checkedSolution = new Vector<String>();

	Vector<MineSol> colVector = new Vector<MineSol>();
	Vector<MineSol> allColumns= new Vector<MineSol>();

	public class IloMineVars{
		IloNumVar[][] AQty;
		IloNumVar ObjVar;
		IloNumVar[] Inv;
		IloNumVar[] OS;
		IloNumVar[] Y;
	}

	public  class MineSol{

		double[] ProdPlan;
		int[][] TrRequest;
		int[] TrCombo;
		int[][] noRunningTrains;
		double actcost;
		//	int[] SolInv;		
		int[] SolY; 
		String key_str;
		int nonBasicCnt =0;
		String source;

		public MineSol() {
			// TODO Auto-generated constructor stub
			ProdPlan = new double[nPeriods];
			//	SolInv = new int[nPeriods];
			SolY = new int[nPeriods];
			TrRequest =  new int [nTypes][nPeriods];
			noRunningTrains = new int [nTypes][nPeriods];
			TrCombo =  new int[nTypes];
			actcost = 0.0;
			nonBasicCnt=0;
			key_str="";
			//itrIdx = itr;
		}
	}
	public Mine(int T, int M){
		nTypes = M;
		nPeriods = T;	
	}
	public void solveMineProb(IloCplex cplex, Data data) throws IloException{
		solveMineProb(cplex, data, null);
	}

	public boolean solveMineProb(IloCplex cplex, Data data, double gap, int time) throws IloException{
		return solveMineProb(cplex, data, gap, time, null);
	}
	//====================================================================
	public boolean solveMineProb(IloCplex cplex, Data data, double gap, int time, int[] TrCombo) 
	throws IloException {
		MyUtils Utils = new MyUtils(data.conf.filePrefix);	

		cplex.clearModel();		
		addConstraints(data, cplex, TrCombo);
		cplex.addMinimize(MV.ObjVar);

		//	cplex.exportModel("mine_"+mIdx+".lp");	
		initialiseSol(); //refreshing the object
		if(!Utils.solveAndRecord(cplex,  "Mine-"+mIdx, gap, time))
			return false;
		objcost = (double)cplex.getObjValue();
		writeOutputs(cplex, data);
		return true;
	}  

	public void solveMineProb(IloCplex cp, Data tmpData, int[] TrCombo) throws IloException {
		// TODO Auto-generated method stub
		solveMineProb(cp, tmpData, 0.0, 0, TrCombo); 
	}


	public boolean checkColumnFeasibility(IloCplex cplex, Data data, int idx) 
	throws IloException {
		MyUtils Utils = new MyUtils(data.conf.filePrefix);	

		cplex.clearModel();		
		addConstraints(data, cplex, null);
		cplex.addMinimize(MV.ObjVar);

		if(idx <0) idx = colVector.size()-1;

		int[][] TrReq = colVector.get(idx).TrRequest;
		for(int m=0; m < nTypes; m++){
			int cnt=0;
			for(int t=0; t <nPeriods; t++)
				if(TrReq[m][t] >0){
					cplex.addEq(MV.AQty[m][t], cnt+1);
					cplex.addEq(MV.AQty[m][t-1], cnt);
					cnt =cnt+1;
				}
			if(cnt==0)
				cplex.addEq(MV.AQty[m][nPeriods-1], 0);
		}


		if(!Utils.solveAndRecord(cplex,  "Mine-"+mIdx, 0, 0)){
			System.err.println(" Failed with mine model");
			return false;
		}
		objcost = (double)cplex.getObjValue();
		System.out.println(" Verified columns with mine model " +idx + " objcost "+ objcost+" regCost"+ colVector.get(idx).actcost );
		return true;
	}  



	public void addConstraints(Data data, IloCplex cplex) throws IloException{		
		addConstraints(data, cplex, null);
	}

	//====================================================================
	public void addConstraints(Data data, IloCplex cplex, int[] nUsedTrains) throws IloException{		

		Train[]  TrClass 	= data.TrClass;		
		int initialInv  = 0;
		boolean dummyFlag = ((TrClass[0].vol < 1)?  true: false);		

		MyUtils Utils = new MyUtils(data.conf.filePrefix);

		if(relax){
			MV.Inv         	= cplex.numVarArray(nPeriods, 0, Integer.MAX_VALUE);	     
			MV.OS     		= cplex.numVarArray(nPeriods, 0, Integer.MAX_VALUE);
			MV.Y  			= cplex.numVarArray(nPeriods, 0, 1); //Demurrage
			MV.AQty 		= new IloNumVar[nTypes][]; // Total number of requests by time t
			MV.ObjVar 		=  cplex.numVar(Integer.MIN_VALUE, Integer.MAX_VALUE);
		}
		else {
			MV.Inv         	= cplex.intVarArray(nPeriods, 0, Integer.MAX_VALUE);	     
			MV.OS     		= cplex.intVarArray(nPeriods, 0, Integer.MAX_VALUE);
			MV.Y  			= cplex.intVarArray(nPeriods, 0, 1); //Demurrage
			MV.AQty 		= new IloIntVar[nTypes][]; // Total number of requests by time t
			MV.ObjVar 		=  cplex.numVar(Integer.MIN_VALUE, Integer.MAX_VALUE);
		}

		for(int t=0; t < nPeriods ; t++){
			MV.Inv[t].setName("Inv("+mIdx+"_"+   t+")");                    
			MV.OS[t].setName("OS("+mIdx+"_"+ t+")");
			MV.Y[t].setName("Y("+mIdx+"_"+ t+")");
		}

		for(int m=0; m < nTypes; m++){
			if (relax){
				MV.AQty[m] = cplex.numVarArray(nPeriods, 0, nPeriods);
				//		MV.AQty[m][nPeriods-1] = cplex.intVar(0, 10);
			}
			else
				MV.AQty[m] = cplex.intVarArray(nPeriods, 0, nPeriods);


			for(int t=0; t < nPeriods ; t++){
				MV.AQty[m][t].setName("AQ("+mIdx+"_"+ m+"_"+  t+")");
			}			
		}
		MV.ObjVar.setName("Mine_ObjVar_"+mIdx);
		IloNumExpr  indMineObj = cplex.intExpr();

		for (int m = 0; m < nTypes; m++) 
			cplex.addEq(MV.AQty[m][0],0);

		for (int t = 1; t < nPeriods; t++) {

			cplex.addLe(MV.Inv[t], invCap);

			IloNumExpr  qtySum = cplex.intExpr();
			IloNumExpr  TrCnt = cplex.intExpr();
			qtySum = cplex.constant(0);                                                       
			TrCnt = cplex.constant(0);

			for (int m=0; m < nTypes; m++){
				cplex.addGe(MV.AQty[m][t],MV.AQty[m][t-1]).setName("AQ_Pre_"+mIdx+"_"+m+"_"+t);						

				qtySum = cplex.sum(qtySum, cplex.prod(cplex.diff(MV.AQty[m][t],MV.AQty[m][t-1]),(int)TrClass[m].vol));
				//Train count which are active
				TrCnt = cplex.sum(TrCnt,cplex.diff(MV.AQty[m][t],MV.AQty[m][Math.max(0, t -TrClass[m].lTime)]));                                                              
			}
			if(dummyFlag){
				if (t < nPeriods-1) cplex.addEq(TrCnt,1).setName("TrainCount_"+mIdx+"_"+t); // one loading at a time
				if (t ==1 & mIdx==0) System.out.println("Dummy train is present in system");
			}
			else
				cplex.addLe(TrCnt,1).setName("TrainCount_"+mIdx+"_"+t); // one loading at a time 


			//  modified balancing constraint. It says production ( diff in holding + shipped) should be less than UB
			cplex.addLe(cplex.sum(cplex.diff(MV.Inv[t], MV.Inv[t-1]), qtySum), prodCap).setName("Prod_Cap_"+mIdx+"_"+t);

			IloNumExpr  cumSupply1 = cplex.intExpr();
			cumSupply1 = cplex.constant(0);

			int minTrTime = nPeriods; 
			int [] UB_noTrains = new int[nTypes];
			IloNumExpr  cumSupplyInt = cplex.numExpr();

			for (int m=0; m < nTypes; m++){

				minTrTime = Math.min(minTrTime, TrClass[m].e_tau);
				int t1 		= Math.max(0,(t-TrClass[m].e_tau)) ;
				double b3 		= Math.min(t*prodCap +initialInv, Demand[nPeriods-1]+ TrClass[nTypes-1].vol) ;

				cumSupplyInt = cplex.sum(cumSupplyInt, 
						cplex.prod(MV.AQty[m][t1],Math.ceil(TrClass[m].vol/data.TrClass[0].vol)));

				// plan the production based on train availability( free)

				if (TrAvail[m][t]==1)
					cumSupply1 = cplex.sum(cumSupply1,cplex.prod(MV.AQty[m][t1],TrClass[m].vol));
				else
					cumSupply1 = cplex.sum(cumSupply1,cplex.prod(MV.AQty[m][Math.max(0,t1-Delay[m])],TrClass[m].vol));


				UB_noTrains[m] = Math.max(0, (int)Math.floor((float)b3 /TrClass[m].vol));

				cplex.addLe(MV.AQty[m][t], UB_noTrains[m]).setName("AQ_UB_ind");


				int[] tmpArray = Utils.subArray(TrClass, m);
				int gcd = Math.max(Utils.gcd(tmpArray),1);

				IloNumExpr newExpr= cplex.numExpr();

				if(m < nTypes-1){ // if m = nTypes -1, then there is only one term, that is already covered above
					int[] newCoeff = new int[nTypes-m];
					int rhs = (int) Math.max(0,Math.floor(b3/gcd));

					for(int m1= 0; m1 < newCoeff.length ; m1++)
						newCoeff[m1] = (int)TrClass[m1+m].vol/gcd;

					if (rhs >0) {
						for(int m1=m; m1 < nTypes; m1++)
							newExpr = cplex.sum(newExpr,cplex.prod(newCoeff[m1-m], MV.AQty[m1][t]));
						cplex.addLe(newExpr, rhs).setName("AQ_RecurUB_"+mIdx+"_"+m+"_"+t);
					}
				}

				if (t+TrClass[m].e_tau > nPeriods)
					cplex.addEq(MV.AQty[m][t],MV.AQty[m][t-1]).setName("AQ_Last_"+mIdx+"_"+m+"_"+t);	


				if(resConstraint){ //resource constraint
					// for each mine, class and time 
					int tEnd = Math.min(nPeriods-1, t+TrClass[m].sTime);
					int tStart = Math.max(0, t-TrClass[m].e_tau);	
					cplex.addLe(cplex.diff(MV.AQty[m][tEnd], MV.AQty[m][tStart]),TrClass[m].number).setName("LinkingConst_"+m+"_"+t);
				}		
			}


			for(int k=0 ; k < Order.length; k++){		
				int noTrainsReq = (int)Math.ceil(Order[k]/data.TrClass[0].vol);
				if((k== dueDate.length-1 && t >= dueDate[k]) || (dueDate[k] <= t && t < dueDate[k+1] ))
					cplex.addGe(cumSupplyInt, cplex.prod(noTrainsReq,cplex.diff(1.0, MV.Y[t]))).setName("Cut_"+k+"_"+t);
			}

			cplex.addGe(Demand[t], cplex.diff(cumSupply1,MV.OS[t])).setName("CumSupply_"+mIdx+"_"+t);


			float UB_OverStk = Math.max(0, (float)(t-minTrTime))*prodCap + initInv-Demand[t];
			//Overstock is limited with needed supply + max extra trip
			double UB2 =  Math.max(0, Math.min(UB_OverStk, Demand[nPeriods-1]- Demand[t]+ TrClass[nTypes-1].vol));

			cplex.addLe(MV.OS[t],  UB2).setName("OS_UB_"+mIdx+"_"+t); // upperbound for overstock

			//			//precedence of OS
			//			if (Demand[t]== Demand[t-1])
			//				cplex.addLe(MV.OS[t-1],MV.OS[t]).setName("OS_precedence_"+t);

			indMineObj = addCommonYConstraints(cplex, indMineObj, t, cumSupply1, TrClass[nTypes-1].vol);

			if(t==nPeriods-1){
				cplex.addGe(cumSupply1, Demand[t]).setName("Supply_T_"+mIdx);

				IloNumExpr  TrSum = cplex.intExpr();
				for (int m=0; m < nTypes; m++){
					TrSum = cplex.sum(TrSum, MV.AQty[m][t]);		
					if (TrClass[m].vol > 1)
						cplex.addLe(MV.AQty[m][t], Math.floor(Demand[t]/TrClass[m].vol)+1);							
				}
			}		
		} // t Loop


		cplex.addEq(MV.Y[nPeriods-1],0);// there should not be any demurrage at time T
		cplex.addEq(MV.Y[0],1);// there should not be any demurrage at time T

		cplex.addEq(MV.Inv[0], initInv);
		cplex.addEq(MV.OS[0], 0);
		cplex.addEq(MV.Inv[nPeriods-1], 0);

		for (int t = 0; t < nPeriods; t++){
			indMineObj = cplex.sum(indMineObj, cplex.prod(MV.Inv[t], hCostM));
			indMineObj = cplex.sum(indMineObj,cplex.prod(MV.OS[t], hCostT));
		}

		indMineObj = cplex.prod(indMineObj, 1.0/baseValue);

		for (int t = 0; t < nPeriods; t++){
			for (int m=0; m < nTypes; m++){
				IloNumExpr q = cplex.diff(MV.AQty[m][t],MV.AQty[m][Math.max(0,t-1)]);		
				//indMineObj = cplex.sum(indMineObj, cplex.prod(q,orderCost[m][t]));

				indMineObj = cplex.sum(indMineObj, cplex.prod(q,orderCost[m][t] -OC + OC/baseValue ));

				if (TrAvail[m][t]==0) //extra holding
					indMineObj = cplex.sum(indMineObj,  cplex.prod(cplex.prod(q, TrClass[m].vol),hCostM*Delay[m]));
			}
		}

		cplex.addEq(MV.ObjVar, indMineObj).setName("ObjVal_Const_"+mIdx);

		if (nUsedTrains != null)
			for(int m=0; m< nUsedTrains.length; m++)
				cplex.addEq(MV.AQty[m][nPeriods-1], nUsedTrains[m]).setName("AQ_T_"+m);

		//		//(0,119)_(0,122)_(0,130)_(0,133)_(0,141)
		//		 //(0,45)_(0,46)_(1,81)_(2,42)_(2,93)
		//		cplex.addEq(MV.AQty[0][45], 1); cplex.addEq(MV.AQty[0][44], 0);
		//		cplex.addEq(MV.AQty[0][46], 2); cplex.addEq(MV.AQty[0][45], 1);
		//		cplex.addEq(MV.AQty[1][81], 1); cplex.addEq(MV.AQty[1][80], 0);
		//		cplex.addEq(MV.AQty[2][42], 1); cplex.addEq(MV.AQty[2][41], 0);
		//		cplex.addEq(MV.AQty[2][93], 2); cplex.addEq(MV.AQty[2][92], 1);
		//cplex.addEq(MV.AQty[1][149], 0); cplex.addEq(MV.AQty[2][149], 0);
	}

	private IloNumExpr addCommonYConstraints(IloCplex cplex, IloNumExpr objtmp, int t, 
			IloNumExpr cumDelivery, double Vmax) throws IloException {
		return addCommonYConstraints(cplex, objtmp, t, cumDelivery, null, null, Vmax);
	}
	//====================================================================
	public IloNumExpr addCommonYConstraints(IloCplex cplex, IloNumExpr objtmp, int t, IloNumExpr cumDelivery, 
			IloNumVar[] Y, IloNumVar[] OS, double Vmax) throws IloException {

		// objtmp = addCommonYConstraints(cplex, null, objtmp, t, cumDelivery, 0, 0);
		if (Y == null){ 
			Y = MV.Y;
			OS = MV.OS;
		}

		for(int k =0; k <  Order.length; k++){
			if(t == dueDate[k]){
				if(k>0) cplex.addGe(cumDelivery,  Order[k-1]).setName("Order_"+(k-1)+"_should_be_met_before_"+t);
			}

			if ( (k < Order.length-1 &&  dueDate[k] < t && t < dueDate[k+1] ) ||
					(k==Order.length-1 && t > dueDate[k] ))
				cplex.addGe(Y[t-1], Y[t]).setName("YPreced_"+t);
		}
		if(t>= dueDate[0]){
			objtmp = cplex.sum(objtmp, cplex.prod(Y[t], demCost));
			cplex.addGe(cplex.prod(Demand[t], Y[t]), cplex.diff(Demand[t], cumDelivery));
		}

		cplex.addLe(Y[t], cplex.diff(1, cplex.prod(OS[t], 1.0/(Math.min(t*prodCap, Demand[Y.length-1]+Vmax)) )));
		return objtmp;
	}


	public void writeOutputs(IloCplex cplex, Data data) throws IloException{
		writeOutputs(cplex, data, 0);
	}
	public void writeOutputs(IloCplex cplex, Data data, int solNo) throws IloException{

		MyUtils Utils = new MyUtils(data.conf.filePrefix);		

		DecimalFormat fourDec = new DecimalFormat("#.####");		
		String toPrint = "\n ## Mine-"+mIdx+" ##\n";                                              

		toPrint += "Requests (time, Train): ";

		initialiseSol();
		sol.ProdPlan[0] =0;
		int[] SolInv  = new int[nPeriods];
		if(!relax){			
			sol.SolY = new int[nPeriods];
		}

		for (int t =0; t < nPeriods; t++){

			double currSupply = 0;			
			for(int k=0; k < nTypes; k++ ){				
				if(t>0)
					sol.TrRequest[k][t] = Math.round((float)(cplex.getValue(MV.AQty[k][t], solNo)-cplex.getValue(MV.AQty[k][t-1], solNo)));
				else
					sol.TrRequest[k][t] = 0;

				if (sol.TrRequest[k][t] >0){
					currSupply += data.TrClass[k].vol;
					toPrint += "("+t + ", "+k+") \t";
				}				
			}

			if(!relax){
				SolInv[t] = 	 Math.round((float) cplex.getValue(MV.Inv[t], solNo));		
				if (t>0)
					sol.ProdPlan[t] = SolInv[t]- SolInv[t-1]+currSupply;			
				sol.SolY[t] =  Math.round((float) cplex.getValue(MV.Y[t], solNo));
			}
		}
		double totalinv=0;
		double totalhT=0;
		double totaldem=0;
		double ordercost=0;
		double orgordercost=0;

		for (int t =0; t < nPeriods; t++){
			totalinv +=  Math.round((float)cplex.getValue(MV.Inv[t], solNo));                                                                 
			totalhT +=  Math.round((float)cplex.getValue(MV.OS[t], solNo));
			for(int k=0; k < nTypes; k++ ){				
				ordercost +=  sol.TrRequest[k][t]*orderCost[k][t]; // It may vary time to time
				orgordercost +=sol.TrRequest[k][t]*OC; // It may vary time to time
			}
		}


		for (int t = dueDate[0]; t < nPeriods; t++)
			totaldem +=  Math.round((float)cplex.getValue(MV.Y[t], solNo));	

		double TotCost = totalinv*hCostM+ totalhT*hCostT+ totaldem*demCost+ordercost;
		sol.actcost = (int)Math.round(TotCost - ordercost+ orgordercost);

		toPrint += "\nObj("+mIdx+") = " + fourDec.format(TotCost) + "  = "+ totalinv*hCostM +"(InvHM)+ "
		+totalhT*hCostT  +"(InvHT)+ " + totaldem*demCost +"(Dem)+"+ fourDec.format(ordercost) +"(Order)";    
		toPrint += "\n ------------------------------- \n";		

		if(msgflag){
			Utils.printf(toPrint);
			System.out.println(toPrint);
		}

		for(int t=0; t < nPeriods; t++){
			//int trs_needed_t = 0;
			for(int m=0; m < nTypes; m++){
				int tEnd = Math.min(nPeriods-1, t+data.TrClass[m].sTime);
				int tStart = Math.max(0, t-data.TrClass[m].e_tau);	
				sol.noRunningTrains[m][t] = (int)Math.round((cplex.getValue(MV.AQty[m][tEnd], solNo)-cplex.getValue(MV.AQty[m][tStart], solNo)));	
				if(t == nPeriods-1)
					sol.TrCombo[m] = (int)Math.round(cplex.getValue(MV.AQty[m][t], solNo));
			}
		}
		sol.source ="Mine";
	}

	public double[] createProdPlan (RailOpr RO, Data data){
		double[] ProdPlan = new double[nPeriods];

		int[] reqInv = new int[nPeriods];
		int[] jump  = new int[nPeriods];

		for(int i=0; i< data.nMines; i++){
			for(int t=0; t< nPeriods; t++){
				ProdPlan[t] =0;
				reqInv[t] = 0;
				jump[t]= 0;
			}
		}

		Job[]  Jobsi = RO.getJobsOfMine(mIdx);
		for(Job j: Jobsi){
			int time = j.cDate - j.jTime + j.pTime; //arrival			
			int told = time;
			if(time  < 1) 	continue; //means that job is not done
			reqInv[time] += j.vol;					
			ProdPlan[time] = data.mine[mIdx].prodCap;

			while(reqInv[time] > 0){					
				time--;			
				int newVal = (reqInv[time+1] - data.mine[mIdx].prodCap); 	
				if (jump[time] ==0 && newVal< 0)
					break;
				reqInv[time] = jump[time] + newVal;						
			}				
			jump[told-1] = (int) j.vol;
			reqInv[told] -= (int) j.vol;
		}
		for(int t=1; t< nPeriods; t++){
			ProdPlan[t] += Math.max(0, (reqInv[t]-reqInv[t-1]));
		}
		return ProdPlan;
	}

	public double computeActualCost(RailOpr RO, Data data){
		initialiseSol(); 
		sol.ProdPlan = createProdPlan(RO, data);
		// original global costs
		double[] InvHolding = new double[RO.Tmax];
		double[] cumsupply = new double[RO.Tmax];


		int[] Cost = new int[4];
		int nJobs = RO.Jobs.length;
		MyUtils Utils = new MyUtils(data.conf.filePrefix);

		InvHolding[0] =0;				
		cumsupply[0]=0;
		for(int a =0; a< Cost.length; a++)
			Cost[a] =0;

		for(int t=1; t< RO.Tmax; t++) {
			cumsupply[t]= cumsupply[t-1];
			InvHolding[t] =InvHolding[t-1] ;
			if (t < nPeriods){
				InvHolding[t] +=  sol.ProdPlan[t];
				sol.SolY[t] = 0;
			}

			for(int j=0; j < nJobs; j++){	
				int k = RO.Jobs[j].tIdx;
				int elapTime = data.TrClass[k].e_tau;

				if ( ( RO.Jobs[j].mIdx!= mIdx))
					continue;// No need to proceed with the following check if the above condition is not met


				if ( (t+elapTime < RO.Tmax) && RO.JobSched[j][t+elapTime]- RO.JobSched[j][t-1+elapTime] ==1)
					InvHolding[t] -= data.TrClass[k].vol;

				if (RO.JobSched[j][t]-RO.JobSched[j][t-1]==1){
					cumsupply[t] += data.TrClass[k].vol;
					if(t-RO.Jobs[j].eTau > data.nPeriods-1)
						sol.TrRequest[k][data.nPeriods-1]=100;
					else
						sol.TrRequest[k][t-RO.Jobs[j].eTau]=1;
				}
			}
		}

		//After setting only we can compute the cost
		for(int t=1; t< nPeriods; t++) {
			Cost[0] += InvHolding[t]*hCostM; 		// inv holding 	
			Cost[1] += Math.max(0,cumsupply[t]-Demand[t])*hCostT; 		// holding at terminal}
			for(int m=0; m < nTypes; m++)
				Cost[3] += sol.TrRequest[m][t]*OC;// orderCost[m][t];
		}

		for(int j=0; j < nJobs; j++){	
			if (RO.Jobs[j].mIdx!= mIdx) continue;
			sol.TrCombo[RO.Jobs[j].tIdx]++;
			for(int t = RO.Jobs[j].cDate -1; t >= RO.Jobs[j].cDate - RO.Jobs[j].jTime; t--){
				if(t >= data.nPeriods) continue;
				sol.noRunningTrains[RO.Jobs[j].tIdx][t]++;
			}
		}	

		for(int t= 0; t< nPeriods; t++) {
			if ( Demand[t]-1e-6 > cumsupply[t] ){
				Cost[2] += demCost;	// demurrage
				sol.SolY[t] =1;
			}
		}

		double ActCost=0;
		for(int a =0; a< Cost.length; a++)
			ActCost += Cost[a];

		String toPrint = "ActualCost("+mIdx+") = " + ActCost + "  = "+ Cost[0] +"(InvHM)+ "
		+Cost[1] +"(InvHT)+ " +Cost[2] +"(Dem)+"+ Cost[3] +"(Order)";    

		Utils.printf(toPrint);
		//	System.out.println(toPrint);
		sol.actcost = ActCost;
		sol.source ="Rail";
		addColumnAndValue(0);
		return ActCost;
	}

	//===========================================================================
	public void initTrAvailAndDelay(Data data) {

		TrAvail = new int[nTypes][nPeriods];			
		Delay = new int[nTypes];
		for(int k=0; k< nTypes; k++){
			Delay[k]=0;
			for (int t =0; t < nPeriods; t++)					
				TrAvail[k][t] = 1;
		}
	}


	public void addAllColumns(IloCplex cplex, Data data) throws IloException{

		int NSols = cplex.getSolnPoolNsolns();
		// if(dualPrice ==0) 
	//	 NSols =1;
		for(int n=NSols-1; n >=0 ; n--){
			//	System.out.println("Obj "+n+" \t "+ Math.round(cplex.getObjValue(n)) + "\t DualPrice "+ Math.round(dualPrice));
			//	if(dualPrice !=0 && (cplex.getObjValue(n)- dualPrice) > -1e-3) continue;
			writeOutputs(cplex, data, n);
			addColumnAndValue(n);
		}
	}

	public void initialiseSol(){
		sol = new MineSol();				
	}
	public String getMineSolnString(int idx){

		MineSol tmpS = sol;
		if(idx >=0)
			tmpS =allColumns.get(idx);
		String cost_str = "M-"+mIdx+" "+ tmpS.key_str+"_Cost="+((int)tmpS.actcost*baseValue)+"_Ratio_"+ (tmpS.actcost);
		return cost_str;
	}
	public void addColumnAndValue(int no) {

		String cost_str = "";// +((int)sol.actcost);
		for(int m=0; m< nTypes; m++)
			for(int t=0; t< nPeriods; t++)
				if(sol.TrRequest[m][t]==1) // arrival time
					cost_str += "_("+m+","+t+")";

		sol.key_str = cost_str;
		sol.actcost = sol.actcost/baseValue;// normalising
		if( checkedSolution.contains(sol.actcost+cost_str)){
			//	System.out.println("Col exists " + cost_str+ " or not good " + sol.actcost);
			return;
		}else
			checkedSolution.add(sol.actcost+cost_str);


		if ( !lpColList.contains(cost_str) &&  !colVector.contains(sol)){
			colVector.addElement(sol);			
			lpColList.add(cost_str);	
			//	System.out.println("Adding column "+(colVector.size()-1) + " in M"+ mIdx  + " key "+ cost_str+ " cost "+ sol.actcost);							
		} 
		else{			
			int idx = lpColList.indexOf(cost_str);
			if (colVector.get(idx).actcost > sol.actcost){
				//				System.out.println("Replacing "+idx+" with key "+
				//						cost_str+" :: "+colVector.get(idx).actcost+" with " + sol.actcost);
				colVector.remove(idx);
				lpColList.remove(idx);				
				colVector.insertElementAt(sol, idx);			
				lpColList.insertElementAt(cost_str, idx);
			}
		}

		if (!mipColList.contains(new String(cost_str)) &&  !allColumns.contains(sol)){
			allColumns.addElement(sol);
			mipColList.add(cost_str);
		}
		else{			
			int idx = mipColList.indexOf(cost_str);
			if (allColumns.get(idx).actcost > sol.actcost){
				allColumns.remove(idx);
				mipColList.remove(idx);				
				allColumns.insertElementAt(sol, idx);			
				mipColList.insertElementAt(cost_str, idx);
			}
		}

	}
	public double getActualCost() {
		// TODO Auto-generated method stub
		return sol.actcost;
	}
	public MineSol getCurrentSolution() {
		// TODO Auto-generated method stub
		return sol;
		//return colVector.get(currSolIdx);
	}
	public void setSolution(MineSol sol1) {
		// TODO Auto-generated method stub
		sol = sol1;
	}
	public int getIdx_mipcol_list() {
		// TODO Auto-generated method stub
		return mipColList.indexOf(sol.key_str);
	}
	public void setBaseValue(IloCplex cp, Data td) throws IloException {
		msgflag = false;
		cp.clearModel();	
		solveMineProb(cp, td);		
		this.baseValue =  Math.round(cp.getObjValue());
		this.objcost = objcost/baseValue;
		System.out.println("Mine "+mIdx+ " basevalue = "+ baseValue);
	}
	public double getBaseValue() {
		return baseValue;
	}
}
