package imura;

import java.util.*;

public class Solution {


	double bestUB;
	double bestLB;
	double gap = 100000;
	double[] currUB;
	double[] currLB;
	int[] ChoiceArray;
	String[] PatStrArray;
	int[] viol;
	private double[][][] bestLambda;
	private double[][]bestDual;
	Data tdata;

	HashSet <String> evaluatedPatX= new HashSet <String>();
	HashSet <String> evaluatedPat= new HashSet <String>();

	Solution(int itrLimit, Data td){
		tdata = td;
		bestUB = 2e10; 
		bestLB = 0; 
		currUB = new double[itrLimit]; 
		currLB = new double[itrLimit]; 
		ChoiceArray = new int[itrLimit];
		viol = new int[itrLimit];
		PatStrArray = new String[itrLimit];		
		setBestLambda(new double[td.nMines][td.nTypes][td.nPeriods]);
	}



	public void setBestLambda(double[][][] bestLambda) {
		int[] size = {bestLambda.length, bestLambda[0].length, bestLambda[0][0].length};
		double[][][] tmpLambda =  new double[size[0]][size[1]][size[2]];
		for(int i=0; i < size[0] ; i++)
			for(int j=0; j < size[1] ; j++)		
				System.arraycopy( bestLambda[i][j], 0, tmpLambda[i][j], 0, bestLambda[i][j].length );				

		this.bestLambda =  tmpLambda;
	}

	public double[][][] getBestLambda() {

		int[] size = {bestLambda.length, bestLambda[0].length, bestLambda[0][0].length};
		double[][][] tmpLambda =  new double[size[0]][size[1]][size[2]];
		for(int i=0; i < size[0] ; i++)
			for(int j=0; j < size[1] ; j++)		
				System.arraycopy( bestLambda[i][j], 0, tmpLambda[i][j], 0, bestLambda[i][j].length );				
		return tmpLambda;
	}
	
	public void setBestDual(double[][] bestDual) {
		int[] size = {bestDual.length, bestDual[0].length};
		double[][] tmpDual =  new double[size[0]][size[1]];
		for(int i=0; i < size[0] ; i++)		
				System.arraycopy( bestDual[i], 0, tmpDual[i], 0, bestDual[i].length );				

		this.bestDual =  tmpDual;
	}

	public double[][] getBestDual() {

		int[] size = {bestDual.length, bestDual[0].length};
		double[][] tmpDual =  new double[size[0]][size[1]];
		for(int i=0; i < size[0] ; i++)
				System.arraycopy( bestDual[i], 0, tmpDual[i], 0, bestDual[i].length );				
		return tmpDual;
	}
}
