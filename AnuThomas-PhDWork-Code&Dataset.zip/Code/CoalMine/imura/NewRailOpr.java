package imura;


import java.util.ArrayList;
import java.util.List;

import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloNumVar;
import ilog.cplex.IloCplex;
import imura.NewRailOpr.Job;

public class NewRailOpr {

	int Tmax;
	int nJobs;
	int nTrains;
	int[][] TrAvailability;

	// boolean ch= 1; 

	Job[]  Jobs;
	int[][] JobSched;
	double ObjVal;
	int objScaling = 100;

	public class Job { //Mine class
		int rDate; //holding cost at mine
		int reachTime; // the time in which it is requested from the mines
		int dDate;
		int jTime; // journey time
		int pTime; // processing time
		int lTime; // loading time
		int sTime; // loading time
		int cDate;// actual completion date 
		int mIdx;// associated mine
		int tIdx;// associated train class	
		int eTau;
		int wgt;
		int idx;
		double vol;
	}

	//=================================================================================================

	public int[][][]  makeJobsFromPattern(Data data, Pattern P) throws IloException{

		int[] pat = P.getNewpattern();
		int[][] usedTrs = new int[data.nMines][data.nTypes];
		double[] totSupply = new double [data.nMines];
		int[][][]  JobClass =  new int[data.nMines][data.nTypes][];

		int jCnter=0;
		for (int i=0; i < data.nMines; i++)		{
			totSupply[i] =0;
			usedTrs[i] = P.getIntPattern(i, pat);			
			for(int k=0; k< data.nTypes; k++){
				JobClass[i][k] =  new int[usedTrs[i][k]];
				jCnter += usedTrs[i][k];
				totSupply[i] += usedTrs[i][k]*data.TrClass[k].vol;
			}
		}

		Jobs =  new Job[jCnter];
		nJobs = jCnter;

		for(int j=0; j < Jobs.length; j++)
			Jobs[j]=  new Job();


		jCnter=0;	
		for (int i=0; i < data.nMines; i++)	{			
			for(int m=0; m < data.nTypes; m++ )	{
				for(int u=0; u < usedTrs[i][m]; u++){
					//					System.out.println(" Job "+jCnter+" Mine - "+i+" TrainClass " + k);
					JobClass[i][m][u] = jCnter;
					Jobs[jCnter].mIdx = i;
					Jobs[jCnter].tIdx = m;									
					Jobs[jCnter].rDate = (int)Math.ceil((float)data.TrClass[m].vol/data.mine[i].prodCap)-data.TrClass[m].sTime;  
					Jobs[jCnter].pTime = data.TrClass[m].pTime;
					Jobs[jCnter].sTime = data.TrClass[m].pTime;
					Jobs[jCnter].lTime = data.TrClass[m].lTime;
					Jobs[jCnter].jTime = data.TrClass[m].g_tau;
					Jobs[jCnter].dDate = Jobs[jCnter].rDate + Jobs[jCnter].jTime ;	
					Jobs[jCnter].eTau = data.TrClass[m].lTime +data.TrClass[m].pTime;
					Jobs[jCnter].wgt = 1; 
					Jobs[jCnter].vol = data.TrClass[m].vol;
					Jobs[jCnter].idx = jCnter;
					jCnter++;
				}
			}	
		}		
		System.out.println("Number of jobs from pattern = "+jCnter);
		return JobClass;
	}

	//================================================================================================================================
	public void makeJobs(Data data){

		Mine[] M = data.mine;

		int jCnt=0; // job counter		
		int totalDemand=0;
		for (int i=0; i < data.nMines; i++)		{
			for (int t =0; t < data.nPeriods; t++)
				for(int k=0; k < data.nTypes; k++ )
					if (M[i].TrReq[k][t]==1)// all are boolean values
						jCnt++ ; 		
			totalDemand += M[i].Order[M[i].Order.length-1];		
		}		

		Jobs =  new Job[jCnt];
		nJobs = jCnt;

		for(int j=0; j < Jobs.length; j++)
			Jobs[j]=  new Job();	


		jCnt=0;
		for (int t =0; t < data.nPeriods; t++)
			for (int i=0; i < data.nMines; i++)	{			
				for(int k=0; k < data.nTypes; k++ )
					if (M[i].TrReq[k][t]>0) {
						Jobs[jCnt].reachTime = t;
						Jobs[jCnt].mIdx = i;
						Jobs[jCnt].tIdx = k;
						Jobs[jCnt].rDate =  Math.max(1,t-data.TrClass[Jobs[jCnt].tIdx].sTime); // no jobs before t=1
						Jobs[jCnt].pTime = data.TrClass[k].pTime;
						Jobs[jCnt].lTime = data.TrClass[k].lTime;
						Jobs[jCnt].jTime = data.TrClass[k].g_tau;
						Jobs[jCnt].dDate = Jobs[jCnt].rDate + Jobs[jCnt].jTime ;
						Jobs[jCnt].vol   = data.TrClass[k].vol;
						Jobs[jCnt].wgt = 1;
						Jobs[jCnt].idx = jCnt;
						
					
						Jobs[jCnt].sTime = data.TrClass[k].pTime;
						Jobs[jCnt].eTau = data.TrClass[k].lTime +data.TrClass[k].pTime;
				
						
						jCnt++;
					}	
			}
		System.out.println("Number of jobs = "+jCnt);
	}


	// called from main file under choice 8
	public double solveWithListHeuristic(IloCplex cplex, Data data, Pattern P) throws IloException{
	
		cplex.clearModel();	

		makeJobs(data);
		Tmax =  data.nPeriods;

		return listHeuristic(cplex, data);
	}



	public double listHeuristic(IloCplex cplex, Data data) throws IloException{
		int nMines = data.nMines;
		int nTypes  = data.nTypes;

		List<Job>  jobList = new ArrayList<Job>();
		for(Job j : Jobs)
			jobList.add(j);

		boolean[][] mineBusy = new boolean[nMines][Tmax];
		int[][] mineProd  = new int[nMines][Tmax];
		int[][] trainAvail  = new int[nTypes][Tmax];


		for(int t=0; t< Tmax; t++){
			for(int i=0; i < nMines; i++){		
				mineProd[i][t] = t*data.mine[i].prodCap;
				mineBusy[i][t] = (t >0? false: true);
			}
			for(int k=0; k < nTypes; k++)
				trainAvail[k][t] = (t >0 ? data.TrClass[k].number: 0);
		}




		for(int t= 0; t< Tmax; t++){
			//	System.out.println(" Time-"+t);
			int jcnt =  jobList.size();
			int idx = 0;
			while(jcnt >0){
				Job j = jobList.get(idx);
				if(mineProd[j.mIdx][t] >= j.vol && !mineBusy[j.mIdx][t]  && trainAvail[j.tIdx][t-j.sTime] > 0){
				//	System.out.println("Assigning job-"+j.idx+" at time "+t);
					j.cDate = t+j.eTau;

					for(int t1=t; t1 < Tmax; t1++)
						mineProd[j.mIdx][t1] -= j.vol;

					for(int t1=t; t1 < Math.min(Tmax,t+j.lTime); t1++)
						mineBusy[j.mIdx][t1] = true;
					for(int t1= t-j.sTime; t1 < Math.min(Tmax, t+j.eTau); t1++)
						trainAvail[j.tIdx][t1] --;

					jobList.remove(j);
				}
				else
					idx++;	
				jcnt--;					
				//	System.out.print("\t "+j.idx);
			}
		}

		double objVal = verifyWithCM(cplex, data);

		System.out.println("ObjCost = "+ objVal);
		
		writeOutputs(data.conf.filePrefix);
		return objVal;
	}



	private void fix_a_solution(IloCplex cplex, IloNumVar[][] Z) throws IloException {

		System.out.println("Fixing a solution.....");

		//		cplex.addEq(Z[0][41],1);	cplex.addEq(Z[1][48],1);	cplex.addEq(Z[2][59],1);	cplex.addEq(Z[3][63],1);	cplex.addEq(Z[4][98],1);	cplex.addEq(Z[5][22],1);	cplex.addEq(Z[6][36],1);	cplex.addEq(Z[7][92],1);	cplex.addEq(Z[8][97],1);	cplex.addEq(Z[9][45],1);	cplex.addEq(Z[10][110],1);	cplex.addEq(Z[11][131],1);	cplex.addEq(Z[12][134],1);	cplex.addEq(Z[13][134],1);	cplex.addEq(Z[14][61],1);	cplex.addEq(Z[15][110],1);	cplex.addEq(Z[16][52],1);	cplex.addEq(Z[17][56],1);	cplex.addEq(Z[18][91],1);	cplex.addEq(Z[19][100],1);	cplex.addEq(Z[20][102],1);	cplex.addEq(Z[21][55],1);	cplex.addEq(Z[22][120],1);	cplex.addEq(Z[23][131],1);	cplex.addEq(Z[24][37],1);	cplex.addEq(Z[25][76],1);	cplex.addEq(Z[26][87],1);	cplex.addEq(Z[27][50],1);	cplex.addEq(Z[28][64],1);	cplex.addEq(Z[29][83],1);	cplex.addEq(Z[30][28],1);	cplex.addEq(Z[31][42],1);	cplex.addEq(Z[32][69],1);	cplex.addEq(Z[33][80],1);	cplex.addEq(Z[34][87],1);	cplex.addEq(Z[35][27],1);	cplex.addEq(Z[36][41],1);	cplex.addEq(Z[37][67],1);	cplex.addEq(Z[38][74],1);	cplex.addEq(Z[39][111],1);	cplex.addEq(Z[40][69],1);	cplex.addEq(Z[41][78],1);	cplex.addEq(Z[42][106],1);	cplex.addEq(Z[43][111],1);
		//		cplex.addEq(Z[0][40],0);	cplex.addEq(Z[1][47],0);	cplex.addEq(Z[2][58],0);	cplex.addEq(Z[3][62],0);	cplex.addEq(Z[4][97],0);	cplex.addEq(Z[5][21],0);	cplex.addEq(Z[6][35],0);	cplex.addEq(Z[7][91],0);	cplex.addEq(Z[8][96],0);	cplex.addEq(Z[9][44],0);	cplex.addEq(Z[10][109],0);	cplex.addEq(Z[11][130],0);	cplex.addEq(Z[12][133],0);	cplex.addEq(Z[13][133],0);	cplex.addEq(Z[14][60],0);	cplex.addEq(Z[15][109],0);	cplex.addEq(Z[16][51],0);	cplex.addEq(Z[17][55],0);	cplex.addEq(Z[18][90],0);	cplex.addEq(Z[19][99],0);	cplex.addEq(Z[20][101],0);	cplex.addEq(Z[21][54],0);	cplex.addEq(Z[22][119],0);	cplex.addEq(Z[23][130],0);	cplex.addEq(Z[24][36],0);	cplex.addEq(Z[25][75],0);	cplex.addEq(Z[26][86],0);	cplex.addEq(Z[27][49],0);	cplex.addEq(Z[28][63],0);	cplex.addEq(Z[29][82],0);	cplex.addEq(Z[30][27],0);	cplex.addEq(Z[31][41],0);	cplex.addEq(Z[32][68],0);	cplex.addEq(Z[33][79],0);	cplex.addEq(Z[34][86],0);	cplex.addEq(Z[35][26],0);	cplex.addEq(Z[36][40],0);	cplex.addEq(Z[37][66],0);	cplex.addEq(Z[38][73],0);	cplex.addEq(Z[39][110],0);	cplex.addEq(Z[40][68],0);	cplex.addEq(Z[41][77],0);	cplex.addEq(Z[42][105],0);	cplex.addEq(Z[43][110],0);

		//		cplex.addEq(Z[0][20],1);	cplex.addEq(Z[1][21],1);	cplex.addEq(Z[2][29],1);	cplex.addEq(Z[3][37],1);	cplex.addEq(Z[4][96],1);	cplex.addEq(Z[5][52],1);	cplex.addEq(Z[6][66],1);	cplex.addEq(Z[7][94],1);	cplex.addEq(Z[8][106],1);	cplex.addEq(Z[9][43],1);	cplex.addEq(Z[10][109],1);	cplex.addEq(Z[11][110],1);	cplex.addEq(Z[12][134],1);	cplex.addEq(Z[13][120],1);	cplex.addEq(Z[14][46],1);	cplex.addEq(Z[15][134],1);	cplex.addEq(Z[16][99],1);	cplex.addEq(Z[17][115],1);	cplex.addEq(Z[18][123],1);	cplex.addEq(Z[19][130],1);	cplex.addEq(Z[20][131],1);	cplex.addEq(Z[21][38],1);	cplex.addEq(Z[22][50],1);	cplex.addEq(Z[23][134],1);	cplex.addEq(Z[24][41],1);	cplex.addEq(Z[25][76],1);	cplex.addEq(Z[26][77],1);	cplex.addEq(Z[27][22],1);	cplex.addEq(Z[28][36],1);	cplex.addEq(Z[29][92],1);	cplex.addEq(Z[30][63],1);	cplex.addEq(Z[31][31],1);	cplex.addEq(Z[32][42],1);	cplex.addEq(Z[33][86],1);	cplex.addEq(Z[34][87],1);	cplex.addEq(Z[35][24],1);	cplex.addEq(Z[36][78],1);	cplex.addEq(Z[37][61],1);	cplex.addEq(Z[38][74],1);	cplex.addEq(Z[39][104],1);	cplex.addEq(Z[40][64],1);	cplex.addEq(Z[41][80],1);	cplex.addEq(Z[42][108],1);	cplex.addEq(Z[43][122],1);
		//		cplex.addEq(Z[0][19],0);	cplex.addEq(Z[1][20],0);	cplex.addEq(Z[2][28],0);	cplex.addEq(Z[3][36],0);	cplex.addEq(Z[4][95],0);	cplex.addEq(Z[5][51],0);	cplex.addEq(Z[6][65],0);	cplex.addEq(Z[7][93],0);	cplex.addEq(Z[8][105],0);	cplex.addEq(Z[9][42],0);	cplex.addEq(Z[10][108],0);	cplex.addEq(Z[11][109],0);	cplex.addEq(Z[12][133],0);	cplex.addEq(Z[13][119],0);	cplex.addEq(Z[14][45],0);	cplex.addEq(Z[15][133],0);	cplex.addEq(Z[16][98],0);	cplex.addEq(Z[17][114],0);	cplex.addEq(Z[18][122],0);	cplex.addEq(Z[19][129],0);	cplex.addEq(Z[20][130],0);	cplex.addEq(Z[21][37],0);	cplex.addEq(Z[22][49],0);	cplex.addEq(Z[23][133],0);	cplex.addEq(Z[24][40],0);	cplex.addEq(Z[25][75],0);	cplex.addEq(Z[26][76],0);	cplex.addEq(Z[27][21],0);	cplex.addEq(Z[28][35],0);	cplex.addEq(Z[29][91],0);	cplex.addEq(Z[30][62],0);	cplex.addEq(Z[31][30],0);	cplex.addEq(Z[32][41],0);	cplex.addEq(Z[33][85],0);	cplex.addEq(Z[34][86],0);	cplex.addEq(Z[35][23],0);	cplex.addEq(Z[36][77],0);	cplex.addEq(Z[37][60],0);	cplex.addEq(Z[38][73],0);	cplex.addEq(Z[39][103],0);	cplex.addEq(Z[40][63],0);	cplex.addEq(Z[41][79],0);	cplex.addEq(Z[42][107],0);	cplex.addEq(Z[43][121],0);



		//P7
		//			cplex.addEq(Z[0][75],1);	cplex.addEq(Z[1][97],1);	cplex.addEq(Z[3][50],1);	cplex.addEq(Z[4][63],1);	cplex.addEq(Z[5][42],1);	cplex.addEq(Z[6][53],1);	cplex.addEq(Z[7][64],1);	cplex.addEq(Z[8][119],1);	cplex.addEq(Z[9][130],1);	cplex.addEq(Z[10][64],1);	cplex.addEq(Z[11][97],1);	cplex.addEq(Z[12][99],1);		cplex.addEq(Z[14][32],1);	cplex.addEq(Z[15][86],1);	cplex.addEq(Z[16][149],0);		cplex.addEq(Z[18][49],1);	cplex.addEq(Z[19][60],1);	cplex.addEq(Z[20][115],1);	cplex.addEq(Z[21][36],1);	cplex.addEq(Z[22][44],1);	cplex.addEq(Z[23][81],1);	cplex.addEq(Z[24][108],1);		cplex.addEq(Z[26][112],1);	cplex.addEq(Z[27][57],1);		cplex.addEq(Z[29][41],1);	cplex.addEq(Z[30][48],1);
		//			cplex.addEq(Z[0][74],0);	cplex.addEq(Z[1][96],0);		cplex.addEq(Z[3][49],0);	cplex.addEq(Z[4][62],0);	cplex.addEq(Z[5][41],0);	cplex.addEq(Z[6][52],0);	cplex.addEq(Z[7][63],0);	cplex.addEq(Z[8][118],0);	cplex.addEq(Z[9][129],0);	cplex.addEq(Z[10][63],0);	cplex.addEq(Z[11][96],0);	cplex.addEq(Z[12][98],0);		cplex.addEq(Z[14][31],0);	cplex.addEq(Z[15][85],0);			cplex.addEq(Z[18][48],0);	cplex.addEq(Z[19][59],0);	cplex.addEq(Z[20][114],0);	cplex.addEq(Z[21][35],0);	cplex.addEq(Z[22][43],0);	cplex.addEq(Z[23][80],0);	cplex.addEq(Z[24][107],0);		cplex.addEq(Z[26][111],0);	cplex.addEq(Z[27][56],0);		cplex.addEq(Z[29][40],0);	cplex.addEq(Z[30][47],0);


		//p8			
		//			cplex.addEq(Z[0][84],1);	cplex.addEq(Z[1][95],1);	cplex.addEq(Z[2][59],1);	cplex.addEq(Z[3][64],1);	cplex.addEq(Z[4][40],1);	cplex.addEq(Z[5][62],1);	cplex.addEq(Z[6][73],1);	cplex.addEq(Z[7][117],1);	cplex.addEq(Z[8][128],1);		cplex.addEq(Z[10][73],1);	cplex.addEq(Z[11][22],1);	cplex.addEq(Z[12][36],1);	cplex.addEq(Z[13][97],1);	cplex.addEq(Z[14][99],1);			cplex.addEq(Z[17][50],1);	cplex.addEq(Z[18][113],1);	cplex.addEq(Z[19][115],1);	cplex.addEq(Z[20][60],1);	cplex.addEq(Z[21][30],1);	cplex.addEq(Z[22][44],1);	cplex.addEq(Z[23][81],1);	cplex.addEq(Z[24][80],1);	cplex.addEq(Z[25][29],1);	cplex.addEq(Z[26][51],1);	cplex.addEq(Z[27][106],1);		cplex.addEq(Z[29][112],1);	cplex.addEq(Z[30][46],1);	cplex.addEq(Z[31][48],1);
		//			cplex.addEq(Z[0][83],0);	cplex.addEq(Z[1][94],0);	cplex.addEq(Z[2][58],0);	cplex.addEq(Z[3][63],0);	cplex.addEq(Z[4][39],0);	cplex.addEq(Z[5][61],0);	cplex.addEq(Z[6][72],0);	cplex.addEq(Z[7][116],0);	cplex.addEq(Z[8][127],0);		cplex.addEq(Z[10][72],0);	cplex.addEq(Z[11][21],0);	cplex.addEq(Z[12][35],0);	cplex.addEq(Z[13][96],0);	cplex.addEq(Z[14][98],0);			cplex.addEq(Z[17][49],0);	cplex.addEq(Z[18][112],0);	cplex.addEq(Z[19][114],0);	cplex.addEq(Z[20][59],0);	cplex.addEq(Z[21][29],0);	cplex.addEq(Z[22][43],0);	cplex.addEq(Z[23][80],0);	cplex.addEq(Z[24][79],0);	cplex.addEq(Z[25][28],0);	cplex.addEq(Z[26][50],0);	cplex.addEq(Z[27][105],0);		cplex.addEq(Z[29][111],0);	cplex.addEq(Z[30][45],0);	cplex.addEq(Z[31][47],0);


		//
		//			//P8
		cplex.addEq(Z[0][91],1);	cplex.addEq(Z[1][102],1);	cplex.addEq(Z[2][61],1);	cplex.addEq(Z[3][63],1);	cplex.addEq(Z[4][58],1);	cplex.addEq(Z[5][69],1);	cplex.addEq(Z[6][80],1);	cplex.addEq(Z[7][124],1);	cplex.addEq(Z[8][135],1);	cplex.addEq(Z[9][149],1);	cplex.addEq(Z[10][75],1);	cplex.addEq(Z[11][33],1);	cplex.addEq(Z[12][35],1);	cplex.addEq(Z[13][97],1);	cplex.addEq(Z[14][99],1);	cplex.addEq(Z[15][14],1);	cplex.addEq(Z[16][36],1);	cplex.addEq(Z[17][113],1);	cplex.addEq(Z[18][115],1);	cplex.addEq(Z[19][149],1);	cplex.addEq(Z[20][60],1);	cplex.addEq(Z[21][47],1);	cplex.addEq(Z[22][49],1);	cplex.addEq(Z[23][81],1);	cplex.addEq(Z[24][80],1);	cplex.addEq(Z[25][25],1);	cplex.addEq(Z[26][47],1);	cplex.addEq(Z[27][113],1);	cplex.addEq(Z[28][149],1);	cplex.addEq(Z[29][112],1);	cplex.addEq(Z[30][46],1);	cplex.addEq(Z[31][48],1);
		cplex.addEq(Z[0][90],0);	cplex.addEq(Z[1][101],0);	cplex.addEq(Z[2][60],0);	cplex.addEq(Z[3][62],0);	cplex.addEq(Z[4][57],0);	cplex.addEq(Z[5][68],0);	cplex.addEq(Z[6][79],0);	cplex.addEq(Z[7][123],0);	cplex.addEq(Z[8][134],0);	cplex.addEq(Z[9][148],0);	cplex.addEq(Z[10][74],0);	cplex.addEq(Z[11][32],0);	cplex.addEq(Z[12][34],0);	cplex.addEq(Z[13][96],0);	cplex.addEq(Z[14][98],0);	cplex.addEq(Z[15][13],0);	cplex.addEq(Z[16][35],0);	cplex.addEq(Z[17][112],0);	cplex.addEq(Z[18][114],0);	cplex.addEq(Z[19][148],0);	cplex.addEq(Z[20][59],0);	cplex.addEq(Z[21][46],0);	cplex.addEq(Z[22][48],0);	cplex.addEq(Z[23][80],0);	cplex.addEq(Z[24][79],0);	cplex.addEq(Z[25][24],0);	cplex.addEq(Z[26][46],0);	cplex.addEq(Z[27][112],0);	cplex.addEq(Z[28][148],0);	cplex.addEq(Z[29][111],0);	cplex.addEq(Z[30][45],0);	cplex.addEq(Z[31][47],0);



		//			//optimal			
		//	cplex.addEq(Z[0][63],1);	cplex.addEq(Z[1][97],1);	cplex.addEq(Z[2][63],1);	cplex.addEq(Z[3][128],1);	cplex.addEq(Z[4][64],1);	cplex.addEq(Z[5][128],1);	cplex.addEq(Z[6][63],1);	cplex.addEq(Z[7][85],1);	cplex.addEq(Z[8][99],1);	cplex.addEq(Z[9][36],1);	cplex.addEq(Z[10][115],1);	cplex.addEq(Z[11][60],1);	cplex.addEq(Z[12][47],1);	cplex.addEq(Z[13][115],1);	cplex.addEq(Z[14][37],1);	cplex.addEq(Z[15][81],1);	cplex.addEq(Z[16][44],1);	cplex.addEq(Z[17][81],1);	cplex.addEq(Z[18][104],1);	cplex.addEq(Z[19][112],1);	cplex.addEq(Z[20][57],1);	cplex.addEq(Z[21][48],1);	cplex.addEq(Z[22][46],1);	cplex.addEq(Z[23][48],1);
		//	cplex.addEq(Z[0][62],0);	cplex.addEq(Z[1][96],0);	cplex.addEq(Z[2][62],0);	cplex.addEq(Z[3][127],0);	cplex.addEq(Z[4][63],0);	cplex.addEq(Z[5][127],0);	cplex.addEq(Z[6][62],0);	cplex.addEq(Z[7][84],0);	cplex.addEq(Z[8][98],0);	cplex.addEq(Z[9][35],0);	cplex.addEq(Z[10][114],0);	cplex.addEq(Z[11][59],0);	cplex.addEq(Z[12][46],0);	cplex.addEq(Z[13][114],0);	cplex.addEq(Z[14][36],0);	cplex.addEq(Z[15][80],0);	cplex.addEq(Z[16][43],0);	cplex.addEq(Z[17][80],0);	cplex.addEq(Z[18][103],0);	cplex.addEq(Z[19][111],0);	cplex.addEq(Z[20][56],0);	cplex.addEq(Z[21][47],0);	cplex.addEq(Z[22][45],0);	cplex.addEq(Z[23][47],0);
	}




	private double verifyWithCM(IloCplex cplex, Data data) throws IloException {
		IloNumExpr objtmp;
		int cnt;
		double out;		
		cplex.clearModel();
		data.resetOrderCost();

		objtmp = cplex.numExpr();
		//LOOPING OVER ALL MINES and adding constraints
		for(int i=0; i < data.nMines; i++){
			data.mine[i].relax = false;
			data.mine[i].addConstraints(data, cplex);
			objtmp = cplex.sum(objtmp, data.mine[i].MV.ObjVar);
		}

		for(int i=0; i < data.nMines; i++)
			for(int m=0; m < data.nTypes; m++){
				cnt=1;
				for(int t=1; t< Tmax; t++) {
					for(int j=0; j < Jobs.length; j++){
						if( i == Jobs[j].mIdx &&  m == Jobs[j].tIdx && 		
								(t== Jobs[j].cDate-Jobs[j].jTime+Jobs[j].pTime) ){
							cplex.addEq(data.mine[i].MV.AQty[m][t], cnt);
							cplex.addEq(data.mine[i].MV.AQty[m][t-1], cnt-1);
							cnt++;
						}							
					}					
				}
			}
		cplex.addMinimize(objtmp);
		cplex.exportModel("rail_cent.lp");
		cplex.solve();
		//	cplex.writeMIPStart("cent_best.mst");
		out = cplex.getObjValue();
		return out;
	}


	private boolean isNumExprEmpty(IloNumExpr expr, IloCplex cp) throws IloException {
		// TODO Auto-generated method stub		
		return expr.getClass().toString().equals(cp.numExpr().getClass().toString());
	}

	private int cTime(int t){
		return Math.min(Tmax-1, Math.max(0, t));
	}

	//============================================================
	public void writeOutputs(String filePrefix){

		MyUtils Utils = new MyUtils(filePrefix);
		int nJobs = Jobs.length;



		String outStr="\nJob";
		for (int j=0; j < nJobs; j++)
			outStr +=","+j;	
		outStr +="\nMine";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ Jobs[j].mIdx;		
		outStr +="\nTrain";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ Jobs[j].tIdx;		
		outStr +="\nReady";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ Jobs[j].rDate;	
		outStr +="\nReach(AQ)";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ (Jobs[j].cDate - Jobs[j].jTime+Jobs[j].pTime);	
		outStr +="\nDue";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ Jobs[j].dDate;
		outStr +="\nCompletion";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ Jobs[j].cDate;

		Utils.printf(outStr);		
	}



}
