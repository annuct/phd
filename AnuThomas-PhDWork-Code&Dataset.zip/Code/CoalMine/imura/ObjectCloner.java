package imura;

import java.io.*;
//import java.util.*;
//import java.awt.*;
public class ObjectCloner
{
 // so that nobody can accidentally create an ObjectCloner object
 private ObjectCloner(){}
 // returns a deep copy of an object
 static public Object deepCopy(Object oldObj) 
 {
    ObjectOutputStream oos = null;
    ObjectInputStream ois = null;
    try
    {
       ByteArrayOutputStream bos = 
             new ByteArrayOutputStream(); // A
       oos = new ObjectOutputStream(bos); // B
       // serialize and pass the object
       oos.writeObject(oldObj);   // C
       oos.flush();               // D
       ByteArrayInputStream bin = 
             new ByteArrayInputStream(bos.toByteArray()); // E
       ois = new ObjectInputStream(bin);                  // F
       // return the new object
       return ois.readObject(); // G
    }
    catch(Exception e)
    {
       e.printStackTrace();
       System.exit(0);
       return null;
    }
    finally
    {
       if(oos != null)
			try {
				oos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
       if(ois != null)
			try {
				ois.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
    }
 }
 
}