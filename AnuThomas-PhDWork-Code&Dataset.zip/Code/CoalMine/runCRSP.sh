export LD_LIBRARY_PATH="/mos/software/ILOG/cplex121/bin/x86-64_sles9.0_3.3"
java -cp /mos/software/ILOG/cplex121/lib/cplex.jar:./: imura.mainFile
