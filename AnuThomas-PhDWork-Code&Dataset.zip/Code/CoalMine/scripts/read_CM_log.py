#!/usr/bin/python
import string
import re
import sys


try:
  fname = sys.argv[1]
except:
  fname = "cplex_log.txt"

fd = open(fname)
print "reading ", fname

content = fd.readlines()
i=0
str123 = "LB\t\tUB \t\tGap \t \teTime(Secs)"
str123 += "\n------------------------------------------------------------------------------------"
method = 0
while(i < len(content)):
    line = content[i].replace( "\n", "" )  
    if re.search("^Root relaxation solution", line) != None:   
       firstEntry = True    
       while(i < len(content)):
          line = content[i].replace( "\n", "" )
          vals = line.split(":")
          if vals[0].endswith("applied") and firstEntry:
             time_str= re.split("\s+",content[i-2].replace( "\n", "" ))
             if (time_str[0] == "Elapsed"):
                time_str= re.split("\s+",content[i-3].replace( "\n", "" ))
         #    print time_str
             firstEntry = False
             len1 = len(time_str)
#             print time_str[len1-4]
             if(time_str[len1-2].endswith("%")):
                str123 += ("\n"+time_str[len1-4])
                str123 += ("\t"+ time_str[len1-3] +"\t"+ time_str[len1-2]+"\t")
             else:
                str123 += ("\n"+time_str[len1-3])
                str123 +=  "\t   \t \t"                   
          if re.search("^Total \(root", line) != None:
             time_str= re.split("\s+",line)
             str123 += "\t"+time_str[3]
             break
          i= i+1
    i = i+1
print str123
