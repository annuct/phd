
if [ $# -lt 1 ]; then
    echo "Run the script with choice: copy OR jcomp  OR run"  
    exit
fi



if [ $1 = copy ]  ; then

echo "copying"
rm -rf ./imura/.svn
cp -rf ../CoalMine/imura/*.java ./imura #
javac -cp /pkgs/ilog/cplex125/cplex/lib/cplex.jar  ./imura/*.java
#-----------------------------------------------------------------------

elif [ $1 = jcomp ] ; then
echo "java compilation"
javac -cp /pkgs/ilog/cplex125/cplex/lib/cplex.jar  ./imura/*.java
#-----------------------------------------------------------------------

elif [ $1 = run ] ; then
echo "running"
if [ $# -ge 2 ] ; then
cd $2
echo "Changing DIR to " $2
fi

export LD_LIBRARY_PATH="/pkgs/ilog/cplex125/cplex/bin/x86-64_sles10_4.1"
java -cp /pkgs/ilog/cplex125/cplex/lib/cplex.jar:./: imura.mainFile

fi
