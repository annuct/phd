#!/usr/bin/python
import string
import re
import sys


try:
  fname = sys.argv[1]
except:
  fname = "cplex_log.txt"

fd = open(fname)
print "reading ", fname

content = fd.readlines()
i=0
str123 = "Output String\nReTime\tRootNode \tFirstSol \tGap % \tLastUB \t \tLastLB \t\teTime(Secs)"
str123 += "\n------------------------------------------------------------------------------------"
method = 0
while(i < len(content)):
    line = content[i].replace( "\n", "" )  
    if re.search("^Root relaxation solution", line) != None:
       Sub = re.split("\s+",line);
       rootVal = Sub[5]
       i = i+5
       line = content[i].replace( "\n", "" )
       Sub = re.split("\s+",line)
       #print Sub
       if(len(Sub)>3):
          if Sub[3].startswith("infeas"):
              i += 1
              continue
          str123 += "\n%d\t%s" %(method%3,rootVal) 
          str123 += "\t"+ Sub[3]
          method += 1 
       frstSol = True
       finalSol = False
       while(i < len(content)):
          line = content[i].replace( "\n", "" )
          Sub = re.split("\s+", line)          
          if (Sub[0] == "*") & frstSol:
             if(Sub[3]== "integral"):
               str123 += "\t"+ Sub[5]+"\t"+Sub[len(Sub)-1]
             else:
               str123 += "\t"+ Sub[3]+"\t"+Sub[len(Sub)-1]
             frstSol = False
          vals = line.split(":")
          if vals[0].endswith("applied") and not finalSol:
          #if re.search("^GUB cover cuts applied:", line) != None:
             time_str= re.split("\s+",content[i-2].replace( "\n", "" ))
             if (time_str[0] == "Elapsed"):
                time_str= re.split("\s+",content[i-3].replace( "\n", "" ))
             if(len(time_str)>= 4):
                flb = (time_str[len(time_str)-3])
                fub = (time_str[len(time_str)-4])
                str123 += "\t" +fub+"\t"+flb
             finalSol = True                       
          if re.search("^Total \(root", line) != None:
             time_str= re.split("\s+",line)
             str123 += "\t"+time_str[3]
             break
          i= i+1
    i = i+1
print str123
