#!/usr/bin/python
import string
import re
import sys


try:
  fname = sys.argv[1]
except:
  fname = "summary.txt"

fd = open(fname)
print "reading ", fname

content = fd.readlines()
i=0
str123 = ""
set=1
while(i < len(content)):
    line = content[i].replace( "\n", "" )
    if (re.search("^Itr-0:", line) != None) & (i > 0):
       print set, content[i-1].replace("\n","");
       set=set+1
    i =  i+1

