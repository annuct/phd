#!/usr/bin/python
import string
import re
import sys


try:
  fname = sys.argv[1]
except:
  fname = "summary.txt"

fd = open(fname)
print "reading ", fname

content = fd.readlines()
i=0
str123 = ""
set=0
while(i < len(content)):
    line = content[i].replace( "\n", "" )
    if ((re.search("^Itr,", line) != None) & (i > 0)): 
       if (re.search("-", line) != None): 	
           print set,",", content[i-1].replace("\n","");
       else:  
	       time_str1 = re.split(",",content[i-1].replace("\n",""));
	       time_str2 = re.split(",",content[i-2].replace("\n",""));
	       print set,",", time_str1[0], time_str2[1], time_str2[2], time_str2[3],time_str1[4];
	       #print set,",", content[i-2].replace("\n","");
       set=set+1
    i =  i+1
print set,",", content[len(content)-1].replace("\n","");
