
data = csvread('CM_time_gap.csv');

dv = sort(data(1,:,:));

idx = find(data(1,:,:)==1);

row1 = time
row2 = gap

linear interpolation

t1 = 1800, 2700, 3600
