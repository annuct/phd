#!/usr/bin/python
import string
import re
import sys


try:
  fname = sys.argv[1]
except:
  fname = "cplex_log.txt"

fd = open(fname)
print "reading ", fname

content = fd.readlines()
i=0
str123 = "LB\t\tUB \t\tGap \t \teTime(Secs)"
str123 += "\n------------------------------------------------------------------------------------"
method = 0

while(i < len(content)):
    line = content[i].replace( "\n", "" )  
    if re.search("^Input data file : data/", line) != None:   
       vals = content[i].replace( "\n", "" ).split("_")
       str123 += ("\n"+vals[1].replace(".dat",""))
       colArray  = 0
       i = i+1	   
       while(i < len(content)):
          line = content[i].replace( "\n", "" )
          vals = line.split(" ")
          if vals[0].startswith("Adding") :
              colArray = colArray +1;  
          if vals[0].startswith("Removing"):
              colArray = colArray -1;
          if vals[0].startswith("Iteration"):
              str123 += ("\t%d" %(colArray))
          if vals[0].startswith("Best") or vals[0].startswith("Error"):
   
          
              break; 

          i= i+1
    i = i+1
print str123
