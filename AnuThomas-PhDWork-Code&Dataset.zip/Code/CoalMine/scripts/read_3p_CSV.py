#!/usr/bin/python
import string
import re
import sys
import numpy as np
import pylab as pl
import scipy as sp
import statsmodels.api as sm
import matplotlib.pyplot as plt

filename="3p"
    
def find_LBR_UBR(data1, data2):
	rowCount=len(data1); #LB
	BR=[[0 for u1 in xrange(rowCount)] for j in xrange(4)]
	#print len(data1), len(data1[0]), len(BR), len(BR[0])
	for row in range(rowCount):		
		for i in range(4):
			if(i==0):
				denom= max(data1[row][i],data2[row][i])
			else:
				denom = min(data1[row][i],data2[row][i])
			if (denom !=0):
				BR[i][row] = (data1[row][i]-data2[row][i])/denom
			else:
				BR[i][row] = 0.0	
	return BR   


# ---------------------------------------
def find_CI(data, idx1In, idx2In, p, nosets):
# Source: https://courses.cit.cornell.edu/rdr98/Python/interactive_one_sample_t_test.py
  batchsize = len(data)/nosets
  yAxis =[10000, -10000]
  FieldNames = ['LBR', 'UBR', 'RelGap', 'Time','Itrs']
  output_name =""

  for uv in range(len(idx2In)):
    idx1 = idx1In[uv]
    idx2 = idx2In[uv]
    for kk in range(nosets):
       newdata = data[kk*batchsize: kk*batchsize+batchsize-1]
       BR=find_LBR_UBR(newdata, idx1, idx2)  
       ci_data =   BR
       offset = 0+0.1*pow(-1,uv+1)*(len(idx2In)-1)
       if (nosets==1): 
          pos = kk+p+5 +offset  
       else:
          pos = kk+5 +offset  
       d_mean = sp.average(ci_data)
     #  print d_mean
      # for kk in range(8): 
       #   print sp.average(ci_data[0+30*kk:30*(kk+1)])

       #pause  
       d_std = sp.std(ci_data)
       d_ste = d_std / sp.sqrt(len(ci_data)); # ste stands for Standard Error of the Mean
       [t_value,p_value] = sp.stats.ttest_1samp(ci_data,0)
       conf_inter = d_mean + sp.stats.t.ppf(0.975,len(ci_data)-1) * d_ste * sp.array([-1,1])
       pl.plot(pos,d_mean,'bo',markersize=10)
       if(len(idx2In)>1 and idx2 == idx2In[1]):
         pl.plot([pos, pos],conf_inter,'g-',linewidth=3)
       else:
         pl.plot([pos, pos],conf_inter,'r-',linewidth=3)
       print 'Mean=' + str(round(d_mean,4)) + ', STE=STD/sqrt(n)=' + str(round(d_ste,2))  +           ', t=Mean/STE=' + str(round(t_value,2)) + ', p= ' + "%1.2g" % p_value +', CI = ['+ str(round(conf_inter[0],4)) + ','+str(round(conf_inter[1],4)) + ']'
       yAxis = [ min(yAxis[0], min(conf_inter)), max(yAxis[1], max(conf_inter))]
    # print yAxis
    # Set the axis back to its original value, in case Python has changed it during plotting
    output_name =output_name+'_(M'+str(idx1)+'_M'+str(idx2)+")"
    pl.plot([4, 5+axis_x_range], [0, 0], 'c--', linewidth=0.5)
   

  # END of UV

  pl.xlabel('Number of producers')
  pl.ylabel('Confidence interval')    
  output_name = 'DM-CI-'+FieldNames+output_name+'.eps'
  print output_name
  if(batchsize==30):
    pl.axis([4, 5+axis_x_range, yAxis[0]*1.05, yAxis[1]*1.05])
    pl.savefig(output_name)   
    pl.clf()
  elif(p==4): 
    pl.show()



# ---------------------------------------



def plot_LBR_UBR(data1, data2):
  BR=find_LBR_UBR(data, idx1, idx2)  
  num_bins =  10
  for p in range(2):  
  #  p=p+1
    ecdf = sm.distributions.ECDF(BR)
    x = np.linspace(min(BR), max(BR))
    plt.plot(x, ecdf(x),linewidth=2)
    plt.ylabel("Frequency")
    plt.plot([0, 0], [0,1], 'c--')
#  plt.hist(LBR, bins=50, color='blue')

    if(p==0):
      plt.xlabel("LBR (M"+str(idx1)+", M"+str(idx2)+")" )
      plt.savefig("DM-LBR_M"+str(idx1)+"_M"+str(idx2)+".eps")
    else:
      plt.xlabel("UBR (M"+str(idx1)+", M"+str(idx2)+")" )
      plt.savefig("DM-UBR_M"+str(idx1)+"_M"+str(idx2)+".eps")
 #   plt.show()  
    plt.clf()  



def plot_All_ratio(data1, data2):

	rowCount=len(data1); #LB
	gBounds=[100, -100]
	BR=find_LBR_UBR(data1, data2)  
	lbl = ['LBR(IM,LR)', 'UBR(IM,LR)']
	num_bins =  10
	for p in range(2):
		ecdf = sm.distributions.ECDF(BR[p])
		gBounds = [min(BR[p]), max(BR[p])]
		x = np.linspace(gBounds[0], gBounds[1])
		plt.plot(x, ecdf(x),linewidth=2, label=lbl[p])


	#plt.text(.2,.6,'LBR(IM,DM)<0 means DM has higher lowerbound'
	# UBR(IM,DM)>0 means that DM has lower upper bound')
	plt.ylabel("Frequency")
	plt.xlabel('Relative Ratio')
	plt.plot([0, 0], [0,1], 'c--')
	plt.legend( loc='lower right' )
	plt.xlim(-0.3,0.6)
	plt.savefig(filename+'_LBR_UBR.eps')
	plt.show()  
        
def plot_gap_hist(D1,D2):
	
	newD1 = [ D1[k][2] for k in range(len(D1))]
	newD2 = [ D2[k][2] for k in range(len(D2))]
	
	MAX=max(max(newD1), max(newD2))
	bins=range(int(MAX+1))
	plt.hist(newD1,label='IM', histtype='step', normed=1,cumulative=True, bins=bins,linewidth=2)
	plt.hist(newD2,label='LR', histtype='step', normed=1, cumulative=True, bins=bins, linewidth=2)
	plt.xlim(-1,50)
	plt.ylim(0,1)
	plt.ylabel("Frequency")
	plt.xlabel('Relative gap')	
	plt.legend( loc='lower right' )
	plt.savefig(filename+'_relative_gap.eps')
	plt.show()  
        
	


def main(fname, case=2):
	global filename
	fd = open(fname)
	print "reading ", fname
	filename = fname.strip('.csv')
	content = fd.readlines()
	noDataSets=len(content)-2
	IMdata =[[0 for k in xrange(4)] for i1 in xrange(noDataSets)]
	DMdata =[[0 for k in xrange(5)] for i1 in xrange(noDataSets)]

	indexArray=[[1,2,3,4,-1],[7,8,9,10,6]]

	i=2
	while(i < len(content)):
		line = content[i].replace( "\n", "" ) 
		Sub = re.split(",",line)
		 # print Sub
		if Sub[len(Sub)-2]=='': 
			i=i+1
			continue
    # else:
    # print Sub[0] 
    # for IM (1:4), DM(7:10,6)
                print Sub
		for k in range(1,5): # LB, UB, gap, time
			IMdata[i-2][k-1] = ( float(Sub[k]) if (Sub[k] !="") else 100)

		for k in range(7,11):
			DMdata[i-2][k-7] = float(Sub[k])      
		DMdata[i-2][4] = float(Sub[6])      
		i=i+1
# WND WHILE
        plot_gap_hist(IMdata,DMdata)
#  case=1;
	if(case == 1):
		find_CI(IMdata,DMdata)
	elif(case == 2):
		plot_LBR_UBR(IMdata,DMdata)
	elif(case == 3):
		plot_All_ratio(IMdata,DMdata)
#END CASE



if __name__ == '__main__':  
    handle_of_conf_int_plot = []
    handle_of_mean_plot = []
### Set up an initial space to click inside
    axis_x_range = 8
     
    if len(sys.argv)!=3: # including filename there will be three arguments
      case = 2;
      fname = "131030_3p_data.csv"
    else:
      fname = sys.argv[1]
      case = float(sys.argv[2]);
   # print fname, case, sys.argv
    main(fname, case)
