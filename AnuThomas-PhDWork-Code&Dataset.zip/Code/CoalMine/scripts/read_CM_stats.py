#!/usr/bin/python
import string
import re
import sys


try:
  fname = sys.argv[1]
except:
  fname = "cplex_log.txt"

fd = open(fname)
print "reading ", fname

content = fd.readlines()
i=0
str123 ="SrNo\tTime\t Gap"
# str123 = "Output String\nReTime\tRootNode \tFirstSol \tGap % \tLastUB \t \tLastLB \t\teTime(Secs)"
# str123 += "\n------------------------------------------------------------------------------------"
method = 0
time=0
gap=0
while(i < len(content)):
    line = content[i].replace( "\n", "" )  
    if re.search("^Root relaxation solution", line) != None:
       method += 1
       gap =100
       while(i < len(content)):       
          line = content[i].replace("\n","");  
          time_str = re.split("\s+",line)
          if (time_str[0] == "Elapsed"):
             prevline =  content[i-1].replace("\n","")
             time = float(time_str[4])
             if(prevline.endswith("%")): 
                 time_str= re.split("\s+",prevline)
                 gap= float(time_str[len(time_str)-1].replace("%",""))
                 str123 += ("\n%d,\t%.2f,\t%.2f" %(method, time, gap))
          vals = line.split(":")
          firstFlag = True
          if vals[0].endswith("applied") and firstFlag:
             firstFlag = False
             time_str= re.split("\s+",content[i-2].replace( "\n", "" ))
             if (time_str[0] == "Elapsed"):
                time_str= re.split("\s+",content[i-3].replace( "\n", "" ))
             if(time_str[len(time_str)-1].endswith("%")):
                gap= float(time_str[len(time_str)-1].replace("%",""))
          if re.search("^Total \(root", line) != None:
             time_str= re.split("\s+",line)
             time = float(time_str[3]) 
             str123 += ("\n%d,\t%.2f,\t%.2f" %(method, time, gap))
             break
          i= i+1
    i = i+1
print str123
