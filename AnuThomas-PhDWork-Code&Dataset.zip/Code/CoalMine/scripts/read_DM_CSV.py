#!/usr/bin/python
import string
import re
import sys
import numpy as np
import pylab as pl
import scipy as sp
import statsmodels.api as sm
import matplotlib.pyplot as plt

    
def find_LBR_UBR(data, idx1, idx2):
    rowCount=len(data); #LB
    BR=[[0 for u1 in xrange(rowCount)] for j in xrange(len(data[0][0]))]
    for row in range(rowCount):
        for ms in range(len(data[0][0])):
          if(ms ==0):
           BR[ms][row] = (data[row][idx1][ms]-data[row][idx2][ms])/max(data[row][idx1][ms],data[row][idx2][ms]);
          elif (ms >1): # rel gap, itrs, time
             minVal=min(data[row][idx1][ms],data[row][idx2][ms]);
             if(minVal==0):
                print "please check row ",row;
                BR[ms][row] = 0;
             else:
                BR[ms][row] = (data[row][idx1][ms]-data[row][idx2][ms])/minVal;
          else: # ms==1 Upper bound
             if(data[row][idx1][1]==0):
                BR[1][row]= 1
             elif(data[row][idx2][1]==0):
                BR[1][row]= -1
             else:
               BR[1][row] = (data[row][idx1][1]-data[row][idx2][1])/min(data[row][idx1][1],data[row][idx2][1]);
    # print LBR[row], UBR[row]
    return BR   


# ---------------------------------------
def find_CI(data, idx1In, idx2In, p, nosets):
# Source: https://courses.cit.cornell.edu/rdr98/Python/interactive_one_sample_t_test.py
  batchsize = len(data)/nosets
  yAxis =[10000, -10000]
  FieldNames = ['LBR', 'UBR', 'RelGap', 'Time','Itrs']
  output_name =""

  for uv in range(len(idx2In)):
    idx1 = idx1In[uv]
    idx2 = idx2In[uv]
    for kk in range(nosets):
       newdata = data[kk*batchsize: kk*batchsize+batchsize-1]
       BR=find_LBR_UBR(newdata, idx1, idx2)  
       ci_data =   BR[p]
       offset = 0+0.1*pow(-1,uv+1)*(len(idx2In)-1)
       if (nosets==1): 
          pos = kk+p+5 +offset  
       else:
          pos = kk+5 +offset  
       d_mean = sp.average(ci_data)
     #  print d_mean
      # for kk in range(8): 
       #   print sp.average(ci_data[0+30*kk:30*(kk+1)])

       #pause  
       d_std = sp.std(ci_data)
       d_ste = d_std / sp.sqrt(len(ci_data)); # ste stands for Standard Error of the Mean
       [t_value,p_value] = sp.stats.ttest_1samp(ci_data,0)
       conf_inter = d_mean + sp.stats.t.ppf(0.975,len(ci_data)-1) * d_ste * sp.array([-1,1])
       pl.plot(pos,d_mean,'bo',markersize=10)
       if(len(idx2In)>1 and idx2 == idx2In[1]):
         pl.plot([pos, pos],conf_inter,'g-',linewidth=3)
       else:
         pl.plot([pos, pos],conf_inter,'r-',linewidth=3)
       print 'Mean=' + str(round(d_mean,4)) + ', STE=STD/sqrt(n)=' + str(round(d_ste,2))  +           ', t=Mean/STE=' + str(round(t_value,2)) + ', p= ' + "%1.2g" % p_value +', CI = ['+ str(round(conf_inter[0],4)) + ','+str(round(conf_inter[1],4)) + ']'
       yAxis = [ min(yAxis[0], min(conf_inter)), max(yAxis[1], max(conf_inter))]
    # print yAxis
    # Set the axis back to its original value, in case Python has changed it during plotting
    output_name =output_name+'_(M'+str(idx1)+'_M'+str(idx2)+")"
    pl.plot([4, 5+axis_x_range], [0, 0], 'c--', linewidth=0.5)
   

  # END of UV

  pl.xlabel('Number of producers')
  pl.ylabel('Confidence interval')    
  output_name = 'DM-CI-'+FieldNames[p]+output_name+'.eps'
  print output_name
  if(batchsize==30):
    pl.axis([4, 5+axis_x_range, yAxis[0]*1.05, yAxis[1]*1.05])
    pl.savefig(output_name)   
    pl.clf()
  elif(p==4): 
    pl.show()



# ---------------------------------------



def plot_LBR_UBR(data, idx1, idx2):
  BR=find_LBR_UBR(data, idx1, idx2)  
  num_bins =  10
  for p in range(2):  
  #  p=p+1
    ecdf = sm.distributions.ECDF(BR[p])
    x = np.linspace(min(BR[p]), max(BR[p]))
    plt.plot(x, ecdf(x),linewidth=2)
    plt.ylabel("Frequency")
    plt.plot([0, 0], [0,1], 'c--')
#  plt.hist(LBR, bins=50, color='blue')

    if(p==0):
      plt.xlabel("LBR (M"+str(idx1)+", M"+str(idx2)+")" )
      plt.savefig("DM-LBR_M"+str(idx1)+"_M"+str(idx2)+".eps")
    else:
      plt.xlabel("UBR (M"+str(idx1)+", M"+str(idx2)+")" )
      plt.savefig("DM-UBR_M"+str(idx1)+"_M"+str(idx2)+".eps")
 #   plt.show()  
    plt.clf()  



def plot_All_ratio(data, idx2, p):

  rowCount=len(data); #LB
  gBounds=[100, -100]
  for idx1 in range(5):
    if(idx2>=idx1):
       continue;
    BR=find_LBR_UBR(data, idx1, idx2)  
  
    num_bins =  10
    ecdf = sm.distributions.ECDF(BR[p])
    gBounds = [min(gBounds[0],min(BR[p])), max(gBounds[1],max(BR[p]))]
    x = np.linspace(gBounds[0], gBounds[1])
    plt.plot(x, ecdf(x),linewidth=2, label="M"+str(idx1))



  plt.ylabel("Frequency")
  plt.plot([0, 0], [0,1], 'c--')
  plt.legend( loc='upper left' )
  if(p==0):
     plt.xlabel("LBR, base=M"+str(idx2))
     plt.savefig("DM-LBR_All_base=M"+str(idx2)+".eps")
  else:
     plt.xlabel("UBR , base=M"+str(idx2))
     plt.savefig("DM-UBR_All_base=M"+str(idx2)+".eps")
  plt.show()  
        


def main(fname, case):

  fd = open(fname)
  print "reading ", fname

  content = fd.readlines()
  i=2
  m=5
  n=5
  noDataSets=240
  data=[[[0 for k in xrange(m)] for j in xrange(n)] for i1 in xrange(noDataSets)]

  indexArray=[[1,2,3,4,-1],[7,8,9,10,6]]

  cnt=0
  while(i < len(content)):
    line = content[i].replace( "\n", "" ) 
    Sub = re.split(",",line)
#    print Sub
    if Sub[len(Sub)-2]=='': 
       i=i+1
       continue
    # else:
    # print Sub[0] 
    # for CM (1:4), M1(7:10,6), M2(14:17,13), M3(21:24,20), M4(28:31,27)

    for k in range(5):
        for j in range(5):
            if(k==0 and j==4): 
                continue
            if(k>1):
                idx=indexArray[1][j]+(k-1)*7;
            else:
                idx=indexArray[k][j]; 

            if(Sub[idx]!=''): # if there is a value available
                data[cnt][k][j] = float(Sub[idx])      

    cnt = cnt+1
    i=i+1
# WND WHILE

#  case=1;
  if(case == 1):
       find_CI(data,[2],[1], 0, 8)
       find_CI(data,[2],[1], 1, 8)
  elif(case == 2):
       plot_LBR_UBR(data, 4,2)
       plot_LBR_UBR(data, 4,1)
  elif(case == 3):
       # base = M0 & M1, last index says whether to use LBR or UBR
       plot_All_ratio(data, 0, 1)
       plot_All_ratio(data, 0, 0)
       plot_All_ratio(data, 1, 1)
       plot_All_ratio(data, 1, 0)
  elif(case == 4):
   # Making all combinations
       for i1 in range(5):
         for i2 in range(5):
           if (i2 >= i1):
              continue;
           plot_LBR_UBR(data, i1,i2)
  elif(case == 5):
   # Making combined CI plots 3-1, 3-2, 4-1 and 4-2
      for p in range(5):
       find_CI(data,[2,4], [3,1], p, 8)
       find_CI(data,[2,3], [4,1], p, 8)
  elif(case == 6):
# Making M2-M1 CI plots
      for p in range(5):
       find_CI(data,[2],[1], p, 8)
  elif(case == 7):
   # Making combined CI plots 3-1, 3-2, 4-1 and 4-2
      for p in range(5):
       find_CI(data,[2,4], [3,1], p, 1)
#       find_CI(data,[2,3], [4,1], p, 8)

#END CASE

  print cnt



if __name__ == '__main__':  
    handle_of_conf_int_plot = []
    handle_of_mean_plot = []
### Set up an initial space to click inside
    axis_x_range = 8
     
    if len(sys.argv)!=3: # including filename there will be three arguments
      case = 5;
      fname = "130628_Decentralised2P.csv"
    else:
      fname = sys.argv[1]
      case = float(sys.argv[2]);
   # print fname, case, sys.argv
    main(fname, case)
