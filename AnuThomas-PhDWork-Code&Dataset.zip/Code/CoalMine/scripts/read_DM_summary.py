#!/usr/bin/python
import string
import re
import sys


try:
  fname = sys.argv[1]
except:
  fname = "cplex_log.txt"

fd = open(fname)
print "reading ", fname

content = fd.readlines()
i=0
#str123 = "Output String\nPNo\tZ_2 RN \t Z_4 RN \tZ_2 AC \t Z_4 AC \tZ_2 eT \t Z_4 eT"
#str123 += "\n------------------------------------------------------------------------------------"
str123 =""
itr = 0
noMines=7 
MaxSize = max(100, int(len(content)/noMines))
TotalSysCost = [None]*MaxSize
TWT = [None]*MaxSize
improvedMines = [None]*MaxSize
prevCost = [None]*noMines
currCost = [None]*noMines
while(i < len(content)):
    line1 = content[i].replace( "\n", "" )  
    if(line1.startswith("Mine")):
        improvedMines[itr] =0;
        for k in range(noMines):
                line = re.split(",", content[i+1+k].replace( "\n", "" ) )	      
                if(itr > 0):	      
                        prevCost[k] = currCost[k]	       
                currCost[k] = float(line[2]);
                if( itr>0  and (currCost[k] <= prevCost[k])):
                    improvedMines[itr] = improvedMines[itr]+1
                   # print k, currCost[k], prevCost[k]
        i = i+  noMines +2	
        line = re.split(",", content[i].replace( "\n", "" ) )
        TotalSysCost[itr] = float(line[2])	
        line1= re.split("\s+", content[i+1].replace( "\n", "" ) )
        TWT[itr] =  float(line1[2])	
        itr = itr +1
    i = i+1	


for k in range(itr):
	if (k >0):
	    str1 =  (TotalSysCost[k] <= TotalSysCost[k-1])
	    str2 =  (TWT[k] <= TWT[k-1])
	    print "%d\t%d\t%d\t%d\t%s\t%s" %(k, TotalSysCost[k], TWT[k], improvedMines[k], str1, str2) 
	else : 
	    print "%d\t%d\t%d" %(k, TotalSysCost[k], TWT[k]) 
