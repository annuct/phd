#!/usr/bin/python
import string
import re
import sys


try:
  fname = sys.argv[1]
except:
  fname = "summary.txt"

fd = open(fname)
print "reading ", fname

content = fd.readlines()
i=0
str123 = ""
set=0
poa = -1; 
while(i < len(content)):
    line = content[i].replace( "\n", "" )
    line1 = line.split(",");
    try:
       if(len(line1) > 3 and (poa < 0) and (i >0) and float(line1[2]) < 100):
#       print line1
          poa = line1[2]
    except ValueError:
         poa = -1
    if ((re.search("^Itr,", line) != None) & (i > 0)):                
       print set,",", content[i-1].replace("\n",""), poa;
       poa = -1;
       set=set+1
    i =  i+1
print set,",", content[len(content)-1].replace("\n",""), poa;
