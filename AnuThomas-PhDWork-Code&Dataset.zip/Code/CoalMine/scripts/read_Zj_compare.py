#!/usr/bin/python
import string
import re
import sys


try:
  fname = sys.argv[1]
except:
  fname = "cplex_log.txt"

fd = open(fname)
print "reading ", fname

content = fd.readlines()
i=1
str123 = "Output String\nPNo\tZ_2 RN \t Z_4 RN \tZ_2 AC \t Z_4 AC \tZ_2 eT \t Z_4 eT"
str123 += "\n------------------------------------------------------------------------------------"
method = 0
while(i+2 < len(content)):
    line1 = content[i].replace( "\n", "" )  
    line2 = content[i+1].replace( "\n", "" )  
    line3 = content[i+2].replace( "\n", "" )  
    Sub1 = re.split(",",line1);
    Sub2 = re.split(",",line2);
    Sub3 = re.split(",",line3);
    #print Sub3
    if(len(Sub2) < 9):
     print Sub2, len(Sub2)
    str123  +="\n%s \t%0.2f \t%0.2f" %(Sub1[0], float(Sub1[3])/float(Sub2[3])*100, float(Sub3[3])/float(Sub2[3])*100)
    str123  += "\t %0.2f \t %0.2f" %(float(Sub1[4])/float(Sub2[4])*100, float(Sub3[4])/float(Sub2[4])*100)
    str123  += "\t %0.2f \t %0.2f" %(float(Sub1[8])/float(Sub2[8])*100, float(Sub3[8])/float(Sub2[8])*100)
    i=i+3
print str123
