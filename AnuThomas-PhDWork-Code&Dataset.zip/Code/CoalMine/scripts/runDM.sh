
if [ $# -lt 1 ]; then
    echo "Run the script with choice: copy OR jcomp  OR run"  
    exit
fi



if [ $1 = copy ]  ; then

echo "copying"
rm -rf ./imura/.svn
cp -rf ../DM/src/imura/*.java ./imura #
javac -cp /tools/ILOG/cplex121/lib/cplex.jar  ./imura/*.java
#-----------------------------------------------------------------------

elif [ $1 = jcomp ] ; then
echo "java compilation"
javac -cp /tools/ILOG/cplex121/lib/cplex.jar  ./imura/*.java
#-----------------------------------------------------------------------

elif [ $1 = run ] ; then
echo "running"
if [ $# -ge 2 ] ; then
cd $2
echo "Changing DIR to " $2
fi

export LD_LIBRARY_PATH="/tools/ILOG/cplex121/bin/x86-64_sles9.0_3.3"
java -cp /tools/ILOG/cplex121/lib/cplex.jar:./: imura.mainFile

fi
