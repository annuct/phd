#!/usr/bin/python
import string
import re
import sys


try:
  fname = sys.argv[1]
except:
  fname = "cplex_log.txt"

t_fname = fname.replace("cplex_log.txt", "time_record.txt")
fd = open(fname)
t_fd = open(t_fname)
print "reading ", fname

content = fd.readlines()
t_content = t_fd.readlines()
i=0
j=0
str123 = "Output String\nModel\tReTime\tRootNode \tAfterCut \t LB \t  \t UB \t LastGap \teTime"
str123 += "\n------------------------------------------------------------------------------------"
method = 0
while(i < len(content)):
    line = content[i].replace( "\n", "" )  
    if re.search("^Root relaxation solution", line) != None:
       Sub = re.split("\s+",line);
       rootVal = Sub[5]
       i = i+5
       line = content[i].replace( "\n", "" )
       Sub = re.split("\s+",line)
       #print Sub
       if(len(Sub)>3):
          if Sub[3].startswith("infeas"):
              i += 1
              continue
          str123 += "\nZ_%d\t%s" %(method%3+2,rootVal) 
          str123 += "\t"+ Sub[3]
          method += 1
       i = i+1           
       frstSol = True
       finalSol = False
       afterCut = True
       while(i < len(content)):
          line = content[i].replace( "\n", "" )
          if (afterCut and (re.search(":", line) == None) and re.search("^Heuristic", line) == None):
             Sub = re.split("\s+", line)          
             if (re.search("%", line) != None):
                 str123 += "\t%0.3f" %(float(Sub[len(Sub)-3]))
             else:          
                 str123 += "\t%0.3f" %(float(Sub[len(Sub)-2]))
             afterCut = False
          # Sub = re.split("\s+", line)    
          # if (Sub[0] == "*") & frstSol:
          #    if(Sub[3]== "integral"):
            #    str123 += "\t%0.0f\t%s" %(float(Sub[5]), Sub[len(Sub)-1])
             # else:
              #  str123 += "\t%0.0f\t%s" %(float(Sub[3]), Sub[len(Sub)-1])
             # frstSol = False
         #  vals = line.split(":")
        #  if vals[0].endswith("applied") and not finalSol:
          #if re.search("^GUB cover cuts applied:", line) != None:
        #     time_str= re.split("\s+",content[i-2].replace( "\n", "" ))
         #    if (time_str[0] == "Elapsed"):
          #      time_str= re.split("\s+",content[i-3].replace( "\n", "" ))
           #  flb = float(time_str[len(time_str)-3])
            # fub = float(time_str[len(time_str)-4])
             #str123 += "\t%0.0f\t%0.3f\t%0.3f" %(fub,flb,(fub-flb)*100/flb)
             # finalSol = True                       
          if re.search("^Total \(root", line) != None:
             time_str= re.split("\s+",line)
             t_line = re.split("secs.", t_content[j].replace("\n",""))
             sp_str = re.split("\s+", t_line[1])
             str123 += "\t%0.2f\t%0.0f\t%0.2f" %(float(sp_str[2]), float(sp_str[4]), float(sp_str[6]))
             j = j+1
             str123 += " \t"+time_str[3]
             break
          i= i+1
    i = i+1
print str123
