function read_DM_records

filename  = '0603_doubleObj.csv';

textdata = textread(filename);

data = csvread(filename);


end