package imura;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;

import ilog.concert.IloException;
import ilog.cplex.IloCplex;
import imura.Data.Configuration;

// This is the coMmon file to run all programs under this work


public class mainFile {
	static String DataPrefix;
	static String baseDir;
	static int modelChoice = -1;

	public static void main( String[] args ) {

		if(args.length >0)
			modelChoice = Integer.valueOf(args[0]);

		int[] mineNo = {7, 10, 5, 6, 8, 9, 12, 15};
		String[] dataLetter = {"A", "B", "C", "D","E","F", "G", "H","Z"};
		//	for(int u : (new int[]{0})){
		for(int u =0 ; u< 8; u++){
			long start = System.currentTimeMillis();
			System.out.println("starting ............");

			DataPrefix = dataLetter[u];
			String filename = "data/"+mineNo[u]+"mines/Data_"+dataLetter[u];
			try{
				runModel(filename, u);
			}catch(Exception e){
				e.printStackTrace();
			}
			System.out.println("Total execution time "+ (System.currentTimeMillis() - start)/1000F +" secs");
			System.out.println("\nfinished............"+ DataPrefix);
		}

		System.out.println("\nfinished............");

	}


	//
	private static void runModel(String dataseries, int u){

		try {

			IloCplex cplex = new IloCplex();
			// int[][] Colln ={{4, 7,8},{2,5,15}, {12,13,14},{4,7,13},{15},{1,2,3,4,5}};

			int[] Colln ={3}; //data set
			//
			//			for(int set : Colln){
			for(int set = 1; set < 11; set++){
				//		if(set==7) continue;

				String filename = dataseries +set+".dat";

				long start = System.currentTimeMillis();
				Data data =  readData(filename);
				for(int i=0; i < data.nMines; i++)
					data.mine[i].initTrAvailAndDelay(data);//init				

				if(modelChoice == -1)
					modelChoice = data.conf.Model_Choice;

				switch(modelChoice){
				case 1: 	
					// Centralised model
					data.conf.filePrefix ="CM_"+DataPrefix+"_";
					CentModel CM = new CentModel(data);
					CM.solve(cplex, data.conf.LR_GAP_LIMIT, data.conf.LR_TIME_LIMIT);
					//	CM.solve(0,0,"cent_sol_rail_p4.mst");
					break;




				case 401: // Centralised + Lagrangian method
					data.conf.filePrefix ="LR_"+DataPrefix+"_";
					try{
						DecentModel DM1 = new DecentModel(data);
						DM1.solveWithLag(cplex);
					}catch(Exception e){
						e.printStackTrace();
						System.out.println("Error in data set - " + set);
					}
					break;

				case 5: // Centralised + column generation method
					data.conf.filePrefix ="CG_"+DataPrefix+"_";
					try{
						ColGen CG = new ColGen(data);
						CG.solveWithColGen(cplex);
					}catch(Exception e){
						e.printStackTrace();
						System.out.println("Error in data set - " + set);
					}
					break;



				default: 
					System.out.println("Invalid choice");
				}	
				System.out.println("Set "+set+ " eTime "+ (System.currentTimeMillis() - start)/1000F +" secs");
			} // data set; Colln

			cplex.end();

		} catch (IloException e) {
			// TODO Auto-generated catch block		
			e.printStackTrace();
		}
	}

	private static void setConfigParameters(Data data){

		Configuration conf = data.conf;
		conf.itrLimit = 500;
		conf.LR_UB_Choice = 0;
		conf.Model_Choice = 401; 
		conf.Mine_CPX_Gap = 0.0;
		conf.CM_CPX_gap = 0.02;

		conf.Mine_CPX_TimeLimit = 0;
		conf.CM_CPX_TimeLImt = 0;

		// String filename = "data/10mines/Data_B"+fNo+".dat";
	}


	//================================================================================================================================

	private static Data readData(String filename) {

		System.out.println("Input data file : "+ filename);
		Data data =null;

		try {
			data = new Data(filename);
			setConfigParameters(data);
			data.conf.datafile = filename;
		} catch(FileNotFoundException ex)  	{
			System.out.println("File ("+filename+") not found.");
		}
		catch (Exception e) {
			System.out.println("ERROR in Input file reading");
			e.printStackTrace();
		}

		return data;
	}

	private static void createDataSets(){

		int nMines =	15;
		String rootDir  = "../data/"+nMines+"mines/";
		File f = new File(rootDir);
		f.mkdir();

		int[] noTrains = new int[]{3, 2, 3, 2};
		int[] capacity = new int[]{3000, 5400, 7200, 8400};
		int [] lTime = new int[]{1, 2, 3, 4};
		int [] pTime = new int[]{5, 5, 6, 6};	
		int prod_cap = 400;
		int inv_cap = 20000;
		int hm = 1;
		int ht = 3;
		int dem = 50000;
		int order = 100;
		int periods = 200;
		int avgProd  = 25000;
		int maxN =  4;

		MyUtils utils = new MyUtils("");

		for(int no=0; no < 30; no++){

			String str="";

			str += makeString(noTrains);
			str += makeString(capacity);
			str += makeString(lTime);
			str += makeString(pTime);
			str += (nMines+ "\n");
			Random R = new Random();

			for(int i=0; i < nMines; i++){
				int nOrders = 1 + R.nextInt(maxN-1);
				int ordTime = 10;
				int ordQty =  100;
				str += "[";
				for(int k=0; k < nOrders; k++) {
					ordTime  += (10+ R.nextInt(Math.min(periods-ordTime-10, periods/nOrders-1)));

					ordQty += 100*Math.round((5000+ R.nextInt(10000))/100);
					if(k >0) str+= ", ";
					str += ("["+ordTime +", " + ordQty+"]");
				}
				str +="]\n";
			}

			str += prod_cap +"\n";
			str +=  inv_cap +"\n";
			str +=  hm +"\n";
			str +=  ht +"\n";
			str +=  dem +"\n";
			str +=  order +"\n";
			str +=  periods +"\n";
			utils.printf(str, rootDir+ "Data_H"+no+".dat");
		}

	}
	private static String makeString(int[] arr){
		String s="[";
		for(int i=0; i< arr.length; i++){
			if(i >0 ) s+=", ";
			s += arr[i];
		}
		s += "]\n";
		return s;
	}


}
