package imura;

import ilog.concert.IloException;


public class Data {

	int 		nMines;
	int 		nTypes;
	int 		nPeriods;

	Mine[] mine;
	Train[] TrClass;	
	Configuration conf = new Configuration();	
//	boolean CG_hotStart = true;
	
	public Data() {
		super();
		conf = new Configuration();	
	}

	Data(String filename) throws IloException, java.io.IOException,
	InputDataReader.InputDataReaderException
	{			
		InputDataReader reader = new InputDataReader(filename);		
		int[] TrArray		= reader.readIntArray();
		double[] TrTypeCap	= reader.readDoubleArray();
		// int[] sTime		= reader.readIntArray();
		int[] lTime		= reader.readIntArray();
		int[] pTime		= reader.readIntArray();

		nTypes = TrArray.length;

		TrClass =  new Train[nTypes];
		for(int i=0; i < nTypes; i++)
			TrClass[i] = new Train();

		for(int i=0; i < nTypes; i++){			
			TrClass[i].number = TrArray[i];
			TrClass[i].vol = TrTypeCap[i];
			TrClass[i].lTime = lTime[i];
			TrClass[i].pTime = pTime[i];
			TrClass[i].sTime = pTime[i]; // at present both are equal
			TrClass[i].e_tau = TrClass[i].lTime +TrClass[i].pTime ;
			TrClass[i].g_tau = TrClass[i].sTime  +TrClass[i].e_tau ;
		//	TrClass[i].fixedcost = TrClass[i].vol*100;
			TrClass[i].runningcost = TrClass[i].vol/100;
			
		}

		nMines		= reader.readInt();
		mine = new Mine[nMines];

		int [][][] 	deInput = new int[nMines][][];
		for(int i=0; i < nMines; i++){
			deInput[i]		= reader.readIntArrayArray();
		}

		int prod_cap	= reader.readInt();
		int invCap 	= reader.readInt();
		double hCostM		= reader.readDouble();
		double hCostT		= reader.readDouble();
		double DemCost 	= reader.readDouble();
		double OC1	= reader.readDouble();
		nPeriods 	= reader.readInt();
		
		for(int i=0; i < nMines; i++){			
			mine[i] = new Mine(nPeriods, nTypes);
			mine[i].orderCost = new double[nTypes][nPeriods];
			mine[i].OC = OC1;
			for(int m=0; m<nTypes; m++)			
				for(int t=0; t < nPeriods; t++)
					mine[i].orderCost[m][t] = OC1;
			
			mine[i].prodCap = prod_cap;
			mine[i].invCap = invCap;
			mine[i].hCostM = hCostM;
			mine[i].hCostT = hCostT;
			mine[i].demCost = DemCost;
			mine[i].initInv = 0;
			mine[i].mIdx = i;			
		}


		for(int i=0; i <nMines; i++){				
			int K = deInput[i].length;
			mine[i].dueDate =  new int[K]; 
			mine[i].Order =  new int[K];
			for(int k=0; k<K; k++){
				mine[i].dueDate[k] = deInput[i][k][0];
				mine[i].Order[k] = deInput[i][k][1];				
			}
		}			

		for(int i=0; i <nMines; i++){
			mine[i].Demand = new int[nPeriods];
			for(int t=0; t < nPeriods; t++){
				mine[i].Demand[t] =0;		
				for(int k=0; k< mine[i].dueDate.length ; k++)
					if (mine[i].dueDate[k]<= t)
						mine[i].Demand[t] = mine[i].Order[k];
			}
		}
	}

	
	public void resetOrderCost(){
		try{
			for(int i=0; i <nMines; i++){
			for(int m =0 ; m < nTypes; m++)
				for(int t=0; t< nPeriods; t++)
					mine[i].orderCost[m][t]= mine[i].OC;
			}
		}catch(Exception e){
		}
	}


	public class Train { //train class
		double vol = 0.0; // volume
		int number=0; //no of trains 
		int lTime; //loading
		int pTime;
		int sTime;
		int g_tau; //total turn around time
		int e_tau; // time to load and reach the terminal
	//	double fixedcost;
		double runningcost;
		float utilisation;


		Train(){
		}

	}


class Configuration{
	int itrLimit = 100;
	int LR_UB_Choice = 0;
	int Model_Choice = 4; 
	double Mine_CPX_Gap = 0.0;
	double CM_CPX_gap = 2.0;
	double LR_GAP_LIMIT = 0;
	double GAMMA_MAX = 0.65;
	int LR_TIME_LIMIT  = 3600;
	double STEP_LIMIT = 1e-4;
	
	int Mine_CPX_TimeLimit = 0;
	int CM_CPX_TimeLImt = 0;
	
	String filePrefix ="";
	String datafile="";
	
	Configuration(){
		
	}
}

	//================================================================================================================================

}
