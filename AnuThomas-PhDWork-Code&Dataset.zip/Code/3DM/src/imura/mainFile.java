package imura;

import java.io.FileNotFoundException;

import ilog.concert.IloException;
import ilog.cplex.IloCplex;
import imura.Data.Configuration;

// This is the coMmon file to run all programs under this work


public class mainFile {
	static String DataPrefix;
	static String baseDir;
	static int modelChoice = -1;

	public static void main( String[] args ) {

		if(args.length >0)
			modelChoice = Integer.valueOf(args[0]);

		int[] mineNo = {7, 10, 5, 6, 8, 9, 12, 15, 17, 20};
		//String[] dataLetter = {"A", "B", "C", "D","E","F", "G", "H","I","J"};
		String[] dataLetter = {"P", "Q", "R", "S","T","U"};
	// for(int u : (new int[]{0})){
		for(int u =1 ; u< dataLetter.length; u++){
			long start = System.currentTimeMillis();
			System.out.println("starting ............");
			int nMines = 6+ u*3;
			DataPrefix = dataLetter[u];
			//String filename = "data/"+mineNo[u]+"mines/";
			String filename = "data3pU/"+nMines+"mines/";
			filename += "Data_3pU_"+dataLetter[u];
			try{
				runModel(filename, u);
			}catch(Exception e){
				e.printStackTrace();
			}
			System.out.println("Total execution time "+ (System.currentTimeMillis() - start)/1000F +" secs");
			System.out.println("\nfinished............"+ DataPrefix);
		}

		System.out.println("\nfinished............");

	}


	//
	private static void runModel(String dataseries, int u){

		try {

			IloCplex cplex = new IloCplex();
			// int[][] Colln ={{4, 7,8},{2,5,15}, {12,13,14},{4,7,13},{15},{1,2,3,4,5}};

			int[] Colln ={1,2,3}; //data set
			//
			for(int set : Colln){
		//for(int set = 1; set < 11; set++){
				//		if(set==7) continue;

				String filename = dataseries +set+".dat";

				long start = System.currentTimeMillis();
				Data data =  readData(filename);

				for(int i=0; i < data.nMines; i++)
					data.mine[i].initTrAvailAndDelay(data);//init				

				if(modelChoice == -1)
					modelChoice = data.conf.Model_Choice;

				switch(modelChoice){
				case 1: 	
					// Centralised model
					data.conf.filePrefix ="3pu_CM_"+DataPrefix+"_";
					CentModel CM = new CentModel(data);
					CM.solve(cplex, data.conf.LR_GAP_LIMIT, data.conf.CM_CPX_TimeLImt);
					//	CM.solve(0,0,"cent_sol_rail_p4.mst");
					break;
				case 4:
					data.conf.filePrefix ="3pu_CG_"+DataPrefix+"_";
					try{						
						NewColGen CG = new NewColGen(data);
						CG.solveWithColGen(cplex);						
					}catch(Exception e){
						e.printStackTrace();
						System.out.println("Error in data set - " + set);
					}
					break;
				case 49:
					System.out.println("Separate obj model");
					data.conf.filePrefix ="3pu_d_CG_"+DataPrefix+"_";
					try{						
						NewColGen CG = new NewColGen(data);
						CG.solveWithColGen(cplex);						
					}catch(Exception e){
						e.printStackTrace();
						System.out.println("Error in data set - " + set);
					}
					break;
				case 99: 
					for(int i = 0; i < data.nMines; i++)  
						data.mine[i].solveMineProb(cplex,data);
					break;

				case 601: // CG
					data.conf.filePrefix ="CG_3DM_"+DataPrefix+"_";
					try{

					}catch(Exception e){
						e.printStackTrace();
						System.out.println("Error in data set - " + set);
					}
					break;



				default: 
					System.out.println("Invalid choice");
				}	
				System.out.println("Set "+set+ " eTime "+ (System.currentTimeMillis() - start)/1000F +" secs");
			} // data set; Colln

			cplex.end();

		} catch (IloException e) {
			// TODO Auto-generated catch block		
			e.printStackTrace();
		}
	}

	private static void setConfigParameters(Data data){

		Configuration conf = data.conf;
		conf.itrLimit = 500;
		conf.LR_UB_Choice = 0;
		conf.Model_Choice = 49;// 1; // 99; 
		conf.Mine_CPX_Gap = 0.0;
		conf.CM_CPX_gap = 0.02;
		conf.Mine_CPX_TimeLimit = 0;
		conf.LR_TIME_LIMIT  = 3600*2;
		conf.CM_CPX_TimeLImt = 3600*2;		 
		// String filename = "data/10mines/Data_B"+fNo+".dat";
	}


	//================================================================================================================================

	private static Data readData(String filename) {

		System.out.println("Input data file : "+ filename);
		Data data =null;

		try {
			data = new Data(filename);
			setConfigParameters(data);
			data.conf.datafile = filename;
		} catch(FileNotFoundException ex)  	{
			System.out.println("File ("+filename+") not found.");
		}
		catch (Exception e) {
			System.out.println("ERROR in Input file reading");
			e.printStackTrace();
		}

		return data;
	}

}
