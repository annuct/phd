package imura;

import java.text.DecimalFormat;
import java.util.*;

import ilog.concert.IloException;
import ilog.concert.IloIntVar;
import ilog.concert.IloNumExpr;
import ilog.concert.IloNumVar;
import ilog.cplex.IloCplex;
import imura.Data;
import imura.Data.Train;
import imura.RailOpr.Job;

public class Mine { //Mine class

	int nOrders;
	int prodCap;
	int invCap;
	int initInv;
	int nTrClass;
	int mIdx;
	int nTypes;
	int nPeriods;
	int[] Order; // cumulative
	int[] dueDate; // due date of orders
	int[] Demand;
	int[] Delay;	
	int[][] TrAvail;	

	double hCostM; // holding cost at mine
	double hCostT;
	double demCost;
	double dualPrice=0;
	double objcost;
	double RailScaling=0;
	double ShipScaling=0;

	double[][] mylambda 	=  new double[nTypes][nPeriods];
	double[] mymu 	=  new double[nPeriods];
	//double[][] orderCost;	 
	double OC; 
	private MineSol sol = null; 

	IloMineVars MV = new IloMineVars();
	boolean relax= false;
	boolean resConstraint = false;
	boolean demuPref = true;
	double[] relaxedSol;
	boolean msgflag = true;
	Vector<String> lpColList = new Vector<String>();
	Vector<String> mipColList = new Vector<String>();
	Vector<String> checkedSolution = new Vector<String>();

	Vector<MineSol> colVector = new Vector<MineSol>();
	Vector<MineSol> allColumns= new Vector<MineSol>();

	public class IloMineVars{
		IloNumVar[][] AQty;
		IloNumVar ObjVar;
		IloNumVar[] Inv;
		IloNumVar[] OS;
		IloNumVar[] US;
		IloNumVar[] Y;
	}

	public  class MineSol{

		double[] ProdPlan;
		int[][] TrRequest;
		int[] 	TrCombo;
		int[][] nRN_Trains;
		int[][] nUL_Trains;
		double actMineCost;
		double[]  CumDelivery;
		double value=0;
		double railobjcost=0;
		//	int[] SolInv;		
		int[] SolY; 
		String key_str;
		int nonBasicCnt =0;
		String source;
		public int[] orderqty;

		public MineSol() {
			// TODO Auto-generated constructor stub
			ProdPlan = new double[nPeriods];
			//	SolInv = new int[nPeriods];
			SolY = new int[nPeriods];
			CumDelivery = new double[nPeriods];
			orderqty = new int[nPeriods];
			TrRequest =  new int [nTypes][nPeriods];
			nRN_Trains = new int [nTypes][nPeriods];
			nUL_Trains = new int [nTypes][nPeriods];
			TrCombo =  new int[nTypes];
			actMineCost = 0.0;
			nonBasicCnt=0;
			key_str="";

			//itrIdx = itr;
		}
	}
	public Mine(int T, int M){
		nTypes = M;
		nPeriods = T;	
	}
	public void solveMineProb(IloCplex cplex, Data data) throws IloException{
		solveMineProb(cplex, data, 0,0);
	}

	//	public boolean solveMineProb(IloCplex cplex, Data data, double gap, int time) throws IloException{
	//		return solveMineProb(cplex, data, gap, time, null);
	//	}
	//====================================================================
	//public boolean solveMineProb(IloCplex cplex, Data data, double gap, int time, int[] TrCombo) 
	public boolean solveMineProb(IloCplex cplex, Data data, double gap, int time)
			throws IloException {
		RailScaling = 	data.conf.RailObjScaling;
		ShipScaling = 	data.conf.ShipDemurrage;
		
		MyUtils Utils = new MyUtils(data.conf.filePrefix);	

		cplex.clearModel();		
		addConstraints(data, cplex);
		cplex.addMinimize(MV.ObjVar);		

		//	cplex.exportModel("mine_"+mIdx+".lp");	
		// initialiseSol(); //refreshing the object
		if(!Utils.solveAndRecord(cplex,  "Mine-"+mIdx, gap, time))
			return false;
		objcost = (double)cplex.getObjValue();
		writeOutputs(cplex, data);
		return true;
	}  

	public boolean checkColumnFeasibility(IloCplex cplex, Data data, int idx) 
			throws IloException {
		MyUtils Utils = new MyUtils(data.conf.filePrefix);	

		cplex.clearModel();		
		addConstraints(data, cplex);
		cplex.addMinimize(MV.ObjVar);

		if(idx <0) idx = colVector.size()-1;

		int[][] TrReq = colVector.get(idx).TrRequest;
		for(int m=0; m < nTypes; m++){
			int cnt=0;
			for(int t=0; t <nPeriods; t++)
				if(TrReq[m][t] >0){
					cplex.addEq(MV.AQty[m][t], cnt+1);
					cplex.addEq(MV.AQty[m][t-1], cnt);
					cnt =cnt+1;
				}
			if(cnt==0)
				cplex.addEq(MV.AQty[m][nPeriods-1], 0);
		}


		if(!Utils.solveAndRecord(cplex,  "Mine-"+mIdx, 0, 0)){
			System.err.println(" Failed with mine model");
			return false;
		}
		objcost = (double)cplex.getObjValue();
		System.out.println(" Verified columns with mine model " +idx + " objcost "+ objcost+" regCost"+ colVector.get(idx).value );
		return true;
	}  




	//====================================================================
	public void addConstraints(Data data, IloCplex cplex) throws IloException{		

		Train[]  TrClass 	= data.TrClass;		

		MyUtils Utils = new MyUtils(data.conf.filePrefix);


		MV.Inv         	= cplex.intVarArray(nPeriods, 0, Integer.MAX_VALUE);	     
		MV.OS     		= cplex.intVarArray(nPeriods, 0, Integer.MAX_VALUE);
		MV.US     		= cplex.intVarArray(nPeriods, 0, Integer.MAX_VALUE);
		MV.Y  			= cplex.intVarArray(nPeriods, 0, 1); //Demurrage
		MV.AQty 		= new IloIntVar[nTypes][]; // Total number of requests by time t
		MV.ObjVar 		=  cplex.numVar(Integer.MIN_VALUE, Integer.MAX_VALUE);


		for(int t=0; t < nPeriods ; t++){
			MV.Inv[t].setName("Inv("+mIdx+"_"+   t+")");                    
			MV.OS[t].setName("OS("+mIdx+"_"+ t+")");
			MV.US[t].setName("US("+mIdx+"_"+ t+")");
			MV.Y[t].setName("Y("+mIdx+"_"+ t+")");
		}

		for(int m=0; m < nTypes; m++){			
			MV.AQty[m] = cplex.intVarArray(nPeriods, 0, nPeriods);
			for(int t=0; t < nPeriods ; t++){
				MV.AQty[m][t].setName("AQ("+mIdx+"_"+ m+"_"+  t+")");
			}			
		}


		MV.ObjVar.setName("Mine_ObjVar_"+mIdx);
		IloNumExpr  indMineObj = cplex.intExpr();

		for (int w = 0; w < nTypes; w++) 
			cplex.addEq(MV.AQty[w][0],0);

		for (int t = 1; t < nPeriods; t++) {	
			// 25: The inventory at end of period t cannot be more than the holding capacity of the mine.
			cplex.addLe(MV.Inv[t], invCap);

			IloNumExpr  qtySum = cplex.intExpr();
			IloNumExpr  TrCnt = cplex.intExpr();
			qtySum = cplex.constant(0);                                                       
			TrCnt = cplex.constant(0);

			for (int w=0; w < nTypes; w++){
				//22: Total number of trains requested on or before time t is non-decreasing.
				cplex.addGe(MV.AQty[w][t],MV.AQty[w][t-1]).setName("AQ_Pre_"+mIdx+"_"+w+"_"+t);						

				qtySum = cplex.sum(qtySum, cplex.prod(cplex.diff(MV.AQty[w][t],MV.AQty[w][t-1]),(int)TrClass[w].vol));
				TrCnt = cplex.sum(TrCnt,cplex.diff(MV.AQty[w][t],MV.AQty[w][Math.max(0, t -TrClass[w].time[1])]));                                                              
			}
			// 30: Only one train can load at the mine at a given time period.
			cplex.addLe(TrCnt,1).setName("TrainCount_"+mIdx+"_"+t); // one loading at a time 

			// 24: The inventory balancing constraint: Inventory at time t can be computed by subtracting the supply at time t from the sum of previous inventory and production at time t.
			// and substitute rho <= P 
			cplex.addLe(cplex.sum(cplex.diff(MV.Inv[t], MV.Inv[t-1]), qtySum), prodCap).setName("Prod_Cap_"+mIdx+"_"+t);

			IloNumExpr  cumSupply1 = cplex.intExpr();
			cumSupply1 = cplex.constant(0);

			int minTrTime = nPeriods; 
			int [] UB_noTrains = new int[nTypes];
			IloNumExpr  cumDel = cplex.numExpr();
			int initialInv =0;

			for (int w=0; w < nTypes; w++){

				minTrTime = Math.min(minTrTime, TrClass[w].Ltime);
				int t1 		= Math.max(0,(t-TrClass[w].Ltime)) ;
				double b3 		= Math.min(t*prodCap +initialInv, Demand[nPeriods-1]+ TrClass[nTypes-1].vol) ;

				cumDel = cplex.sum(cumDel, cplex.prod(MV.AQty[w][t1],Math.ceil(TrClass[w].vol/TrClass[0].vol)));

				// plan the production based on train availability( free)


				cumSupply1 = cplex.sum(cumSupply1,cplex.prod(MV.AQty[w][t1],TrClass[w].vol));				
				UB_noTrains[w] = Math.max(0, (int)Math.floor((float)b3 /TrClass[w].vol));
				//32: for individual trains 
				cplex.addLe(MV.AQty[w][t], UB_noTrains[w]).setName("AQ_UB_ind");


				int[] tmpArray = Utils.subArray(TrClass, w);
				int gcd = Math.max(Utils.gcd(tmpArray),1);

				IloNumExpr newExpr= cplex.numExpr();

				if(w < nTypes-1){ // if m = nTypes -1, then there is only one term, that is already covered above
					int[] newCoeff = new int[nTypes-w];
					int rhs = (int) Math.max(0,Math.floor(b3/gcd));

					for(int m1= 0; m1 < newCoeff.length ; m1++)
						newCoeff[m1] = (int)TrClass[m1+w].vol/gcd;

							
					if (rhs >0) {
						for(int m1=w; m1 < nTypes; m1++)
							newExpr = cplex.sum(newExpr,cplex.prod(newCoeff[m1-w], MV.AQty[m1][t]));
						//35: ~~~~ 32 
						cplex.addLe(newExpr, rhs).setName("AQ_RecurUB_"+mIdx+"_"+w+"_"+t);
					}
				}

				if (t+TrClass[w].Ltime > nPeriods)
					cplex.addEq(MV.AQty[w][t],MV.AQty[w][t-1]).setName("AQ_Last_"+mIdx+"_"+w+"_"+t);	


				if(resConstraint){ //resource constraint
					// for each mine, class and time 
					int tEnd = Math.min(nPeriods-1, t+TrClass[w].time[0]);
					int tStart = Math.max(0, t-TrClass[w].Ltime-TrClass[w].time[4]);	
					cplex.addLe(cplex.diff(MV.AQty[w][tEnd], MV.AQty[w][tStart]),TrClass[w].number).setName("LinkingConst_"+w+"_"+t);
				}		
			}

			for(int k=0 ; k < Order.length; k++){		
				int noTrainsReq = (int)Math.ceil(Order[k]/data.TrClass[0].vol);

				if((k== dueDate.length-1 && t >= dueDate[k]) || (dueDate[k] <= t && t < dueDate[k+1] )){
					cplex.addGe(cumDel, cplex.prod(noTrainsReq,cplex.diff(1.0, MV.Y[t]))).setName("Cut_"+k+"_"+t);
				}

			}
			// 26: If a train of class w has to deliver its cargo at the terminal at time t, then it should reach the
			cplex.addGe(Demand[t], cplex.diff(cumSupply1,MV.OS[t])).setName("CumSupply_"+mIdx+"_"+t);
			cplex.addLe(Demand[t], cplex.sum(cumSupply1,MV.US[t])).setName("UnderStock_"+mIdx+"_"+t);

			float UB_OverStk = Math.max(0, (float)(t-minTrTime))*prodCap + initInv-Demand[t];
			//Overstock is limited with needed supply + max extra trip
			double UB2 =  Math.max(0, Math.min(UB_OverStk, Demand[nPeriods-1]- Demand[t]+ TrClass[nTypes-1].vol));
			// 33: 
			cplex.addLe(MV.OS[t],  UB2).setName("OS_UB_"+mIdx+"_"+t); // upperbound for overstock



			for(int k =0; k <  Order.length; k++){
				if(t == dueDate[k]){
					//27: (u-1)th order must be delivered before the due-date of the uth order, Fu . This also implies that
					//	at any time t at most one order for a mine can be tardy. In other words, cumulative supply at
					//	time Fu should be not less than the demand at time Fu-1 .

					if(k>0 ) cplex.addGe(cumSupply1,  Order[k-1]).setName("Order_"+(k-1)+"_should_be_met_before_"+t);
				}

				if ( (k < Order.length-1 &&  dueDate[k] < t && t < dueDate[k+1] ) ||
						(k==Order.length-1 && t > dueDate[k] ))
					//37: The demand changes only at the due-date of orders
					cplex.addGe(MV.Y[t-1], MV.Y[t]).setName("YPreced_"+t);
			}
			if(t>= dueDate[0]){
				indMineObj = cplex.sum(indMineObj, cplex.prod(MV.Y[t], demCost));
				// 28: If the cumulative supply at time t is less than its demand then the producer needs to pay demurrage cost.
				cplex.addGe(cplex.prod(Demand[t], MV.Y[t]), cplex.diff(Demand[t], cumSupply1));
			}
			//34: If a producer overstocks at the terminal then it cannot incur demurrage.
			double Vmax =TrClass[nTypes-1].vol;
			cplex.addLe(MV.Y[t], cplex.diff(1, cplex.prod(MV.OS[t], 1.0/(Math.min(t*prodCap, Demand[MV.Y.length-1]+Vmax)) )));

			if(t==nPeriods-1){
				//29: All orders must be met by the end of the planning horizon.
				cplex.addGe(cumSupply1, Demand[t]).setName("Supply_T_"+mIdx);

				IloNumExpr  TrSum = cplex.intExpr();
				for (int m=0; m < nTypes; m++){
					TrSum = cplex.sum(TrSum, MV.AQty[m][t]);		
					cplex.addLe(MV.AQty[m][t], Math.floor(Demand[t]/TrClass[m].vol)+1);							
				}
			}		
		} // t Loop


		cplex.addEq(MV.Y[nPeriods-1],0);// there should not be any demurrage at time T
		cplex.addEq(MV.Y[0],1);// there should not be any demurrage at time T

		cplex.addEq(MV.Inv[0], initInv);
		cplex.addEq(MV.OS[0], 0);
		cplex.addEq(MV.US[0], 0);
		cplex.addEq(MV.US[nPeriods-1], 0);
		cplex.addEq(MV.Inv[nPeriods-1], 0);

		for (int t = 0; t < nPeriods; t++){
			indMineObj = cplex.sum(indMineObj, cplex.prod(MV.Inv[t], hCostM));
			indMineObj = cplex.sum(indMineObj,cplex.prod(MV.OS[t], hCostT));
		if(data.conf.Model_Choice!=49)
			indMineObj = cplex.sum(indMineObj,cplex.prod(MV.US[t], ShipScaling));
		}

		for (int m=0; m < nTypes; m++)
			indMineObj = cplex.sum(indMineObj, cplex.prod(MV.AQty[m][nPeriods-1],OC));


		if(data.conf.Model_Choice==4 || data.conf.Model_Choice==49){ // Only for CG
			// Running cost is already accounted using the addValuesFrom RO function
			//lambda term
			for(int t=0; t < nPeriods; t++){
				IloNumExpr qmu = cplex.constant(0);				 
				for(int m=0; m < nTypes; m++){				
					int tStart = Math.min(nPeriods-1,t+data.TrClass[m].time[0]);
					int tEnd = Math.max(0,t-data.TrClass[m].Ltime-data.TrClass[m].time[4]);
					double cost = mylambda[m][t]+ RailScaling*data.TrClass[m].runningcost;
if(data.conf.Model_Choice==49)
	 cost = mylambda[m][t];
					IloNumExpr q = cplex.prod(cplex.diff(MV.AQty[m][tStart],MV.AQty[m][tEnd]), cost);					
					indMineObj = cplex.sum(indMineObj,q);
					int t1 = Math.max(0, t - data.TrClass[m].time[1] -data.TrClass[m].time[2]); 
					int t2 = Math.max(0, t - data.TrClass[m].Ltime);
					qmu = cplex.sum(qmu, cplex.diff(MV.AQty[m][t1],MV.AQty[m][t2]));					
				}
				indMineObj = cplex.sum(indMineObj,cplex.prod(qmu, mymu[t]));
			}
		}

		cplex.addEq(MV.ObjVar, indMineObj).setName("ObjVal_Const_"+mIdx);

	//	fix_mine_solution(cplex,data);
	}





	private void fix_mine_solution(IloCplex cplex,Data data) throws IloException {
		// TODO Auto-generated method stub
		String SolnStr = "M-0 _(0,21)_(0,94)_(0,99)_(1,14)_(1,48)_(2,65)_Cost=1060280 value 1060280 \n "+
"M-1 _(0,64)_(0,66)_(0,67)_(0,112)_(2,42)_(3,104)_Cost=501340 value 501340\n "+
"M-2 _(0,35)_(0,77)_(0,79)_(0,103)_(1,14)_(1,31)_(1,96)_(3,71)_Cost=1013260 value 1013260\n "+
"M-3 _(0,18)_(0,31)_(0,48)_(0,107)_(1,59)_(1,105)_Cost=797860 value 797860\n "+
"M-4 _(1,42)_(2,89)_(2,114)_Cost=498420 value 498420\n "+
"M-5 _(0,28)_(1,79)_(1,82)_(2,21)_Cost=514280 value 514280\n "+
"M-6 _(0,43)_(0,44)_(0,116)_(1,65)_(1,113)_(3,25)_Cost=1270980 value 1270980";

		String [] key = SolnStr.split("\n");
		String mykey = key[mIdx];
		key = mykey.split("_");
		String outstr = mykey;

		int[] trType = new int[key.length-2];
		int[] time = new int[key.length-2];

		for(int k=1; k < key.length-1; k++){
			String[] entries = key[k].replace("(","").replace(")", "").split(",");
			trType[k-1] = Integer.valueOf(entries[0]);
			time[k-1] = Integer.valueOf(entries[1]);
		}
		for(int m=0; m< data.nTypes; m++){
			int cnt = 0;
			for(int k=0; k < time.length; k++){
				if(trType[k]==m){
					cnt ++;
				//	outstr += "cplex.addEq(MV.AQty["+m+"]["+time[k]+"],"+cnt+");cplex.addEq(MV.AQty["+m+"]["+(time[k]-1)+"],"+(cnt-1)+") \n";
					cplex.addEq(MV.AQty[m][time[k]],cnt);
					cplex.addEq(MV.AQty[m][time[k]-1],cnt-1); 
				}
			}
		}
		System.out.println(outstr);
	}
	
	
	public void writeOutputs(IloCplex cplex, Data data) throws IloException{
		writeOutputs(cplex, data, 0);
	}
	public void writeOutputs(IloCplex cplex, Data data, int solNo) throws IloException{
		if(relax) return;

		MyUtils Utils = new MyUtils(data.conf.filePrefix);		

		DecimalFormat fourDec = new DecimalFormat("#.####");		
		String toPrint = "\n ## Mine-"+mIdx+" ##\n";                                              

		toPrint += "Requests (time, Train): ";

		initialiseSol(data);
		sol.ProdPlan[0] =0;
		int[] SolInv  = new int[nPeriods];
		if(!relax){			
			sol.SolY = new int[nPeriods];
			sol.CumDelivery =  new double[nPeriods];
		}

		for (int t =0; t < nPeriods; t++)
			sol.CumDelivery[t] = 0;

		for (int t =0; t < nPeriods; t++){
			double currSupply = 0;			
			for(int k=0; k < nTypes; k++ ){				
				if(t>0)
					sol.TrRequest[k][t] = Math.round((float)(cplex.getValue(MV.AQty[k][t], solNo)-cplex.getValue(MV.AQty[k][t-1], solNo)));
				else
					sol.TrRequest[k][t] = 0;

				if (sol.TrRequest[k][t] >0){
					currSupply += data.TrClass[k].vol;
					toPrint += "("+t + ", "+k+") \t";
					int idx = Math.min(nPeriods-1, t+data.TrClass[k].Ltime);
					sol.CumDelivery[idx] += data.TrClass[k].vol;			
				}				
			}

			if(!relax){
				SolInv[t] = 	 Math.round((float) cplex.getValue(MV.Inv[t], solNo));		
				if (t>0)
					sol.ProdPlan[t] = SolInv[t]- SolInv[t-1]+currSupply;			
				sol.SolY[t] =  Math.round((float) cplex.getValue(MV.Y[t], solNo));
			}			
		}

		for (int t =1; t < nPeriods; t++)
			sol.CumDelivery[t] += sol.CumDelivery[t-1];

		double totalinv=0;
		double totalhT=0;
		double totalUS=0;
		double totaldem=0;
		double ordercost=0;
		//	double orgordercost=0;

		for (int t =0; t < nPeriods; t++){
			totalinv +=  Math.round((float)cplex.getValue(MV.Inv[t], solNo));                                                                 
			totalhT +=  Math.round((float)cplex.getValue(MV.OS[t], solNo));
			totalUS +=  Math.round((float)cplex.getValue(MV.US[t], solNo));
			for(int k=0; k < nTypes; k++ ){				
				ordercost +=  sol.TrRequest[k][t]*OC; // orderCost[k][t]; 
			}
		}


		for (int t = dueDate[0]; t < nPeriods; t++)
			totaldem +=  Math.round((float)cplex.getValue(MV.Y[t], solNo));	


		double rcost =0;
		for(int t=0; t < nPeriods; t++){
			//int trs_needed_t = 0;
			for(int m=0; m < nTypes; m++){
				int tEnd = Math.min(nPeriods-1, t+data.TrClass[m].time[0]);
				int tStart = Math.max(0, t-data.TrClass[m].Ltime-data.TrClass[m].time[4]);

				int tEnd2 = Math.max(0, t-data.TrClass[m].time[1]-data.TrClass[m].time[2]);
				int tStart2 = Math.max(0, t-data.TrClass[m].Ltime);


				sol.nRN_Trains[m][t] = (int)Math.round((cplex.getValue(MV.AQty[m][tEnd], solNo)-cplex.getValue(MV.AQty[m][tStart], solNo)));
				sol.nUL_Trains[m][t] = (int)Math.round((cplex.getValue(MV.AQty[m][tEnd2], solNo)-cplex.getValue(MV.AQty[m][tStart2], solNo)));

				rcost += sol.nRN_Trains[m][t]*data.TrClass[m].runningcost;
				if(t == nPeriods-1)
					sol.TrCombo[m] = (int)Math.round(cplex.getValue(MV.AQty[m][t], solNo));
			}
		}

		totalUS= totalUS*ShipScaling;
		double TotCost = totalinv*hCostM+ totalhT*hCostT+ totalUS + totaldem*demCost+ordercost+rcost*RailScaling;
		sol.actMineCost = (int)Math.round(TotCost);

		sol.railobjcost = rcost*RailScaling;

		toPrint += "\nObj("+mIdx+") = " + fourDec.format(TotCost) + "  = "+ totalinv*hCostM +"(InvHM)+ " + totalUS + " (US) "
				+totalhT*hCostT  +"(InvHT)+ " + totaldem*demCost +"(Dem)+"+ fourDec.format(ordercost) +"(Order)" + " RunCost ="+rcost;    
		toPrint += "\n ------------------------------- \n";		
		
		String toPrint2 = "NOV14:M+"+mIdx+":"+TotCost + " = "+ totalinv*hCostM +":"+totalhT*hCostT +":" +
		totaldem*demCost +":"+ ordercost +":"  + ""+rcost;
		
	//	System.out.println(toPrint2);

		if(msgflag){
			Utils.printf(toPrint);
			System.out.println(toPrint);
		}

		sol.source ="Mine";
	}

	public double[] createProdPlan (RailOpr RO, Data data){
		double[] ProdPlan = new double[nPeriods];

		int[] reqInv = new int[nPeriods];
		int[] jump  = new int[nPeriods];

		for(int i=0; i< data.nMines; i++){
			for(int t=0; t< nPeriods; t++){
				ProdPlan[t] =0;
				reqInv[t] = 0;
				jump[t]= 0;
			}
		}

		Job[]  Jobsi = RO.getJobsOfMine(mIdx);
		for(Job j: Jobsi){
			int time =  Math.min(nPeriods-1, j.cDate - j.time[1]-j.time[2]-j.time[3]); //arrival	

			int told = time;
			if(time  < 1) 	continue; //means that job is not done
			reqInv[time] += j.vol;					
			ProdPlan[time] = data.mine[mIdx].prodCap;

			while(reqInv[time] > 0){					
				time--;			
				int newVal = (reqInv[time+1] - data.mine[mIdx].prodCap);				

				if(time < 0)
					told=2;
				if (jump[time] ==0 && newVal< 0)
					break;
				reqInv[time] = jump[time] + newVal;						
			}				
			jump[told-1] = (int) j.vol;
			reqInv[told] -= (int) j.vol;
		}
		for(int t=1; t< nPeriods; t++){
			ProdPlan[t] += Math.max(0, (reqInv[t]-reqInv[t-1]));
		}
		return ProdPlan;
	}

	public double computeActualCost(RailOpr RO, Data data){
		initialiseSol(data); 
		sol.ProdPlan = createProdPlan(RO, data);
		// original global costs
		double[] InvHolding = new double[RO.Tmax];
		double[] cumsupply = new double[RO.Tmax];


		int[] Cost = new int[6];
		int nJobs = RO.Jobs.length;
		MyUtils Utils = new MyUtils(data.conf.filePrefix);

		InvHolding[0] =0;				
		cumsupply[0]=0;
		for(int a =0; a< Cost.length; a++)
			Cost[a] =0;

		for(int t=1; t< RO.Tmax; t++) {
			cumsupply[t]= cumsupply[t-1];
			InvHolding[t] =InvHolding[t-1] ;
			if (t < nPeriods){
				InvHolding[t] +=  sol.ProdPlan[t];
				sol.SolY[t] = 0;
			}

			for(int j=0; j < nJobs; j++){	
				int k = RO.Jobs[j].tIdx;
				int elapTime = data.TrClass[k].Ltime;

				if ( ( RO.Jobs[j].mIdx!= mIdx))
					continue;// No need to proceed with the following check if the above condition is not met


				if ( (t+elapTime < RO.Tmax) && RO.JobSched[j][t+elapTime]- RO.JobSched[j][t-1+elapTime] ==1)
					InvHolding[t] -= data.TrClass[k].vol;

				if (RO.JobSched[j][t]-RO.JobSched[j][t-1]==1){
					cumsupply[t] += data.TrClass[k].vol;			
					int maintime = RO.Jobs[j].time[1]+RO.Jobs[j].time[2]+RO.Jobs[j].time[3];
					if(t- maintime > data.nPeriods-1)
						sol.TrRequest[k][data.nPeriods-1]=100;
					else
						sol.TrRequest[k][t-maintime]=1;
				}
			}
			if(t>=data.nPeriods)
				sol.CumDelivery[data.nPeriods-1] += cumsupply[t];
			else
				sol.CumDelivery[t] = cumsupply[t];

		}

		//After setting only we can compute the cost
		for(int t=1; t< nPeriods; t++) {
			Cost[0] += InvHolding[t]*hCostM; 		// inv holding 	
			Cost[1] += Math.max(0,cumsupply[t]-Demand[t])*hCostT; 		// holding at terminal}
			for(int m=0; m < nTypes; m++)
				Cost[3] += sol.TrRequest[m][t]*OC;// orderCost[m][t];
		}

		for(int j=0; j < nJobs; j++){
			Job jobj = RO.Jobs[j];
			if (jobj.mIdx!= mIdx) continue;
			int last_time_point = jobj.cDate+jobj.time[4]-1;
			int tend = Math.min(nPeriods-1,last_time_point);
			for(int t1=tend; t1 > jobj.cDate; t1--)
				sol.nUL_Trains[jobj.tIdx][t1]++;

			sol.TrCombo[jobj.tIdx]++;
			int jrtime = 0;
			for (int k=0; k < jobj.time.length;k++) jrtime += jobj.time[k];
			for(int t = tend; t > last_time_point - jrtime; t--){
				if(t >= data.nPeriods) continue;
				sol.nRN_Trains[jobj.tIdx][t]++;
			}
		}	

		for(int t= 0; t< nPeriods; t++) {
			if ( Demand[t]-1e-6 > cumsupply[t] ){
				Cost[2] += demCost;	// demurrage
				sol.SolY[t] =1;
				Cost[5] += (Demand[t]-cumsupply[t])*ShipScaling;
			}
			for(int m=0; m< data.nTypes; m++)
				Cost[4] += (sol.nRN_Trains[m][t]*data.TrClass[m].runningcost)*RailScaling;
		}


		double ActCost=0;
		for(int a =0; a< Cost.length; a++)
			ActCost += Cost[a];


		if(RO.Tmax > nPeriods){
			ActCost = ActCost*(RO.Tmax - nPeriods);
			System.out.println("Tmax is exceeding ... ");
		}

		String toPrint = "ActualCost("+mIdx+") = " + ActCost + "  = "+ Cost[0] +"(InvHM)+ "
				+Cost[1] +"(InvHT)+ " +Cost[2] +"(Dem)+"+ Cost[3] +"(Order)"  + " RunCost ="+Cost[4];


		String toPrint2 = "NOV14:M+"+mIdx+":"+ActCost + " = "+ Cost[0] +":"+Cost[1] +":" +Cost[2] +":"+ Cost[3] +":"  + ""+Cost[4];
	//	System.out.println(toPrint2);
		
		
		Utils.printf(toPrint);
		//	System.out.println(toPrint);
		sol.actMineCost = ActCost;
		sol.railobjcost = Cost[4];
		addValuesFromRailOprAndTerminal(-1, data);
		sol.source ="Rail";
		addColumnAndValue(0, data);
		return ActCost;
	}
	public double getActualCost() {
		// TODO Auto-generated method stub
		return sol.actMineCost;
	}
	public double getValue() {
		// TODO Auto-generated method stub
		return sol.value;
	}
	//===========================================================================
	public void initTrAvailAndDelay(Data data) {

		TrAvail = new int[nTypes][nPeriods];			
		Delay = new int[nTypes];
		for(int k=0; k< nTypes; k++){
			Delay[k]=0;
			for (int t =0; t < nPeriods; t++)					
				TrAvail[k][t] = 1;
		}
	}


	public void addAllColumns(IloCplex cplex, Data data) throws IloException{

		int NSols = cplex.getSolnPoolNsolns();
		// if(dualPrice ==0) 
		// NSols =1;
		for(int n=NSols-1; n >=0 ; n--){
			//	System.out.println("Obj "+n+" \t "+ Math.round(cplex.getObjValue(n)) + "\t DualPrice "+ Math.round(dualPrice));
			//	if(dualPrice !=0 && (cplex.getObjValue(n)- dualPrice) > -1e-3) continue;
			writeOutputs(cplex, data, n);
			addColumnAndValue(n, data);
		}
	}

	public void initialiseSol(Data data){
		sol = new MineSol();
		int[] Order = data.mine[mIdx].Order;
		for(int t=0; t< data.nPeriods; t++)
			for(int k=0; k < Order.length; k++ )
				if((k== dueDate.length-1 && t >= dueDate[k]) || (dueDate[k] <= t && t < dueDate[k+1] )){			
					//Order was recorded cumulative, now we compute the actual order qty in the period. 
					sol.orderqty[t] = Order[k]- (k>0? Order[k-1]: 0);
				}	
	}

	public void addColumnAndValue(int no, Data data) {

		if(sol.actMineCost<0) return; // integer rounding issues
		
		String cost_str = "";// +((int)sol.actcost);
		for(int m=0; m< nTypes; m++)
			for(int t=0; t< nPeriods; t++)
				if(sol.TrRequest[m][t]==1) // arrival time
					cost_str += "_("+m+","+t+")";

		sol.key_str = cost_str;
		sol.value = addValuesFromRailOprAndTerminal(no, data)  ;// normalising					

		if( checkedSolution.contains(sol.value+cost_str)){
			//	System.out.println("Col exists " + cost_str+ " or not good " + sol.actcost);
			return;
		}else
			checkedSolution.add(sol.value+cost_str);


		if ( !lpColList.contains(cost_str) &&  !colVector.contains(sol)){
			colVector.addElement(sol);			
			lpColList.add(cost_str);	
			System.out.println("Adding column "+(colVector.size()-1) + " in M"+ mIdx  + " key "+ cost_str+ " cost "+ sol.actMineCost);							
		} 
		else{			
			int idx = lpColList.indexOf(cost_str);
			if (colVector.get(idx).value > sol.value){
				//				System.out.println("Replacing "+idx+" with key "+
				//						cost_str+" :: "+colVector.get(idx).actcost+" with " + sol.actcost);
				colVector.remove(idx);
				lpColList.remove(idx);				
				colVector.insertElementAt(sol, idx);			
				lpColList.insertElementAt(cost_str, idx);
			}
		}

		if (!mipColList.contains(new String(cost_str)) &&  !allColumns.contains(sol)){
			allColumns.addElement(sol);
			mipColList.add(cost_str);
		}
		else{			
			int idx = mipColList.indexOf(cost_str);
			if (allColumns.get(idx).value > sol.value){
				allColumns.remove(idx);
				mipColList.remove(idx);				
				allColumns.insertElementAt(sol, idx);			
				mipColList.insertElementAt(cost_str, idx);
			}
		}
		// System.out.println(" Value of "+mIdx+"  " +no+" = "+sol.value+ " "+objcost+ "  "+sol.actMineCost);
	}

	private double addValuesFromRailOprAndTerminal(int no, Data data) {
		// TODO Auto-generated method stub
		double runcost =0;
		for(int m=0; m < data.nTypes; m++)
			for(int t=0; t < data.nPeriods; t++)
				runcost += sol.nRN_Trains[m][t]*data.TrClass[m].runningcost;
		double out = sol.actMineCost+(no < 0 ? RailScaling*runcost: 0);

		// if(no==0 && data.conf.Model_Choice==4) // only for CG running cost has to be added to the objective
		//	objcost += RailScaling*runcost;

		//	System.out.println("Total "+out+" "+sol.actMineCost+" "+ runcost);
		return out;
	}
	public MineSol getSolution(int idx) {
		// TODO Auto-generated method stub
		if(idx < 0)
			return sol;
		else
			return colVector.get(idx);
	}
	public void setSolution(int idx) {
		// TODO Auto-generated method stub
		sol = colVector.get(idx);
	}
	public int getIdx_mipcol_list() {
		// TODO Auto-generated method stub
		return mipColList.indexOf(sol.key_str);
	}

	public String getMineSolnString(int idx){

		MineSol tmpS = sol;
		if(idx >=0)
			tmpS =allColumns.get(idx);
		String cost_str = "M-"+mIdx+" "+ tmpS.key_str+"_Cost="+(int)tmpS.actMineCost+ " value "+ (int)tmpS.value;
		return cost_str;
	}
	public void set_multipliers(double[][][] lambda, double[][] mu) {
		// TODO Auto-generated method stub
		mymu = new double[nPeriods];
		mylambda = new double[nTypes][nPeriods];
		for(int t=0; t < nPeriods; t++){
			mymu[t] = mu[mIdx][t];
			for(int m=0; m < nTypes; m++){
				mylambda[m][t] = lambda[mIdx][m][t]; 
			}
		}			
	}
}
