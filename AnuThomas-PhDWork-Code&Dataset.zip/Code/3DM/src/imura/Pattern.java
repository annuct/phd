package imura;


import ilog.concert.IloException;
import ilog.concert.IloIntVar;
import ilog.concert.IloNumExpr;
import ilog.cplex.IloCplex;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

public class Pattern {

	Sequence[] Seq;
	private Data intData;	

	private int[] bestPat;
	private int[] newPattern;
	double bestCost; 

	// private List<String>  = new ArrayList<String>();	
	private HashSet <String> visitedNodes = new HashSet <String>();

	public Pattern(Data data) {
		super();
		Seq = new Sequence[data.nMines];
		for(int j=0; j< Seq.length; j++)
			Seq[j] = new Sequence();

		for(int i=0; i< data.nMines; i++)
			Seq[i].makePatternList(data, i);

		intData = data;
		bestCost = 3e12;
	}



	public String makeString(int[] arr){
		String str="";
		for(int k=0; k< arr.length; k++){
			if(k>0 )  str +="-";
			str += arr[k];
		}
		return str;
	}
	public boolean checkPresence(int[] arr){			
		return visitedNodes.contains(makeString(arr));
	}

	public void addToVistedList(int[] arr){
		visitedNodes.add(makeString(arr));
	}
	public void dispVistedList(){
		String str="Visted Nodes";
		Iterator itr = visitedNodes.iterator(); 
		while (itr.hasNext()){
			str +="\n i: "+  itr.next();  
		}
		System.out.println(str);
	}

	private class Sequence{		

		private List<String> patList = new ArrayList<String>();

		//	private Set patList = new HashSet();

		private void makePatternList(Data data, int mIdx){


			int N = data.nTypes;
			int[] cap = new int[N];		

			double Dem = data.mine[mIdx].Demand[data.nPeriods-1];

			int[] maxN = new int[N];
			for(int k=0; k< N; k++){
				cap[k] = (int) data.TrClass[k].vol;
				maxN[k] = (int)Math.ceil(Dem/cap[k]);
			}	

			int[][] AllChoices = generateAllChoices(maxN);

			for(int i=0; i< AllChoices.length; i++){
				int[] arr = new int[N];
				double sum =0;
				boolean badCh = false;
				for(int u=1; u< N; u++){
					sum += AllChoices[i][u-1]*cap[u-1] ;
					if ( Math.ceil((Dem-sum)/cap[u]) < AllChoices[i][u]){
						badCh = true; break;
					}
					if(badCh) break;
				}
				sum += AllChoices[i][N-1]*cap[N-1] ;
				if(badCh || (sum < Dem)) continue;

				double totalSupply =0;
				for(int k=0; k< N; k++){
					arr[k] = AllChoices[i][k];
					totalSupply += arr[k]*cap[k];
				}

				/*				for(int k1=0; k1 < N; k1++ )
					if(arr[k1] > 0 && totalSupply - cap[k1] >= Dem)
						System.out.println(" Extra train in "+ makeString(arr));
				 */

				patList.add(makeString(arr));
			}

			/*		for(int j=0; j< outList.size(); j++){
			int[] tmp =  outList.get(j);
			System.out.print("\n");
			for(int k=0; k< N; k++)
				System.out.print("\t "+tmp[k]);
		}*/
			//	System.out.println("Array Length "+patList.size());

		}



	}


	//----------------------------------------------------------

	double solveWithPattern(IloCplex cplex){

		Data data = intData;
		MyUtils Utils = new MyUtils(data.conf.filePrefix);	

		double out = -100;
		int nMines = data.nMines;

		int[] itr = getRndPattern();

		String str  = "Pattren : " + makeString(itr);


		CentModel CM = new  CentModel(data);
		out = CM.solve(cplex, this, itr, 0.00, 1800);

		if (out > 0) 
			str += " \t Obj: " + out;
		else
			str += " \t Infeasible";

		System.out.println(str);
		Utils.printf(str, "summary.txt");
		return out;
	}
	//----------------------------------------------------------
	int[] nbdSearch(int degree){
		return nbdSearch(bestPat, degree);
	}
	//----------------------------------------------------------
	int[] nbdSearch(int[] arr, int degree){		
		// System.out.println(" BP " + makeString(bestPat));
		int[] outPat = new int[arr.length];
		for(int i=0; i< outPat.length; i++)
			outPat[i] = arr[i];

		boolean[] picked = new boolean[intData.nMines];		
		Random R = new Random();
		do{
			int count =0;
			for(int m=0; m < picked.length; m++)
				picked[m] = false;
			do{
				int rdMidx  =  R.nextInt(intData.nMines); // random mine index
				if(picked[rdMidx]) continue;
				outPat[rdMidx] = R.nextInt(Seq[rdMidx].patList.size());
				picked[rdMidx] = true;
				count++;
			}while(count < degree);

		}while(!validate(arr));

		return outPat;
	}


	public void setNewPattern(int [] arr){
		newPattern = new int[arr.length];
		for(int i=0; i < arr.length; i++)
			newPattern[i] = arr[i];
	}

	public int[] getNewpattern(){
		int[]  tmp = new int[newPattern.length];
		for(int i=0; i < newPattern.length; i++)
			tmp[i] = newPattern[i];		
		return tmp;
	}
	//----------------------------------------------------------

	int[]  getRandomPattern(){
		int[] patSeq = new int[intData.nMines];
		Random ranD = new Random();  
		//	ranD.setSeed(1508111446);

		for(int i=0; i < intData.nMines; i++)
			patSeq[i] = (int) Math.round(-0.5+ ranD.nextInt(Seq[i].patList.size())) ;

		return patSeq;
	}

	//----------------------------------------------------------

	int[]  getRndPattern(){
		/*		int[] patSeq = new int[intData.nMines];
		Random ranD = new Random();  
		ranD.setSeed(1508111446);

		for(int i=0; i < intData.nMines; i++)
			patSeq[i] = (int) Math.round(-0.5+ ranD.nextInt(Seq[i].patList.size())) ;
		 */

		//		int[] itr = new int[nMines];

		//int[]  itr = {8,0,8,8,8,8,1};

		//	int[]  itr = {0,0,0,0,0,0,0};

		int[]  itr =
		//		 {5, 7, 2, 7, 10, 5, 6}; //optimal 
		{11, 21, 7, 4, 11};// optimal for c4
			//	 	{1,	0,	0,	0,	5,	12,	12}; //p2
			//	 	{4,0,8,9,8,11,1}; //p3					 
			//	 	{4,1,12,9,8,11,10}; //p4					 
			//			{5,6,9,7,11,5,5}; //p5
			//  	{11,7,10,9,4,15,6}; //p6
			//	  	{13,22, 3, 17,	1, 9, 1}; //p7
	 	// {10, 24, 4, 14, 3, 12, 0};  // p8
		// { 3, 22, 10, 10, 21, 0, 3}; //p9
		//	{ 5, 7, 2, 7, 10, 5, 7}; // p10
		// { 18, 6, 6, 15, 10, 2, 3}; //p11
		//	{5, 7, 10, 7, 7, 5,7}; // in'tial best 
		//	{ 17, 22, 43, 4, 14, 26, 40}; // for data set A1
		//	{23,66,111,5,24,65,26};
		//		patSeq = new int[]{5,6,9,7,11,5,5};

		//	{ 94, 141, 14, 62, 28, 94, 25}; // data set A2, first one
		//	{ 137, 0, 63, 104, 81, 89, 53}; // A7
		// {152, 8, 64, 70, 136, 58, 68}; // A7 takes 600 sec for xt= tp model
		//	{118, 8, 64, 70, 81, 89, 68};// A7
		//	 {23, 120, 15, 14, 43, 124, 8, 56, 14, 44};
		//	{64,14,7,41, 42,1,4};
		return itr;
	}
	//----------------------------------------------------------

	public double solveWithRndPattern(IloCplex cplex, double currUB){
		return solveWithRndPattern(cplex, currUB, 0);
	}
	//----------------------------------------------------------
	public double solveWithRndPattern(IloCplex cplex, double currUB, int time){	
		int[] patSeq;
		double out = -100;
		int nAttempts=0;		

		while(nAttempts <50 ){
			nAttempts++;
			patSeq = getRndPattern();

			CentModel CM = new CentModel(intData);
			out= CM.solve(cplex, this, patSeq, 0.02, time);// 10% rel gap			

			if (out >= 0) 
				break;
		}		
		return out;
	}

	public void  getInitialPattern(IloCplex cp) throws IloException{

		Data TD = intData;
		CentModel CM = new CentModel(TD);
		CM.relax = true;		
		CM.solve(cp);
		int[][] pat =  new int[TD.nMines][TD.nTypes];
		int[] ReducedDem = new int[TD.nMines];
		int[] patSeq = new int[intData.nMines];

		for(int i=0; i< pat.length; i++){
			ReducedDem[i] = TD.mine[i].Demand[TD.nPeriods-1];
			for(int m=0; m< pat[i].length; m++){
				pat[i][m] = (int)(TD.mine[i].relaxedSol[m]*1.1); // floor , 10% grace
				ReducedDem[i] -= pat[i][m]*TD.TrClass[m].vol;
			}
		}


		cp.clearModel();
		for(int i=0; i < intData.nMines; i++){
			cp.clearModel();
			IloIntVar[] coeff = cp.intVarArray(intData.nTypes+1, 0, Integer.MAX_VALUE) ;
			IloNumExpr  tmp = cp.numExpr();
			for(int m=0; m< intData.nTypes; m++)
				tmp = cp.sum(tmp, cp.prod(coeff[m], intData.TrClass[m].vol));
			tmp = cp.diff(tmp, coeff[intData.nTypes]);

			cp.addEq(tmp, ReducedDem[i]);
			cp.addMinimize(coeff[intData.nTypes]);
			cp.output();		
			cp.solve();


			//	System.out.println(" Solutions "+i);
			for(int m=0; m< intData.nTypes; m++){
				pat[i][m] = (int)Math.round(pat[i][m]+cp.getValue(coeff[m]));
				//	 System.out.print("\t " +pat[i][m] );
			}

			String str = makeString(pat[i]);
			for(int j=0; j< Seq[i].patList.size(); j++ ){
				if(Seq[i].patList.get(j).equals(str)){
					patSeq[i] = j;				
					break;
				}
			}		
			//	System.out.println("BP : " + makeString(bestPat));

			TD.mine[i].relax = false;
		}

		setBestpattern(patSeq);	

		CM.relax = false;
		CM.mstFlag = true;
		//	bestCost = CM.scaling*CM.solve(cp, this, bestPat, 0.05, 50*intData.nMines);
		//	System.out.println("Best Cost " + bestCost);

	}

	public boolean validate(int[] idxArr){

		Data data = intData;
		//Pattern Validation	

		int[] noTrains = new int[data.nTypes];
		for(int k=0; k< data.nTypes; k++)
			noTrains[k]=0;

		String pat_str = "\nPattern: [ ";
		for(int i=0; i < data.nMines; i++){
			int[] tmpArr = makeIntArray(Seq[i].patList.get(idxArr[i]));


			pat_str += idxArr[i]+", ";
			for(int k=0; k< data.nTypes; k++)
				noTrains[k] += tmpArr[k]; 
		}
		pat_str += "]\n";
		//	System.out.print(pat_str);

		boolean good = true;
		for(int k=0; k< data.nTypes; k++){
			if (noTrains[k]  >= ((float) data.nPeriods*data.TrClass[k].number/data.TrClass[k].Ltime)){ /////// ANU-Oct10
				//inFeas ++; //per train load
				good = false;
				break;
			}
		}
		return good;
	}


	public void addConstraints(IloCplex cp, int[] idxArray) throws IloException{

		Data data  = intData;
		int endTime = data.nPeriods-1;
		int[] totalTrips = new int[data.nTypes];
		for(int m=0; m< totalTrips.length; m++)
			totalTrips[m]=0;

		//Adding equality constraints at time T
		for(int i=0;i< Seq.length; i++){
			int[] trArray = makeIntArray(Seq[i].patList.get(idxArray[i])); 
			double totalsupply=0;
			for(int m=0; m < trArray.length; m++){				
				cp.addEq(data.mine[i].MV.AQty[m][endTime], trArray[m] );
				totalTrips[m] +=   trArray[m];
				totalsupply+= trArray[m]*data.TrClass[m].vol;
			}
			cp.addEq(data.mine[i].MV.OS[endTime], totalsupply-data.mine[i].Demand[endTime]);
		}

		//Adding LB for number of trains
		for(int m=0; m < data.nTypes; m++){
			int maxN = Math.min(endTime/data.TrClass[m].Ltime, // ANU-Oct10 
					totalTrips[m]/data.TrClass[m].number);
			for(int n=1; n <= maxN; n++){
				IloNumExpr tmp = cp.numExpr();
				int nTime = endTime - n*data.TrClass[m].Ltime-data.TrClass[m].Ltime; //// ANU-Oct10	
				int nTr = totalTrips[m] - n*data.TrClass[m].number;
				for(int i=0;i< data.nMines; i++){
					int[] TrArray = makeIntArray(Seq[i].patList.get(idxArray[i]));
					tmp = cp.sum(tmp, data.mine[i].MV.AQty[m][nTime]);
					if ( TrArray[m] - n*data.TrClass[m].number > 0)
						cp.addGe(data.mine[i].MV.AQty[m][nTime], TrArray[m] - 
								n*data.TrClass[m].number).setName("PatConstr_"+i+"_"+m);
				}
				if (nTr > 0 && nTime >0) cp.addGe(tmp, nTr).setName("PatConstr_"+m);
			}
		}


		//Additional constraints on demurrage
		for(int i=0;i< data.nMines; i++){
			int[] TrArray = makeIntArray(Seq[i].patList.get(idxArray[i]));
			double totSup=0;
			int min_e_tau = endTime;
			for(int m=0; m< TrArray.length; m++){
				totSup += TrArray[m]*data.TrClass[m].vol;
				min_e_tau = Math.min(min_e_tau, data.TrClass[m].Ltime);/////ANU-Oct10
			}


			int n=1;
			while(true){
				double cumS=0;
				int tt = 0;											
				for(int m=0; m < data.nTypes; m++)					
					if( (TrArray[m] -n*data.TrClass[m].number) >0){
						cumS += (TrArray[m] -n*data.TrClass[m].number)*data.TrClass[m].vol;							
						tt = Math.max(endTime - n*data.TrClass[m].Ltime, tt); /////ANU-Oct10
					}
				if (cumS ==0) break;
				int ordlen = data.mine[i].Order.length;
				for(int k= 0; k < ordlen; k++){			
					if (cumS > data.mine[i].Order[k] && tt > data.mine[i].dueDate[k])
						if(k < ordlen-1 && tt < data.mine[i].dueDate[k+1])
							cp.addEq(data.mine[i].MV.Y[tt], 0).setName("NoDem");
						else if(k== ordlen-1)
							cp.addEq(data.mine[i].MV.Y[tt], 0).setName("NoDem");
				}
				n++; 
			}

			for(int t=1; t<= endTime; t++){
				IloNumExpr tmpSum = cp.numExpr();
				for(int m=0; m< data.nTypes; m++)					
					tmpSum = cp.sum(tmpSum, cp.prod(data.TrClass[m].vol, data.mine[i].MV.AQty[m][t]));

				tmpSum = cp.sum(tmpSum,  data.mine[i].MV.Inv[t]);

				double cumSLB = totSup - (endTime - min_e_tau -t)*data.mine[i].prodCap;
				if (cumSLB>0 && t <= endTime - min_e_tau)
					cp.addLe(cumSLB, tmpSum).setName("MinSupply_"+i+"_"+t);
			}

			/*			int[][] Choices = generateAllChoices(TrArray);
			for(int u=0; u < Choices.length-1; u++){
				double totS =0;
				for(int m=0; m< data.nTypes; m++)
					totS +=  Choices[u][m]*data.TrClass[m].vol;
				if (totS >= data.mine[i].Demand[data.nPeriods-1]){
					for(int m=0; m <  data.nTypes-1; m++){											
						if (TrArray[m]==Choices[u][m])
							continue;

						for(int t=1; t< data.nPeriods; t++){
							IloNumExpr tmpSum = cp.numExpr();
							for(int m1= m+1; m1< data.nTypes; m1++)
								tmpSum = cp.sum(tmpSum, cp.diff(TrArray[m1],data.mine[i].MV.AQty[m1][t]));


							cp.addLe(cp.diff(TrArray[m],data.mine[i].MV.AQty[m][t]),cp.prod(TrArray[m],tmpSum));
							cp.addLe(cp.diff(data.mine[i].MV.AQty[m][t],data.mine[i].MV.AQty[m][t-1]),tmpSum);
						}
						break;
					}
				}
			}*/
		} 
	}



	public int[][] generateAllChoices(int[] UB){

		int max=1;
		int[]  n =  new int[UB.length];
		for(int i=0; i< UB.length; i++){
			max *=  (UB[i]+1);
			n[i] =0;
		}

		int[][] AllChoices =  new int[max][UB.length];
		int cnt =0;
		while(true){
			for(int k=0; k< UB.length; k++)
				AllChoices[cnt][k] = n[k];

			boolean flag = true;
			for(int u=0; u< UB.length; u++)
				if (n[u]!= UB[u]){
					flag = false;
					break;
				}
			if (flag)   break;

			cnt++; 
			n[UB.length-1]++;		

			if(n[UB.length-1]> UB[UB.length-1]){
				for(int u= UB.length-1; u > 0; u--)
					if (n[u] > UB[u]){
						n[u]=0;
						n[u-1]++;
					}
			}
		}
		return AllChoices;

	}

	public void setBestpattern(int[] arr){
		bestPat = new int[arr.length];
		for(int i=0; i< arr.length; i++)
			bestPat[i] = arr[i];

	}

	public int[] getBestpattern(){
		int[] arr = new int[bestPat.length];

		for(int i=0; i< bestPat.length; i++)
			arr[i] =bestPat[i] ;
		return arr;
	}

	public int [] getIntPattern(int i, int[] arr) {
		// TODO Auto-generated method stub
		return makeIntArray(this.Seq[i].patList.get(arr[i]));
	}

	public String getStringPattern(int i, int[] arr) {
		// TODO Auto-generated method stub
		return this.Seq[i].patList.get(arr[i]);
	}

	private int[] makeIntArray(String str){
		String[] strArr  = str.split("-");		
		int[] outArr = new int[strArr.length];		
		for(int i=0; i < outArr.length; i++)
			outArr[i] = Integer.valueOf(strArr[i]);

		return outArr;
	}



	public List<String> getList(int i) {
		// TODO Auto-generated method stub
		return Seq[i].patList;
	}



	public void clearVisitedNodes() {
		// TODO Auto-generated method stub
		visitedNodes.clear();
	}

	/*void comparePatternNresult(int[] idxArray, IloCplex cp) throws IloException{

		Data data = intData;
		boolean rmFlag =  false;
		for(int mIdx =0; mIdx < data.nMines; mIdx++){
			int[] TrArray = Seq[mIdx].patList.get(idxArray[mIdx]);
			for(int k=0; k < data.nTypes; k++){
				int NTrs = (int)Math.round(cp.getValue(data.mine[mIdx].MV.AQty[k][data.nPeriods-1]));
				if (NTrs != TrArray[k]){
					System.out.println("AQ["+mIdx+", "+k+"] : "+TrArray[k]+" --> " + NTrs);
					rmFlag = true;
				}
			}
				if (rmFlag) searchAndRemove(mIdx, idxArray[mIdx]);		
		}
	}*/



	/*	public void setPattern(int[][] IN){
		for(int i=0; i< IN.length; i++)
			for(int j=0; j< IN[i].length; j++)
				bestPattern[i][j] = IN[i][j];
	}

	public int[][] getPattern(){
		return bestPattern;
	}*/


}
