package imura;

import ilog.concert.*;
import ilog.cplex.*;
import ilog.cplex.IloCplex.UnknownObjectException;


import imura.Data.Train;

public class CentModel {

	Data intData;
	boolean relax = false;
	boolean writeMST = false;

	boolean mstFlag = false;
	//	IloNumVar[] nUsedTrains;

	IloNumVar[][] Yship; 
	IloNumVar RailObj;
	IloNumVar TermObj;

	public CentModel(Data d){
		intData = d;
	}
	double solve(IloCplex cplex) {
		return solve(cplex, 0, 0);
	}

	public double solve(IloCplex cplex,double gap, int time) {	
		return solve(cplex, null, null, gap, time);
	}
	public double solve(IloCplex cplex, double gap, int time, double currUB) {	
		return solve(cplex, null, null, gap, time, currUB);
	}
	public double solve(IloCplex cplex, Pattern P, int[] Pat, double gap, int time){
		return solve(cplex, P, Pat, gap, time, 0);
	}
	//====================================================================
	public double solve(IloCplex cplex, Pattern P, int[] Pat, double gap, int time, double currUB) {		

		Data data = intData;
		int nMines 		= data.nMines;
		Mine[]  mine 	= data.mine;	
		int nTypes      = data.nTypes;
		String fname = "cent_best.mst";

		int CentModelLB=0;
		MyUtils Utils = new MyUtils(data.conf.filePrefix);

		// VARIABLE INITIALIZATION
		try {
			Utils.resetCplexParameters(cplex);
			IloNumVar newObj = createBasicModel(cplex, data, CentModelLB);

			if (!Utils.solveAndRecord(cplex, "center", gap, time)){
				Utils.printf("Could not solve ");
				System.out.printf("Could not solve CM: 159 ");
				return -100;
			}

			if(mstFlag){
				if (cplex.getSolnPoolNsolns() > 1) {
					cplex.writeMIPStart(fname);
					System.out.println("MST is ready!");
				}
				else
					return -144;// no need to call CM again without finding another starting point
			}

			//	cplex.writeMIPStart("cm_solution.mst");

			double ObjValue = print_CM_output_summary(cplex, data, Utils);

			//	for(int m=0;  m < nTypes; m++)
			//		System.out.println("Cost of fixed of"+ cplex.getValue(nUsedTrains[m]));

			for(int i=0; i<nMines; i++){
				mine[i].msgflag = !relax;
				mine[i].writeOutputs(cplex, data);		
			}

			return ObjValue;			
		}catch(Exception e){
			e.printStackTrace();
			return -100;
		}
	}
	private double print_CM_output_summary(IloCplex cplex, Data data,
			MyUtils Utils) throws UnknownObjectException, IloException {
		
		double ObjValue =  cplex.getObjValue();
		Utils.printf("Obj " + ObjValue);
		for(int s=0;  s< data.nShips; s++){
			double[] YS =cplex.getValues(Yship[s]); 
			String mystr="ShipOrder-"+s+" Tardy at t= ";
			for(int t= data.ShipOrdDue[s]; t < data.nPeriods; t++){
				if(YS[t]==1)
					mystr += (t + "  ");
			}
			Utils.printf(mystr);	
		}
		
		Utils.printf("Rail Obj = " + cplex.getValue(RailObj));
		Utils.printf("Term Obj = " + cplex.getValue(TermObj));
		return ObjValue;
	}
	public IloNumVar createBasicModel(IloCplex cplex, Data data,  int CentModelLB)	throws IloException {

		cplex.clearModel();	
		//LOOPING OVER ALL MINES and adding constraints
		Train[] TrClass = data.TrClass ;
		//	nUsedTrains = cplex.numVarArray(TrClass.length, 0, 100);
		Mine[] mine = data.mine;
		IloNumExpr  objtmp = cplex.numExpr();
		RailObj = cplex.numVar(Integer.MIN_VALUE, Integer.MAX_VALUE);
		TermObj = cplex.numVar(Integer.MIN_VALUE, Integer.MAX_VALUE);
		
		for(int t=0; t < data.nPeriods; t++){
			int dSum =0; 
			int sOdSum =0; 
			for(int i=0; i < data.nMines; i++)
				dSum += data.mine[i].Demand[t];
			for(int k=0; k < data.nShips; k++){
				if (data.ShipOrdDue[k] <= t)
					sOdSum += data.ShipOrdQty[k];
				if (data.ShipOrdDue[k] == t && dSum != sOdSum)				
					System.err.println("ERROR-DEMAND: Please check "+ t+"   "+ dSum +"   "+sOdSum);
			}
			//	System.err.println( t+"   "+ dSum +"   "+sOdSum);
		}



		for(int i=0; i < data.nMines; i++){
			mine[i].addConstraints(data, cplex);
			objtmp = cplex.sum(objtmp, mine[i].MV.ObjVar);
		}
		
		// LINKING: rail operators constraint
		IloNumExpr  tmpRailObj =  cplex.constant(0);
		for(int m=0; m < data.nTypes; m++){
			for(int t=1; t< data.nPeriods; t++){
				IloNumExpr  tmpSum =  cplex.constant(0);
				IloNumExpr  numTrs =  cplex.constant(0);

				for (int i=0; i < data.nMines; i++){											
					// for each mine, class and time 
					int tEnd = Math.min(data.nPeriods-1, t+TrClass[m].time[0]);
					int tStart = Math.max(0, t-TrClass[m].Ltime-TrClass[m].time[4]);	
					tmpSum = cplex.sum(tmpSum, cplex.diff(mine[i].MV.AQty[m][tEnd], mine[i].MV.AQty[m][tStart]));
					numTrs  = cplex.sum(numTrs, mine[i].MV.AQty[m][t]);
				}	
				//	cplex.addLe(tmpSum, nUsedTrains[m]).setName("LinkingConst_"+m+"_"+t);
				cplex.addLe(tmpSum, TrClass[m].number).setName("LinkingC_"+m+"_"+t);
				// Adding rail operator objective : Running cost
				tmpRailObj = cplex.sum(tmpRailObj, cplex.prod(tmpSum, TrClass[m].runningcost));		
				//	cplex.addLe(numTrs, (int)((float)t+TrClass[m].e_tau)/TrClass[m].g_tau*TrClass[m].number);
			}
		}
		objtmp = cplex.sum(cplex.prod(tmpRailObj, data.conf.RailObjScaling),objtmp);
		cplex.addEq(RailObj, tmpRailObj).setName("RailObjective");

		Yship 		= new IloIntVar[data.nShips][];
		for(int s =0; s < data.nShips; s++){
			Yship[s] = cplex.intVarArray(data.nPeriods, 0, 1); //Demurrage
			for(int t=0; t< data.nPeriods; t++){
				Yship[s][t].setName("Yship_"+s+"_"+t);
				if (t>=data.ShipOrdDue[s] )
					cplex.addLe(Yship[s][t], Yship[s][t-1]);
				else
					cplex.addEq(Yship[s][t],1);		

				if (s>0 && t==data.ShipOrdDue[s])
					cplex.addLe(Yship[s-1][t], Yship[s][t]);					
			}
			cplex.addEq(Yship[s][data.nPeriods-1],0);
		}

		IloNumExpr  tmpTermObj =  cplex.constant(0);
		for(int t=1; t< data.nPeriods; t++){
			IloNumExpr  CumDel =  cplex.constant(0);
			IloNumExpr  CumOrd =  cplex.constant(0);
			for (int i=0; i < data.nMines; i++){
				for(int m=0; m < data.nTypes; m++){
					int tStart = Math.max(0, t-TrClass[m].Ltime);
					CumDel = cplex.sum(CumDel, cplex.prod(mine[i].MV.AQty[m][tStart],TrClass[m].vol));
				}
			}

			for(int s =0; s < data.nShips; s++){
				if (t<= data.ShipOrdDue[s])
					CumOrd = cplex.sum(CumOrd, cplex.prod( cplex.diff(1, Yship[s][t]), data.ShipOrdQty[s]));

				if(t>=data.ShipOrdDue[s])
					tmpTermObj = cplex.sum(tmpTermObj, cplex.prod(Yship[s][t],data.ShipOrdQty[s]*data.conf.ShipDemurrage));
			}
			cplex.addGe(CumDel, CumOrd).setName("ShipOrderTardy_"+t);
		}

		objtmp = cplex.sum(tmpTermObj,objtmp);
		cplex.addEq(TermObj, tmpTermObj).setName("TerminalObjective");
		
		//Unloading restriction --> Terminal 
		for(int m=0; m < data.nTypes; m++){
			for(int t=1; t< data.nPeriods; t++){
				IloNumExpr  tmpSum =  cplex.constant(0);			
				for (int i=0; i < data.nMines; i++){											
					// for each mine, class and time 
					int tEnd = Math.max(0, t-TrClass[m].time[1]-TrClass[m].time[2]);
					int tStart = Math.max(0, t-TrClass[m].Ltime);	
					tmpSum = cplex.sum(tmpSum, cplex.diff(mine[i].MV.AQty[m][tEnd], mine[i].MV.AQty[m][tStart]));		
				}	
				cplex.addLe(tmpSum, data.TermUnloadCap).setName("UnloadingLimit_"+m+"_"+t);
			}
		}


		cplex.addMinimize(objtmp);
		return null;
	}


}
