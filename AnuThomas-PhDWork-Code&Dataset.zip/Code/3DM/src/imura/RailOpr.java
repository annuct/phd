package imura;

import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloNumVar;
import ilog.cplex.IloCplex;
import imura.Mine.MineSol;

public class RailOpr {

	int Tmax;
	int nJobs;
	int nTrains;
	int[][] TrAvailability;
	double RO_INF = 1e20;

	// boolean ch= 1; 
	boolean newRailObj=false;

	Job[]  Jobs;
	int[][] JobSched;
	int[] colArray;
	double ObjVal;
	int objScaling = 100;
	boolean columnFlag = true;
	boolean privateProdInfo = false;
	String summary_str="";

	public RailOpr(boolean privateProdInfo) {
		super();
		this.privateProdInfo = privateProdInfo;
	}

	public RailOpr() {
		super();
		this.privateProdInfo = false;
	}

	public class Job { //Mine class
		int rDate; //holding cost at mine
		int reachTime; // the time in which it is requested from the mines
		int dDate;
		int st_time;
		//	int jTime; // journey time
		//	int endtime;
		int [] time;
		int cDate;// actual completion date 
		int mIdx;// associated mine
		int tIdx;// associated train class	
		//	int eTau;
		int wgt;
		int idx;
		double vol;
	}



	//================================================================================================================================
	public void makeJobs(Data data){


		MineSol[] MS = new MineSol[data.nMines];
		int jCnt=0; // job counter		
		// int totalDemand=0;
		for (int i=0; i < data.nMines; i++)		{
			MS[i] = data.mine[i].getSolution(-1);
			for (int t =0; t < data.nPeriods; t++)
				for(int k=0; k < data.nTypes; k++ )
					if (MS[i].TrRequest[k][t]==1)// all are boolean values
						jCnt++ ; 		
			// 		totalDemand += M[i].Order[M[i].Order.length-1];		
		}		

		Jobs =  new Job[jCnt];
		nJobs = jCnt;

		for(int j=0; j < Jobs.length; j++)
			Jobs[j]=  new Job();	


		jCnt=0;
		for (int t =0; t < data.nPeriods; t++)
			for (int i=0; i < data.nMines; i++)	{	

				for(int k=0; k < data.nTypes; k++ )
					if (MS[i].TrRequest[k][t]==1) {
						Jobs[jCnt].reachTime = t;
						Jobs[jCnt].mIdx = i;
						Jobs[jCnt].tIdx = k;
						Jobs[jCnt].rDate =  Math.max(1,t-data.TrClass[k].time[0]); // no jobs before t=1
						Jobs[jCnt].time = new int[5];
						for(int u=0; u < 5; u++)
							Jobs[jCnt].time[u] = data.TrClass[k].time[u];
						Jobs[jCnt].st_time = Jobs[jCnt].time[0]+Jobs[jCnt].time[1]+Jobs[jCnt].time[2]+Jobs[jCnt].time[3];								
						Jobs[jCnt].dDate = Jobs[jCnt].rDate + 	Jobs[jCnt].st_time;				
						Jobs[jCnt].wgt = 1;
						Jobs[jCnt].idx = jCnt;
						Jobs[jCnt].vol = data.TrClass[k].vol;						
						jCnt++;
					}	
			}
		System.out.println("Number of jobs = "+jCnt);
	}

	public double solveRailProb(IloCplex cplex, Data data) {
		return solveRailProb( cplex,  data, 0);
	}

	//======================================================================================

	public double solveRailProb(IloCplex cplex, Data data, int itr) {

		Tmax			= data.nPeriods;// getTmax(data);	
		MyUtils Utils = new MyUtils(data.conf.filePrefix);
		double out = RO_INF;
		if (nJobs==0) return out;
		//	if(data.conf.Model_Choice==45)
		//		decentralised = true;
		try {
			cplex.clearModel();
			IloNumVar[][] Z 	= new IloNumVar[nJobs][];
			//		IloNumVar[][] Span 	= new IloNumVar[data.nTypes][2];			
			IloNumVar[] nUsedTrains = cplex.numVarArray(data.TrClass.length, 0, 100);

			for (int j = 0; j < nJobs; j++) 
				Z[j]   = cplex.boolVarArray(Tmax);

			/*	if(newRailObj)
				for(int k=0; k < data.nTypes; k++){
					Span[k] = cplex.numVarArray(2, 0, Tmax);
					Span[k][0].setName("Span_"+k+"_min");
					Span[k][1].setName("Span_"+k+"_max");
				}
			 */
			// Pre-computed weighted tardiness coefficient
			double [][] tar_cost =  new double[nJobs][Tmax];		
			//	double [][] ear_cost =  new double[nJobs][Tmax];
			for (int j=0; j< nJobs; j++ ){
				for(int t=0; t< Tmax; t++){
					Z[j][t].setName("z_"+j+"_"+t);
					tar_cost[j][t] = 100*Jobs[j].wgt*Math.max(0, t- Jobs[j].dDate); 
					//			ear_cost[j][t] = 2*Jobs[j].wgt*Math.max(0, Jobs[j].dDate-t);
				}
				if(!privateProdInfo) //This is only to get a feasible solution				
					Jobs[j].rDate = Math.max(0, (int)Jobs[j].vol/data.mine[Jobs[j].mIdx].prodCap-Jobs[j].time[2]);
			}

			for (int j = 0; j < nJobs; j++)				
				cplex.addEq(Z[j][Tmax-1], 1);			// All jobs must be completed 
			//		cplex.addEq(Z[j][rTime[j]+data.Tmax/3],1);// maximum delay is Tmax/3

			IloNumExpr  objtmp = cplex.numExpr();
			for(int m=0; m < data.nTypes; m++){
				nUsedTrains[m].setName("nUsedTrains_"+m);
				cplex.addLe(nUsedTrains[m], 5*data.TrClass[m].number).setName("ResUtil_"+m);
				// objtmp = cplex.sum(objtmp, cplex.prod(nUsedTrains[m], data.TrClass[m].fixedcost));	
			}
			addConstraints_R2_R3_R5_R6(cplex, data, Z, nUsedTrains);


			//	IloNumExpr  mkSpan = cplex.numExpr();
			for (int j = 0; j < nJobs; j++){
				for (int t = 1; t < Tmax; t++){
					double tmp_cost = tar_cost[j][t];
					//				if(!privateProdInfo)
					//					tmp_cost += ear_cost[j][t];
					objtmp = cplex.sum(objtmp, cplex.prod(tmp_cost, cplex.diff(Z[j][t], Z[j][t-1])));					
				}
				//	cplex.addEq(Z[j][Jobs[j].dDate],1).setName("SettingJobs"); //only for the validation
			}

			for (int k=0; k < data.nTypes; k++){
				for (int t = 0; t < Tmax; t++) {				
					for (int j = 0; j < nJobs; j++) {
						int t1 = Math.min(Tmax-1, t+Jobs[j].time[0]+Jobs[j].time[1]+Jobs[j].time[2]+Jobs[j].time[3]);
						if ((Jobs[j].tIdx==k) &&  t>= Jobs[j].time[4] ){
							IloNumExpr runlen = cplex.diff(Z[j][t1], Z[j][t-Jobs[j].time[4]]);
							objtmp = cplex.sum(objtmp, cplex.prod(runlen, data.TrClass[k].runningcost ));
							// New term in the objective
						}
					}
				}
			}


			for(int i=0; i< data.nMines; i++){		
				for(int k =1; k <  data.mine[i].Order.length; k++){
					int time = data.mine[i].dueDate[k];
					IloNumExpr cumDelivery = cplex.numExpr();
					for(Job j : getJobsOfMine(i))
						cumDelivery = cplex.sum(cumDelivery, cplex.prod(Z[j.idx][time], j.vol));
					cplex.addGe(cumDelivery,  data.mine[i].Order[k-1]).setName("Order_"+(k-1)+"_should_be_met_before_"+time);
				}

				if(!privateProdInfo){ // should have sufficient production
					for(int t= 0; t< Tmax; t++ ){
						IloNumExpr cumSupply = cplex.numExpr();
						for(Job j : getJobsOfMine(i))					
							cumSupply = cplex.sum(cumSupply, cplex.prod(Z[j.idx][Math.min(Tmax-1,t+j.time[1]+j.time[2]+j.time[3])], j.vol));
						cplex.addLe(cumSupply, t*data.mine[i].prodCap).setName("ProdCap_"+i+"_"+t); 
					}
				}
			}



			cplex.addMinimize(objtmp); 
			cplex.exportModel("rail_sol.lp");
			if(!Utils.solveAndRecord(cplex,  "Rail"))
				return out;

			ObjVal = cplex.getObjValue();
			Utils.printf("Rail Obj " + ObjVal);
			summary_str = "DMOUT:: "+nJobs+","+ObjVal ;
			JobSched=  new int[nJobs][Tmax];

			for(int j=0; j < nJobs; j++)
				for(int t=0; t < Tmax; t++)
					JobSched[j][t] =  Math.round( (float) cplex.getValue(Z[j][t]));

			readAllSolutions(cplex, data, Z, false);
			out = logMineSolutions(data, Utils, itr, !columnFlag);
			summary_str += " = " +out;
			Utils.printf(summary_str);			
		}
		catch (IloException exc) {
			System.err.println("Concert exception '" + exc + "' caught");			
		}
		return out;
	}

	//=================================================================================================
	private void addConstraints_R2_R3_R5_R6(IloCplex cplex, Data data, IloNumVar[][] Z, IloNumVar[] nUsedTrains) throws IloException {


		for(int j=0;  j < Jobs.length; j++){
			for (int t = 1; t < Tmax; t++) {
				if (t < (Jobs[j].rDate+Jobs[j].time[0]+Jobs[j].time[1]+Jobs[j].time[2]+Jobs[j].time[3]))
					//R2
					cplex.addEq(Z[j][t], 0).setName("Rel_date_"+j+"_"+t);			// release date constraint
				else //R3
					cplex.addGe(Z[j][t], Z[j][t-1]);		// Once done, stays there
			}
			cplex.addEq(Z[j][0], 0);			// All jobs must be zero at t=0
		}


		//R5
		for (int i=0; i < data.nMines; i++)
			for (int t = 1; t < Tmax; t++) {
				IloNumExpr  tmp = cplex.numExpr();					
				for (int j = 0; j < nJobs; j++) {
					// check whether it is loading R3
					int t1 = t+Jobs[j].time[3]+Jobs[j].time[2]+Jobs[j].time[1];
					int t2 = t+Jobs[j].time[2]+Jobs[j].time[3]; 
					if ((Jobs[j].mIdx == i) && ( t1 < Tmax) )
						tmp = cplex.sum(tmp, cplex.diff(Z[j][t1], Z[j][t2]));						
				}
				//Not more than one job on any mine for loading: R3
				if(!isNumExprEmpty(tmp, cplex)) 
					cplex.addLe(tmp, 1).setName("LoadingRestriction_"+i+"_"+t);				
			}

		//	R6
		for (int k=0; k < data.nTypes; k++){
			for (int t = 0; t < Tmax; t++) {
				IloNumExpr  tmp = cplex.constant(0);				
				for (int j = 0; j < nJobs; j++){ 					

					if ((Jobs[j].tIdx==k) && (t+Jobs[j].st_time < Tmax) && t>=Jobs[j].time[4] )
						tmp = cplex.sum(tmp, cplex.diff(Z[j][t+Jobs[j].st_time], Z[j][t-Jobs[j].time[4]]));				
				}
				//Number of trains with same type is finite
				if(!isNumExprEmpty(tmp, cplex)){
					cplex.addLe(tmp, data.TrClass[k].number).setName("ResourceCons_"+k+"_"+t);
					//	if(nUsedTrains != null) cplex.addLe(tmp,nUsedTrains[k]).setName("RCons_"+k+"_"+t);
				}

			}
		}
		for (int t = 0; t < Tmax; t++) {
			IloNumExpr  ULtmp = cplex.constant(0);
			for (Job j : Jobs){
				if ( (t+j.time[3]  < Tmax) )
					ULtmp = cplex.sum(ULtmp, cplex.diff(Z[j.idx][t+j.time[3]], Z[j.idx][t]));
			}
			cplex.addLe(ULtmp, data.TermUnloadCap).setName("Unloading_"+t);
		}
	}
	//=================================================================================================


	private void readAllSolutions(IloCplex cplex, Data data,  IloNumVar[][] Z, boolean chUBM) throws IloException {

		int nMines = data.nMines;		
		int NSols = 1;// cplex.getSolnPoolNsolns();

		for(int u=NSols-1; u >=0 ; u--){
			JobSched=  new int[nJobs][Tmax];
			for(int j=0; j < nJobs; j++){
				for(int t=0; t < Tmax; t++){
					JobSched[j][t] =  Math.round( (float) cplex.getValue(Z[j][t], u));					
					if (t>0 && JobSched[j][t]- JobSched[j][t-1] ==1 )					
						Jobs[j].cDate = t;
				}
			}		

			writeOutputs(data.conf.filePrefix);	
		}
	}

	public Job[] getJobsOfMine( int i) {
		// TODO Auto-generated method stub
		int cnt=0;
		for(int j=0; j < Jobs.length; j++)
			if(Jobs[j].mIdx ==i){
				//	out[cnt] = j;
				cnt ++;
			}
		Job[] out = new Job[cnt];

		cnt=0;
		for(int j=0; j < Jobs.length; j++)
			if(Jobs[j].mIdx ==i){
				out[cnt] = Jobs[j];
				cnt ++;
			}		
		return out;
	}


	private boolean isNumExprEmpty(IloNumExpr expr, IloCplex cp) throws IloException {
		// TODO Auto-generated method stub		
		return expr.getClass().toString().equals(cp.numExpr().getClass().toString());
	}

	private int cTime(int t){
		return Math.min(Tmax-1, Math.max(0, t));
	}

	//============================================================
	public void writeOutputs(String filePrefix){

		MyUtils Utils = new MyUtils(filePrefix);
		int nJobs = Jobs.length;

		//		for (int j=0; j < nJobs; j++){
		//			for(int t=1; t < Tmax; t++){
		//				if (JobSched[j][t]- JobSched[j][t-1] ==1 ){
		//			//		Jobs[j].cDate =	t;		// completion time 	
		//					break;
		//				}
		//			}			
		//		}

		String outStr="\nJob";
		for (int j=0; j < nJobs; j++)
			outStr +=","+j;	
		outStr +="\nMine";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ Jobs[j].mIdx;		
		outStr +="\nTrain";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ Jobs[j].tIdx;		
		outStr +="\nReady";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ Jobs[j].rDate;	
		outStr +="\nReach(AQ)";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ (Jobs[j].cDate - Jobs[j].time[3]-Jobs[j].time[2]-Jobs[j].time[1]);	
		outStr +="\nDue";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ Jobs[j].dDate;
		outStr +="\nCompletion";
		for (int j=0; j < nJobs; j++)
			outStr +=","+ Jobs[j].cDate;

		Utils.printf(outStr);		
	}


	private int getTmax(Data data){		
		int Tmax = data.nPeriods;
		Job[] tempJ = new Job[Jobs.length] ;
		for(int j=0; j < Jobs.length; j++){
			tempJ[j] =  Jobs[j];
		}

		for(int j=0; j < Jobs.length; j++){
			for(int t= Jobs[j].dDate; t < data.nPeriods*data.nMines ; t++){
				if (checkAvailability(data, tempJ, j, t)){
					tempJ[j].cDate = t;
					//	System.out.print("\t ["+ j+", "+ t+"] ");
					Tmax = Math.max(Tmax, t+1);
					break;
				}
			}
		}
		System.out.println("Tmax = "+ Tmax);
		return Tmax;
	}


	//===========================================================================

	private boolean checkAvailability(Data data, Job[] J, int idx, int time) {

		int[] nActiveTrains = new int[time+1];
		for(int t=0; t < nActiveTrains.length; t++)
			nActiveTrains[t] =0;

		int trType = J[idx].tIdx;
		int jrTime =  J[idx].time[0]+J[idx].time[1]+J[idx].time[2]+J[idx].time[3];
		int N = data.TrClass[trType].number; 

		for(int j=0; j< idx; j++){
			for(int t=0; t <= time; t++)
				if (J[j].tIdx == trType)
					if (J[j].cDate == t)
						for(int t1= Math.max(0, t - jrTime); t1 <Math.min(data.nPeriods-1, t+J[j].time[4]); t1++)
							nActiveTrains[t1]++;
		}	
		if(time < jrTime)
			System.out.println(" error ");
		return (nActiveTrains[Math.max(0,time-jrTime)] < N );
	}

	//===========================================================================
	public Job Job() {
		// TODO Auto-generated method stub
		return new Job();
	}

	public double getInitialSol(Data tData, IloCplex cplex) throws IloException{
		return getInitialSol(tData, cplex, null);
	}


	public double JobSchedModel(Data tData, IloCplex cplex) throws IloException{
		makeJobs(tData);
		double out = solveRailProb(cplex, tData);
		if ( out > RO_INF / 100)
			return out;
		// ACT Oct 17	tData.resetOrderCost();		

		out = logMineSolutions(tData, null, -1); 
		//	addColumnToMine(tData, (int)Math.round(cplex.getObjValue()), 0);		
		return  out;	
	}

	public double getInitialSol(Data tData, IloCplex cplex, Pattern PObj) throws IloException{	
		int[] BP = null;
		if (PObj != null)
			BP = PObj.getBestpattern();

		for(int i=0; i < tData.nMines; i++){
			cplex.clearModel();	
			tData.mine[i].msgflag = false;
			if(PObj == null){
				tData.mine[i].solveMineProb(cplex, tData);
				if(columnFlag) tData.mine[i].addColumnAndValue(0, tData);// .addAllColumns(cplex, tData);
			}
			else{			
				int[] TrCombo =  PObj.getIntPattern(i, BP);
				//////			ANU-Oct10		tData.mine[i].solveMineProb(cplex, tData, TrCombo);
			}
		}

		makeJobs(tData);
		double out = solveRailProb(cplex, tData);
		if ( out > RO_INF - 100)
			return out;
		// ACT	tData.resetOrderCost();		

		out = logMineSolutions(tData, null, -1); 
		//	addColumnToMine(tData, (int)Math.round(cplex.getObjValue()), 0);		
		return  out;		
	}

	public double logMineSolutions(Data data, MyUtils Utils, int itr) {
		return logMineSolutions(data, Utils, itr, true);
	}

	public double logMineSolutions(Data data, MyUtils Utils, int itr, boolean flag) {
		//*************Logging****************************	
		String newStr ="Mine, Obj, ActCost";
		double[] sum1 = new double[3];
		String solstr ="";
		for(int i=0; i < data.nMines; i++){
			data.mine[i].computeActualCost(this, data);
			double c1 = data.mine[i].objcost;
			double c2 = data.mine[i].getValue();
			// solstr += ("\n"+ data.mine[i].getMineSolnString(-10));
			newStr += "\n"+i+", "+Math.round(c1)+", "+ Math.round(c2);
			sum1[0] += c1;
			sum1[1] += c2;
			sum1[2] += (c2*1);
			summary_str += (i==0? "," : "+") ;
		}
		newStr += "\n-------- Itr: "+itr+" --------------------------"+
				"\nTotal = "+", "+Math.round(sum1[0])+", "+ Math.round(sum1[1])+
				"\nRailOpr = "+ObjVal+
				"\n----------------------------------\n";
		if(flag && Utils != null)
			Utils.printf(newStr,"summary.txt");
		if(Utils != null){
			solstr = "From the rail operator : Total sys cost ="+Math.round(sum1[2]) +solstr;
			Utils.printf(solstr,"solutions.txt");
		}

		//***********************************************
		return sum1[1]; //actual cost
	}

	public double solveForCG(IloCplex cp, Data td, int itr) {
		// TODO Auto-generated method stub
		newRailObj = false;
		privateProdInfo = false;
		makeJobs(td);
		return solveRailProb(cp,td,itr);
	}
}
