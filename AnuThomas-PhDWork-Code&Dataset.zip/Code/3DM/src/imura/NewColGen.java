package imura;

import java.text.DecimalFormat;
import java.util.Iterator;
import java.util.Random;

import ilog.concert.IloException;
import ilog.concert.IloNumExpr;
import ilog.concert.IloNumVar;
import ilog.concert.IloRange;
import ilog.cplex.IloCplex;
import imura.Mine.MineSol;

public class NewColGen {
	protected Data intData;

	double[] dualPricesMu = null;
	double[] dp_mu_ST= null;
	double[][] dualPrices= null;
	double[][] dp_lam_ST= null;
	double[][] STcenter= null;
	double[] STcenterMu= null;
	long startTime;
	long newseed = 1234567890;
	boolean hasAFeasSol = false;
	boolean stablCG = true;

	DecimalFormat twoDec = new DecimalFormat("#.##");
	DecimalFormat fourDec = new DecimalFormat("#.####");
	DecimalFormat custDec =twoDec;
	Solution SolObj;
	int pass = 0;
	double minTermCost = 10e10;
	double minRailCost = 10e10;

	public NewColGen(Data d){
		intData = d;
		dualPrices = new double[d.nTypes][d.nPeriods];
		dualPricesMu = new double[d.nPeriods];
		dp_lam_ST = new double[d.nTypes][d.nPeriods];
		dp_mu_ST = new double[d.nPeriods];
		STcenter= new double[d.nTypes][d.nPeriods];	
		STcenterMu= new double[d.nPeriods];
	}

	private void setData(Data din){
		this.intData = din;
	}


	public void solveWithColGen(IloCplex cplex) throws IloException{

		Data data = intData;
		// decentralised model		
		MyUtils Utils = new MyUtils(data.conf.filePrefix);
		cplex.clearModel();
		//	Pattern PatObj= new Pattern(data);

		int nMines = data.nMines;
		int nTypes = data.nTypes;
		int nPeriods = data.nPeriods;	
		int nShips = data.nShips;
		int itrLimit = data.conf.itrLimit;
		SolObj = new Solution(itrLimit, data);
		SolObj.bestLB = -1e20;
		SolObj.bestUB = 1e20;

		double[][][] lambda 	=  new double[nMines][nTypes][nPeriods];
		double[][] mu 			=  new double[nMines][nPeriods];
		double  cumTime = 0, step=0.1,  gamMax=0.9;

		initialiseVariables(lambda, mu);		

		Utils.printf("Itr, \tLB,  \tUB, \tGap, \tcTime, \tMasterLB, \tLB-Gap","summary.txt");

		startTime = System.currentTimeMillis();

		for(int itr=1; itr< itrLimit; itr++){
			double newLB=0;
			//LB computation		
			String costStr = " Cost =";
			for(int i=0; i < nMines; i++){
				cplex.clearModel();	
				data.mine[i].msgflag = false;
				data.mine[i].set_multipliers(lambda,mu);
				data.mine[i].solveMineProb(cplex, data);
				data.mine[i].addAllColumns(cplex, data);
				newLB += data.mine[i].objcost;
				costStr += ("\t "+ custDec.format(data.mine[i].objcost));
			}
			SolObj.LB[itr] = computeLB(newLB, lambda, mu);
			if ( (SolObj.LB[itr] > SolObj.bestLB)){
				SolObj.bestLB = SolObj.LB[itr];
				step = Math.min(2,step*1.3);
				copyValuesToSTcenter();// dp_lam -> ST_center, dp_mu -> ST_center_mu
			}else{
				step = step*0.9;
			}


			double[][] delta= computeViolation();
			SolObj.UB[itr]=computeUB(data,itr,cplex);
			solve_CG_model(cplex, data,  itr, false); // LP Version of RMP 


			if (SolObj.UB[itr] < SolObj.bestUB){
				SolObj.bestUB = SolObj.UB[itr];
			}


			cumTime = printIterationSummary(Utils, itr, step);
			if(SolObj.lb_gap <0)
				System.out.println(" Negative value please check");

			boolean  condition =  ( (SolObj.gap < data.conf.LR_GAP_LIMIT) || 
					(cumTime+200 > data.conf.LR_TIME_LIMIT) ||
					(itr>20 && hasAFeasSol && SolObj.RMPSol[itr-20]==SolObj.RMPSol[itr])||
					(SolObj.lb_gap < 0.001));


			if(data.conf.Model_Choice==49)			
				condition = ( (cumTime+200 > data.conf.LR_TIME_LIMIT)||
						(itr>20 && hasAFeasSol && SolObj.RMPSol[itr-20]==SolObj.RMPSol[itr]));


			if(condition)		{ // Master problems' LB and Lag LB are almost same{
				SolObj.bestUB = Math.min(SolObj.bestUB,computeUB(data,-10,cplex));
				printIterationSummary(Utils, itr, step);
				break; //QUITTING THE LOOP
			}					


			if (itr>10 && hasAFeasSol && SolObj.RMPSol[itr-10]*.9<SolObj.RMPSol[itr] && SolObj.UB[itr]==SolObj.UB[itr-10]){
				// trying to escape from a local minimum
				assign_dual_prices_randomly(data.nTypes, data.nPeriods, data.conf.Model_Choice, delta);
			}


			//			P. Wentges. Weighted Dantzig-Wolfe decomposition of linear mixed-integer programming.
			//			Int. Trans. Opl. Res., 4(2):151{162, 1997.

			gamMax = 1;// (stablCG ? 0.5: 1); 	
			boolean STon = (SolObj.bestUB < 1e19);// start using the center once we have a solution
			double gamOpt = (itr ==1? 1 : gamMax);
			for(int t=0; t< nPeriods; t++){
				dp_mu_ST[t] = (1-gamOpt)*(STon? STcenterMu[t]: dp_mu_ST[t]) + gamOpt*dualPricesMu[t];
				for(int m=0; m < nTypes; m++){
					dp_lam_ST[m][t] = (1-gamOpt)*(STon? STcenter[m][t]: dp_lam_ST[m][t])+ gamOpt*dualPrices[m][t];
				}		
			}

			//*************Lambda****************************					                 
			for(int m=0; m < nTypes; m++){
				for(int t=0; t < nPeriods; t++){					
					for(int i=0; i < nMines; i++){
						if(m==0) mu[i][t] = Math.max(0, -1*dualPricesMu[t]);
						lambda[i][m][t] = Math.max(0, -1*dp_lam_ST[m][t]);					
					} // mine loop					
				}
			}

			Utils.printf("\n\n ##### ITERATION - "+itr+"####\n", "cplex_log.txt");
			System.out.println("\n \n ************************************************ \n");
			Utils.printf("\n---------------------ITR:"+itr+"-------------------------------","solutions.txt");
			//	clearColumns(data); //cleaning columns
		}

	}

	private double computeUB(Data data, int itr, IloCplex cplex) throws IloException {
		return computeUB(data, itr, cplex, true);
	}

	private double computeUB(Data data, int itr, IloCplex cplex, boolean MP_int) throws IloException {
		// TODO Auto-generated method stub
		double compUB= SolObj.bestUB;

		if(SolObj.lb_gap < 0.01)
			pass ++;
		if(SolObj.lb_gap < 0.002)
			pass=1;

		if(hasAFeasSol && (itr%20==0  || pass==1) && MP_int)
			compUB = solve_CG_model(cplex, data,  itr, true); // Int Version of RMP

		Data td = intData;
		double cumTime = (System.currentTimeMillis() - startTime)/1000;
		if(cumTime > td.conf.LR_TIME_LIMIT || itr <= 0)
			return compUB; // time out



		RailOpr RO12 = new RailOpr();		
		double UBfromRail = RO12.solveForCG(cplex, td, itr);

		if(UBfromRail < 1e15){
			hasAFeasSol = true;
			System.out.println("Solution from Rail Model "+ UBfromRail);
			compUB=UBfromRail;
		}		
		return compUB;
	}

	private double solve_CG_model(IloCplex cp, Data td, int itr, boolean IntFlag) throws IloException {
		// TODO Auto-generated method stub
		double UBout=1e20;
		if(IntFlag)
			System.out.println(" Solving the integer master problem ");
		else
			System.out.println(" Solving the relaxed master problem ");

		IloNumVar[][] Xic = new IloNumVar[td.nMines][]; 
		IloNumVar[][] Yship = new IloNumVar[td.nShips][td.nPeriods];


		if(!solveMasterProblem(cp, td, itr, Xic, Yship,IntFlag)){
			System.out.println("Could not solve MasterProb: IntFlag="+IntFlag+" itr= "+itr);

			assign_dual_prices_randomly(td.nTypes, td.nPeriods, td.conf.Model_Choice);
			return UBout;
		}
		double cpObjVal = cp.getObjValue();

		if(!IntFlag)
			SolObj.RMPSol[itr] = cpObjVal;

		String outStr;
		if(IntFlag){
			outStr = "Integer Version  obj = "+ custDec.format(cpObjVal);			
		}else
			outStr = "Relaxed prob objcost  = "+ custDec.format(cpObjVal);


		int[] FeasCols =  new int[Xic.length]; 
		double[] minesCost =  new double[td.nMines];
		double actCost =0; 

		double[][] Xval = new double[td.nMines][];	
		double[][] redCost = new double[td.nMines][];
		String solnstr ="";		
		int goodMine =0;

		for(int i=0; i < Xic.length; i++){
			double xSum =0;
			Xval[i] = new double[Xic[i].length];
			if(!IntFlag){				
				redCost[i] =  cp.getReducedCosts(Xic[i]);			
			}

			for(int c=0; c < Xic[i].length; c++){
				Xval[i][c] = cp.getValue(Xic[i][c]);	
				if(!IntFlag){
					if( (!cp.getBasisStatus(Xic[i][c]).toString().endsWith("Basic")) && Xval[i][c] ==0)				
						td.mine[i].colVector.get(c).nonBasicCnt++;
					else
						td.mine[i].colVector.get(c).nonBasicCnt =0;
				}
				xSum += Xval[i][c]; 
				if( Xval[i][c] > 1e-4){

					if(IntFlag && hasAFeasSol){
						minesCost[i]  = td.mine[i].allColumns.get(c).actMineCost;
						actCost += (int)Math.round((minesCost[i]));
						solnstr += "\n" + td.mine[i].getMineSolnString(c);
					}else
						minesCost[i]  = td.mine[i].colVector.get(c).actMineCost;

					int chance = (int)Math.round(100*Xval[i][c]);
					outStr += "\t ("+i+", "+c+", "+ (IntFlag? "": chance) +" ["+custDec.format(minesCost[i])+"] ), ";
					FeasCols[i] =c;
				}
			}
			if(!IntFlag && !hasAFeasSol && xSum>1-1e-3)
				goodMine ++;
		}
		if(!IntFlag && !hasAFeasSol && goodMine==td.nMines)
			hasAFeasSol = true; // To identify atleast one global solution 

		if(itr>=0)
			SolObj.lb_gap = (hasAFeasSol? (SolObj.RMPSol[itr]-SolObj.bestLB)/SolObj.RMPSol[itr]: 100);
		System.out.println(outStr);

		if(!IntFlag){ // valid only for LP version			
			setDualPrice_and_UB(cp, td, itr, Xval);
		}else{
			MyUtils utils = new MyUtils(td.conf.filePrefix);
			utils.printf(solnstr,"solutions.txt");
		}

		double outvalue = (actCost>0? actCost: UBout);
		if(hasAFeasSol && !IntFlag && SolObj.lb_gap<0.2){
			// Following logic is necessary only for RMP 
			outvalue = Math.min(outvalue, use_best_columns(td, Xval, itr, cp));
			SolObj.UB[itr] = Math.min(SolObj.UB[itr],outvalue);
		}
		// Bestcol will be affected if we delete any column from the list.
		for(int i=0; i < td.nMines; i++){			
			for(int c = td.mine[i].colVector.size()-1; c >= 0; c--){
				MineSol MS = td.mine[i].colVector.get(c);					
				if(MS.nonBasicCnt >= 10 ){						
					//			System.out.println("Removing columns " +c+" "+  MS.key_str+" from mine "+i);
					td.mine[i].lpColList.remove(MS.key_str);
					td.mine[i].colVector.remove(MS);
				}
			}
		}		
		return outvalue;
	}


	private void assign_dual_prices_randomly(int nTypes, int nPeriods, int ch) {
		// TODO Auto-generated method stub
		assign_dual_prices_randomly(nTypes, nPeriods, ch, null);
	}

	private void assign_dual_prices_randomly(int type, int period, int ch, double[][] del) {
		// TODO Auto-generated method stub
		System.out.println("Assigning dual prices randomly to break the infeasibility");

		if(del==null){
			Random rd = new Random();
			int fact = (ch==4? 10: 100);
			for(int t=0; t < period; t++){
				dualPricesMu[t] = -fact*rd.nextDouble()*(SolObj.bestLB);
				for(int m=0; m < type; m++){	
					dualPrices[m][t] = -fact*rd.nextDouble()*(SolObj.bestLB);
				}
			}
		}else{

			double[][] delLam = new double[type][period];
			double[] delMu = new double[period];
			for(int m=0; m < type; m++){
				for(int t=0; t < period; t++){
					delLam[m][t] = del[m][t];
					if(m==0) delMu[t]  =  del[type][t];
				}
				
			}
			
			MyUtils Utils = new MyUtils("");
			double[]  normL = Utils .norm(delLam);
			double  normMu = Utils .norm(delMu);
			
			for(int t=0; t < period; t++){
				dualPricesMu[t] = Math.max(0,  dualPricesMu[t] - 0.1*(SolObj.bestUB-SolObj.bestLB)*delMu[t]/normMu);
				for(int m=0; m < type; m++){	
					dualPrices[m][t] = Math.max(0,  dualPrices[m][t] - 0.1*(SolObj.bestUB-SolObj.bestLB)*delLam[m][t]/normL[m]);
				}
			}
		}
	}

	private double use_best_columns(Data td, double[][] Xval, int itr, IloCplex cp) throws IloException{

		int MAX=5;
		double ubvalue = SolObj.bestUB;
		for(int sam =0; sam < MAX; sam++){

			String colStr = "Column selection : ";
			String key_str ="";
			int[] FeasCols = new int[td.nMines];			
			for(int i=0; i < Xval.length; i++){
				int prob =0;
				FeasCols[i] = -1;
				int rNo = (new Random(1011201110+(sam-1)*1000+itr*100+10*i)).nextInt(100);
				for(int c=0; c < Xval[i].length; c++){
					if( Xval[i][c] <= 0) continue;		
					prob += (int)Math.round(100*Xval[i][c]);
					FeasCols[i] =c;
					if(prob >= rNo) break;
				}	
				if(FeasCols[i] >= 0){ 		
					colStr += "\t ("+i+", "+FeasCols[i]+", "+ rNo +") ";
					key_str += ("+"+ td.mine[i].colVector.get(FeasCols[i]).key_str);
				}else{
					return ubvalue; 
				}
			}
			System.out.println(colStr);

			if (SolObj.evaluatedPat.contains(key_str)){			
				System.out.println("Already evaluated pattern (repair) " + key_str);
				continue;
			}
			else
				SolObj.evaluatedPat.add(key_str);
			for(int i=0; i < Xval.length; i++)
				td.mine[i].setSolution(FeasCols[i]);
			ubvalue = Math.min(ubvalue, computeUB(td, itr, cp, false));
		}
		return ubvalue;
	}

	private boolean solveMasterProblem(IloCplex cp, Data td, int itr,
			IloNumVar[][] Xic, IloNumVar[][] Yship, boolean intFlag) throws IloException {
		// TODO Auto-generated method stub

		IloNumVar[] MineValue = cp.numVarArray(td.nMines, 0, Integer.MAX_VALUE); 

		int[] colDim =  new int[td.nMines];
		int[] idxArray = null;
		double[] minValue =  new double[td.nMines];
		IloNumExpr obj = cp.numExpr();
		String col_string="";

		cp.clearModel();
		// choiceFlag==0 LP version, ==1; INT full version, ==2 INT last iteration
		int choiceFlag = (intFlag? 1: 0);
		for(int k=0; k < td.nShips; k++){
			if(choiceFlag==0)
				Yship[k] = cp.numVarArray(td.nPeriods, 0, 1);
			else
				Yship[k] = cp.intVarArray(td.nPeriods, 0, 1);

			for(int t=0; t< td.nShips; t++)
				Yship[k][t].setName("YShip_"+t);
		}

		for(int i=0; i < td.nMines; i++){			
			if(choiceFlag==1){
				colDim[i] = td.mine[i].allColumns.size();//  columns.size();	
				Xic[i] = cp.intVarArray(colDim[i], 0, 1);
			}else if(choiceFlag==0){
				colDim[i] = td.mine[i].colVector.size();//  columns.size();	
				Xic[i] = cp.numVarArray(colDim[i], 0, 1);
			}else if(choiceFlag==2){
				colDim[i] =   idxArray[i]+1;//  columns.size();
				Xic[i] = cp.intVarArray(1, 0, 1);
			}
			col_string += "_"+colDim[i];

			IloNumExpr colSum = cp.numExpr();	
			IloNumExpr tmpObj = cp.numExpr();
			int startIdx= (choiceFlag==2 ?  colDim[i]-1:0);
			for(int c = startIdx; c< colDim[i];  c++){
				Xic[i][c-startIdx].setName("Xcol_"+i+"_"+c);				

				double value;
				if(choiceFlag==1 || (choiceFlag==2 && idxArray != null)){
					value = td.mine[i].allColumns.get(c).value;
					if(c==0 || minValue[i] > value)
						minValue[i]  = value;	
				}else
					value = td.mine[i].colVector.get(c).value;

				tmpObj = cp.sum(tmpObj, cp.prod(Xic[i][c-startIdx], value));
				colSum = cp.sum(colSum, Xic[i][c-startIdx]);
			}

			if(choiceFlag==2 || !hasAFeasSol){
				cp.addLe(colSum, 1).setName("ColSelect_"+i);
				double penalty = ( 1e8);
				tmpObj = cp.sum(tmpObj, cp.prod( cp.diff(1.0, colSum), penalty ));
			}else{
				cp.addEq(colSum, 1).setName("ColSelect_"+i);				
			}

			cp.addEq(MineValue[i], tmpObj).setName("MineObj_"+i);
			obj = cp.sum(obj, MineValue[i]);
		}
		System.out.println("Col String itr= "+ col_string);

		for(int t=0; t < td.nPeriods; t++){		
			IloNumExpr tmpSumTerm = cp.numExpr(); // for the terminal
			IloNumExpr tmpTerDem = cp.numExpr(); // for term
			for(int m=0; m < td.nTypes; m++){
				IloNumExpr tmpSum = cp.numExpr(); // for the rail opr				
				for(int i=0; i < td.nMines; i++){		
					int startIdx= (choiceFlag==2 ?  colDim[i]-1:0);
					for(int c= startIdx; c <colDim[i]; c++ ){	
						MineSol MS;
						if(choiceFlag==1 || (choiceFlag==2 && idxArray != null)){
							MS = td.mine[i].allColumns.get(c);
						}else
							MS = td.mine[i].colVector.get(c);						

						if(m==0)
							tmpTerDem = cp.sum(tmpTerDem, cp.prod(Xic[i][c-startIdx],MS.CumDelivery[t]));

						if(MS.nRN_Trains[m][t] >0)
							tmpSum = cp.sum(tmpSum, cp.prod(Xic[i][c-startIdx], MS.nRN_Trains[m][t]));

						if(MS.nUL_Trains[m][t] >0)
							tmpSumTerm = cp.sum(tmpSumTerm, cp.prod(Xic[i][c-startIdx], MS.nRN_Trains[m][t]));
					}										
				}
				if (!isNumExprEmpty(tmpSum, cp))
					cp.addLe(tmpSum,  td.TrClass[m].number).setName("ResConst_"+m+"_"+t);
			}
			if (!isNumExprEmpty(tmpSumTerm, cp) && t != td.nPeriods-1)
				cp.addLe(tmpSumTerm,  td.TermUnloadCap).setName("UnLoading_"+t);		

			/*		IloNumExpr rhs = cp.numExpr();
		//	IloNumExpr  tmpTermObj =  cp.constant(0);
			for(int l=0; l < td.nShips; l++){
				if(td.ShipOrdDue[l]<= t){
					rhs  = cp.prod(cp.sum(rhs,cp.diff(1, Yship[l][t])), td.ShipOrdQty[l]);
			//		tmpTermObj = cp.sum(tmpTermObj, cp.prod(Yship[l][t],td.ShipOrdQty[l]*td.conf.ShipDemurrage));
				}
			}
			 */		

			//		cp.addGe(tmpTerDem, rhs).setName("Yship_MP_"+t);
			//	obj = cp.sum(obj,tmpTermObj);
		}

		if(choiceFlag==1){//Integer Version
			cp.addLe(obj, SolObj.bestUB + 100);
			cp.addGe(obj, SolObj.bestLB);
		}

		cp.addMinimize(obj);
		MyUtils Utils = new MyUtils("");
		String lbl ="CG-"; int TL=0;
		if(choiceFlag==1){
			cp.exportModel("colgen_int.lp"); lbl +="MIP"; TL=300;
		}else if(choiceFlag==2){
			cp.exportModel("colgen_intCurr.lp"); lbl +="MIP"; TL=300;
		}else{
			cp.exportModel("colgen_relax.lp");	lbl +="LP";
		}
		return Utils.solveAndRecord(cp, lbl, 0, TL);		
	}

	private boolean isNumExprEmpty(IloNumExpr expr, IloCplex cp) throws IloException {
		// TODO Auto-generated method stub
		return expr.getClass().toString().equals(cp.numExpr().getClass().toString());
	}

	private void setDualPrice_and_UB(IloCplex cp, Data td, int itr,
			double[][] xval) throws IloException {
		// TODO Auto-generated method stub
		double currrBest = 1e20;
		for(int i=0; i < dualPricesMu.length; i++)
			dualPricesMu[i] =0;
		for(int i=0; i < dualPrices.length; i++){			
			for(int j=0; j < dualPrices[i].length; j++){
				dualPrices[i][j] =0;
			}
		}
		for (Iterator it = cp.rangeIterator(); it.hasNext(); /* nothing */) {
			IloRange range = (IloRange)it.next();
			String name = range.getName();
			//	System.out.println(" Ilo "+ name +" \t slack "+ cp.getSlack(range));
			if(name != null  && name.startsWith("ResConst_")){
				String[] sub = name.split("_");
				int trClass = Integer.parseInt(sub[1]);
				int time = Integer.parseInt(sub[2]);
				dualPrices[trClass][time] = cp.getDual(range);	
				//		if(dualPrices[trClass][time] !=0)
				//				System.out.print("\t dp("+time+")=" + fourDec.format(dualPrices[trClass][time]));
			}
			else if (name != null  && name.startsWith("ColSelect_")){
				String[] sub = name.split("_");
				int mineIdx = Integer.parseInt(sub[1]);
				td.mine[mineIdx].dualPrice = cp.getDual(range);
				//				System.out.println(" mine["+mineIdx+"] dualPrice " +td.mine[mineIdx].dualPrice );
			}
			else if (name != null  && name.startsWith("UnLoading_")){
				String[] sub = name.split("_");				
				int time = Integer.parseInt(sub[1]);
				dualPricesMu[time] = cp.getDual(range);	
				//			if(dualPricesMu[time] !=0)
				//				System.out.print("\t dmu("+time+")=" + fourDec.format(dualPricesMu[time]));
			}
		}
	}

	private double printIterationSummary(MyUtils Utils, int itr, double step) {
		SolObj.gap = (SolObj.bestUB-SolObj.bestLB)/SolObj.bestUB;
		System.out.println("Itr-"+itr+" \t LB*"+Math.round(SolObj.bestLB)+
				" \t UB*"+Math.round(SolObj.bestUB)+
				" \t LB(k)"+Math.round(SolObj.LB[itr])+
				" \t UB(k)"+Math.round(SolObj.UB[itr])
				+" \t gap(k)"+Math.round(SolObj.gap*100));

		double cumTime = (System.currentTimeMillis() - startTime)/1000;

		String str = itr+", \t"+ custDec.format(SolObj.bestLB);
		if (hasAFeasSol)
			str += ", "+ (SolObj.bestUB <1e19 ? custDec.format(SolObj.bestUB): "UBMAX") +
			",\t "+ twoDec.format(SolObj.gap*100);

		else
			str += ", *****, - ";
		str += ",\t "+ Math.round(cumTime)+",\t "+ custDec.format(SolObj.RMPSol[itr])+
				",\t "+ custDec.format(SolObj.lb_gap*100);


		Utils.printf(str,"summary.txt");		
		return cumTime;
	}


	private void copyValuesToSTcenter() {
		// TODO Auto-generated method stub
		for(int t=0; t < intData.nPeriods; t++){			
			STcenterMu[t] =dp_mu_ST[t];
			for(int m=0; m < intData.nTypes; m++){		
				STcenter[m][t] =dp_lam_ST[m][t];
			}
		}
	}

	private double[][] computeViolation() throws IloException{
		Data data = intData;
		int nMines = data.nMines;
		int nPeriods = data.nPeriods;
		int nTypes = data.nTypes;
		MineSol[] MS = new MineSol[nMines];
		for(int i=0; i < nMines; i++)
			MS[i] = data.mine[i].getSolution(-1);

		double[][] Delta =  new double[nTypes+1][nPeriods];		
		for(int m=0; m < nTypes; m++)
			for(int t=0; t < nPeriods; t++){
				double sum=0; 
				for(int i=0; i < nMines; i++)
					sum += MS[i].nRN_Trains[m][t]; 				

				Delta[m][t] = (data.TrClass[m].number - sum);				
			}


		for(int t=0; t < nPeriods; t++){
			double sum=0; 

			for(int m=0; m < nTypes; m++){					
				for(int i=0; i < nMines; i++)
					sum += MS[i].nUL_Trains[m][t]; 				
			}
			Delta[nTypes][t] = (data.TermUnloadCap - sum);				
		}
		return Delta;
	}

	private double computeLB(double LBin, double[][][] lambda, double[][] mu) {
		// TODO Auto-generated method stub

		Data data = intData;
		double [] cumDel = new double[data.nPeriods];
		double [] cumDemand = new double[data.nPeriods];
		cumDemand[0]=0;
		for(int t=1; t < data.nPeriods; t++){
			cumDel[t] = 0;

			for(int s=0; s < data.nShips; s++)
				if(t==data.ShipOrdDue[s]){
					cumDemand[t]= cumDemand[t-1]+data.ShipOrdQty[s];
					break;
				}else
					cumDemand[t]= cumDemand[t-1];
		}

		for(int i=0; i < data.nMines; i++){
			MineSol sol = data.mine[i].getSolution(-1);	
			for(int t=0; t < data.nPeriods; t++){
				cumDel[t] += sol.CumDelivery[t];
			}
		}


		double railcost=0;
		for(int i=0; i < data.nMines; i++){				
			railcost += data.mine[i].getSolution(-1).railobjcost;
		}

		double termcost =0;
		for(int t=0; t < data.nPeriods; t++){
			if(cumDel[t]< cumDemand[t])
				for(int s=0; s < data.nShips-1; s++)
					if ( (t >  data.ShipOrdDue[s]) && (s==data.nShips-1 || t < data.ShipOrdDue[s+1])) 
						termcost += data.ShipOrdQty[s]*data.conf.ShipDemurrage;
		}


		double penalty = 0;  
		for(int t=0; t < intData.nPeriods; t++){			
			for(int m=0; m < intData.nTypes; m++){
				penalty += lambda[0][m][t]*intData.TrClass[m].number;
			}
			penalty += mu[0][t]*intData.TermUnloadCap;
		}
		System.out.println("LB = "+(LBin-penalty)+" Lbsum " + LBin+" penalty "+ penalty);
		if(intData.conf.Model_Choice==4)
			return LBin-penalty;//+railcost+termcost;
		else
			System.out.println("Adding other players value using the secure sum\nRcost ="+railcost+"   ShipCost= " +termcost);

		minRailCost = Math.min(railcost, minRailCost);
		minTermCost = Math.min(termcost, minTermCost);
		return LBin-penalty+minRailCost+minTermCost;
	}

	private void initialiseVariables(double[][][] lambda, double[][] mu) {	
		for(int t=0; t < intData.nPeriods; t++){
			dp_mu_ST[t]=0;
			STcenterMu[t] =0;
			for(int m=0; m < intData.nTypes; m++){		
				STcenter[m][t] =0;
				dp_lam_ST[m][t]=0;
				for(int i=0; i < intData.nMines; i++){
					lambda[i][m][t] = 0;			
					if(m==0) mu[i][t] = 0;		
				}
			}
		}
	}
}
